import express, { Request, Response } from 'express';
import dotenv from 'dotenv';
import path from 'path';
import fs from 'fs';
import { fileURLToPath } from 'url';
import { requireAuth, AuthRequest } from './src/middleware/auth.ts';
import { getOrCreateUser } from './src/db/users.ts';
import {
  getProducts,
  upsertProduct,
  deleteProduct,
  clearAllProducts,
  getOrders,
  createOrder,
  updateOrderStatus,
  deleteOrder,
  clearAllOrders,
  getStoreSettings,
  updateStoreSettings,
  restoreDemoData,
} from './src/db/store.ts';

dotenv.config();

const __filename = fileURLToPath(import.meta.url);
const __dirname = path.dirname(__filename);

const app = express();
const PORT = process.env.PORT ? parseInt(process.env.PORT, 10) : 3000;

// High limit for base64 images uploaded for products
app.use(express.json({ limit: '50mb' }));
app.use(express.urlencoded({ extended: true, limit: '50mb' }));

// Ensure public/uploads directory exists
const uploadsDir = path.join(__dirname, 'public', 'uploads');
if (!fs.existsSync(uploadsDir)) {
  fs.mkdirSync(uploadsDir, { recursive: true });
}

// Serve uploaded images directly with cache headers
app.use('/uploads', express.static(uploadsDir, {
  maxAge: '30d',
  immutable: true,
}));

// Helper to automatically convert any base64 image strings into static disk files
function saveBase64ToFile(base64Str: string): string {
  if (!base64Str || typeof base64Str !== 'string' || !base64Str.startsWith('data:image/')) {
    return base64Str;
  }
  const matches = base64Str.match(/^data:image\/([a-zA-Z0-9+]+);base64,(.+)$/);
  if (!matches) return base64Str;
  let ext = matches[1].toLowerCase();
  if (ext === 'jpeg') ext = 'jpg';
  if (ext === 'svg+xml') ext = 'svg';
  const buffer = Buffer.from(matches[2], 'base64');
  const safeName = `img_${Date.now()}_${Math.random().toString(36).substring(2, 8)}.${ext}`;
  const filePath = path.join(uploadsDir, safeName);
  fs.writeFileSync(filePath, buffer);
  return `/uploads/${safeName}`;
}

// Upload endpoint: saves base64 image as static file on disk and returns fast URL
app.post('/api/upload', (req: Request, res: Response) => {
  try {
    const { image } = req.body;
    if (!image || typeof image !== 'string') {
      return res.status(400).json({ error: 'No image provided' });
    }
    const matches = image.match(/^data:image\/([a-zA-Z0-9+]+);base64,(.+)$/);
    if (!matches) {
      return res.status(400).json({ error: 'Invalid base64 image data' });
    }
    let ext = matches[1].toLowerCase();
    if (ext === 'jpeg') ext = 'jpg';
    if (ext === 'svg+xml') ext = 'svg';
    const base64Data = matches[2];
    const buffer = Buffer.from(base64Data, 'base64');
    const safeName = `img_${Date.now()}_${Math.random().toString(36).substring(2, 8)}.${ext}`;
    const filePath = path.join(uploadsDir, safeName);
    fs.writeFileSync(filePath, buffer);
    res.json({ url: `/uploads/${safeName}` });
  } catch (err: any) {
    console.error('Error saving image file:', err);
    res.status(500).json({ error: err.message || 'Upload failed' });
  }
});

// Health check
app.get('/api/health', (_req: Request, res: Response) => {
  res.json({ status: 'ok', timestamp: new Date().toISOString() });
});

// Authentication / User Sync
app.post('/api/auth/sync-user', requireAuth, async (req: AuthRequest, res: Response) => {
  try {
    if (!req.user || !req.user.uid || !req.user.email) {
      return res.status(400).json({ error: 'User UID and email required' });
    }
    const user = await getOrCreateUser(req.user.uid, req.user.email, req.body.displayName);
    res.json(user);
  } catch (error: any) {
    console.error('Error syncing user:', error);
    res.status(500).json({ error: error.message || 'Failed to sync user' });
  }
});

// Products API
app.get('/api/products', async (_req: Request, res: Response) => {
  try {
    const products = await getProducts();
    res.json(products);
  } catch (error: any) {
    console.error('Error getting products:', error);
    res.status(500).json({ error: error.message || 'Failed to get products' });
  }
});

app.post('/api/products', async (req: Request, res: Response) => {
  try {
    const product = req.body;
    if (!product || !product.id || !product.name) {
      return res.status(400).json({ error: 'Invalid product data' });
    }
    // Automatically convert any base64 images to static files on disk
    if (product.customImage && typeof product.customImage === 'string' && product.customImage.startsWith('data:image/')) {
      product.customImage = saveBase64ToFile(product.customImage);
    }
    if (Array.isArray(product.galleryImages)) {
      product.galleryImages = product.galleryImages.map((img: string) =>
        typeof img === 'string' && img.startsWith('data:image/') ? saveBase64ToFile(img) : img
      );
    }
    const saved = await upsertProduct(product);
    res.json(saved);
  } catch (error: any) {
    console.error('Error saving product:', error);
    res.status(500).json({ error: error.message || 'Failed to save product' });
  }
});

app.delete('/api/products/:id', async (req: Request, res: Response) => {
  try {
    const { id } = req.params;
    await deleteProduct(id);
    res.json({ success: true });
  } catch (error: any) {
    console.error('Error deleting product:', error);
    res.status(500).json({ error: error.message || 'Failed to delete product' });
  }
});

app.post('/api/products/clear', async (_req: Request, res: Response) => {
  try {
    await clearAllProducts();
    res.json({ success: true });
  } catch (error: any) {
    console.error('Error clearing products:', error);
    res.status(500).json({ error: error.message || 'Failed to clear products' });
  }
});

// Orders API
app.get('/api/orders', async (_req: Request, res: Response) => {
  try {
    const orders = await getOrders();
    res.json(orders);
  } catch (error: any) {
    console.error('Error getting orders:', error);
    res.status(500).json({ error: error.message || 'Failed to get orders' });
  }
});

app.post('/api/orders', async (req: Request, res: Response) => {
  try {
    const order = req.body;
    if (!order || !order.id || !order.customerName || !order.phone) {
      return res.status(400).json({ error: 'Invalid order data' });
    }
    const saved = await createOrder(order);
    res.json(saved);
  } catch (error: any) {
    console.error('Error creating order:', error);
    res.status(500).json({ error: error.message || 'Failed to create order' });
  }
});

app.patch('/api/orders/:id', async (req: Request, res: Response) => {
  try {
    const { id } = req.params;
    const { status } = req.body;
    await updateOrderStatus(id, status);
    res.json({ success: true });
  } catch (error: any) {
    console.error('Error updating order status:', error);
    res.status(500).json({ error: error.message || 'Failed to update order status' });
  }
});

app.delete('/api/orders/:id', async (req: Request, res: Response) => {
  try {
    const { id } = req.params;
    await deleteOrder(id);
    res.json({ success: true });
  } catch (error: any) {
    console.error('Error deleting order:', error);
    res.status(500).json({ error: error.message || 'Failed to delete order' });
  }
});

app.post('/api/orders/clear', async (_req: Request, res: Response) => {
  try {
    await clearAllOrders();
    res.json({ success: true });
  } catch (error: any) {
    console.error('Error clearing orders:', error);
    res.status(500).json({ error: error.message || 'Failed to clear orders' });
  }
});

app.post('/api/store/restore-demo', async (_req: Request, res: Response) => {
  try {
    const result = await restoreDemoData();
    res.json(result);
  } catch (error: any) {
    console.error('Error restoring demo data:', error);
    res.status(500).json({ error: error.message || 'Failed to restore demo data' });
  }
});

// Settings API
app.get('/api/settings', async (_req: Request, res: Response) => {
  try {
    const settings = await getStoreSettings();
    res.json(settings);
  } catch (error: any) {
    console.error('Error getting settings:', error);
    res.status(500).json({ error: error.message || 'Failed to get settings' });
  }
});

app.post('/api/settings', async (req: Request, res: Response) => {
  try {
    const settings = req.body;
    const saved = await updateStoreSettings(settings);
    res.json(saved);
  } catch (error: any) {
    console.error('Error saving settings:', error);
    res.status(500).json({ error: error.message || 'Failed to save settings' });
  }
});

// Setup Vite middleware in dev or serve dist in production
async function startServer() {
  const isProd = process.env.NODE_ENV === 'production';

  if (!isProd) {
    const { createServer: createViteServer } = await import('vite');
    const vite = await createViteServer({
      server: { middlewareMode: true },
      appType: 'spa',
    });
    app.use(vite.middlewares);
  } else {
    const distPath = path.resolve(__dirname, 'dist');
    app.use(express.static(distPath));
    app.get('*', (_req: Request, res: Response) => {
      res.sendFile(path.join(distPath, 'index.html'));
    });
  }

  app.listen(PORT, '0.0.0.0', () => {
    console.log(`Server listening on http://0.0.0.0:${PORT}`);
  });
}

startServer().catch((err) => {
  console.error('Failed to start server:', err);
});
