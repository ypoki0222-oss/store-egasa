import type { Config, Context } from '@netlify/functions';
import { getStore } from '@netlify/blobs';

const MIME_TYPES: Record<string, string> = {
  png: 'image/png',
  jpg: 'image/jpeg',
  gif: 'image/gif',
  webp: 'image/webp',
  svg: 'image/svg+xml',
  avif: 'image/avif',
};

// Serves product images uploaded from the admin dashboard (stored in Netlify Blobs)
export default async (_req: Request, context: Context) => {
  const key = context.params.key;
  const data = await getStore('uploads').get(key, { type: 'arrayBuffer' });
  if (!data) return new Response('Not found', { status: 404 });
  const ext = key.split('.').pop()?.toLowerCase() || '';
  return new Response(data, {
    headers: {
      'Content-Type': MIME_TYPES[ext] || 'application/octet-stream',
      'Cache-Control': 'public, max-age=31536000, immutable',
    },
  });
};

export const config: Config = {
  path: '/uploads/:key',
  preferStatic: true,
};
