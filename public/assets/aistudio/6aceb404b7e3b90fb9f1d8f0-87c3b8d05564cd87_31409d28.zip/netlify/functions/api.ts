import type { Config } from '@netlify/functions';
import { getStore } from '@netlify/blobs';
import {
  getProducts,
  upsertProduct,
  deleteProduct,
  clearAllProducts,
  getOrders,
  createOrder,
  updateOrderStatus,
  deleteOrder,
  clearAllOrders,
  getStoreSettings,
  updateStoreSettings,
  restoreDemoData,
} from '../../src/db/store.ts';

// Saves a base64 data URL to Netlify Blobs and returns its public /uploads URL
async function saveBase64Image(base64Str: string): Promise<string> {
  const matches = base64Str.match(/^data:image\/([a-zA-Z0-9+]+);base64,(.+)$/);
  if (!matches) return base64Str;
  let ext = matches[1].toLowerCase();
  if (ext === 'jpeg') ext = 'jpg';
  if (ext === 'svg+xml') ext = 'svg';
  const buffer = Uint8Array.from(Buffer.from(matches[2], 'base64')).buffer;
  const key = `img_${Date.now()}_${Math.random().toString(36).substring(2, 8)}.${ext}`;
  await getStore('uploads').set(key, buffer);
  return `/uploads/${key}`;
}

const isDataImage = (v: unknown): v is string => typeof v === 'string' && v.startsWith('data:image/');

export default async (req: Request) => {
  const { pathname } = new URL(req.url);
  const [resource, sub] = pathname.replace(/^\/api\/?/, '').split('/').filter(Boolean);
  const method = req.method;

  try {
    if (resource === 'health') {
      return Response.json({ status: 'ok', timestamp: new Date().toISOString() });
    }

    if (resource === 'upload' && method === 'POST') {
      const { image } = await req.json();
      if (!isDataImage(image)) {
        return Response.json({ error: 'Invalid base64 image data' }, { status: 400 });
      }
      return Response.json({ url: await saveBase64Image(image) });
    }

    if (resource === 'products') {
      if (!sub && method === 'GET') return Response.json(await getProducts());
      if (!sub && method === 'POST') {
        const product = await req.json();
        if (!product || !product.id || !product.name) {
          return Response.json({ error: 'Invalid product data' }, { status: 400 });
        }
        if (isDataImage(product.customImage)) {
          product.customImage = await saveBase64Image(product.customImage);
        }
        if (Array.isArray(product.galleryImages)) {
          product.galleryImages = await Promise.all(
            product.galleryImages.map((img: string) => (isDataImage(img) ? saveBase64Image(img) : img))
          );
        }
        return Response.json(await upsertProduct(product));
      }
      if (sub === 'clear' && method === 'POST') {
        await clearAllProducts();
        return Response.json({ success: true });
      }
      if (sub && method === 'DELETE') {
        await deleteProduct(decodeURIComponent(sub));
        return Response.json({ success: true });
      }
    }

    if (resource === 'orders') {
      if (!sub && method === 'GET') return Response.json(await getOrders());
      if (!sub && method === 'POST') {
        const order = await req.json();
        if (!order || !order.id || !order.customerName || !order.phone) {
          return Response.json({ error: 'Invalid order data' }, { status: 400 });
        }
        return Response.json(await createOrder(order));
      }
      if (sub === 'clear' && method === 'POST') {
        await clearAllOrders();
        return Response.json({ success: true });
      }
      if (sub && method === 'PATCH') {
        const { status } = await req.json();
        await updateOrderStatus(decodeURIComponent(sub), status);
        return Response.json({ success: true });
      }
      if (sub && method === 'DELETE') {
        await deleteOrder(decodeURIComponent(sub));
        return Response.json({ success: true });
      }
    }

    if (resource === 'settings') {
      if (method === 'GET') return Response.json(await getStoreSettings());
      if (method === 'POST') return Response.json(await updateStoreSettings(await req.json()));
    }

    if (resource === 'store' && sub === 'restore-demo' && method === 'POST') {
      return Response.json(await restoreDemoData());
    }

    return Response.json({ error: 'Not found' }, { status: 404 });
  } catch (error: any) {
    console.error(`API error on ${method} ${pathname}:`, error);
    return Response.json({ error: error?.message || 'Server error' }, { status: 500 });
  }
};

export const config: Config = {
  path: '/api/*',
};
