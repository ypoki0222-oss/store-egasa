CREATE TABLE "orders" (
	"id" text PRIMARY KEY,
	"order_number" text NOT NULL,
	"customer_name" text NOT NULL,
	"phone" text NOT NULL,
	"city" text NOT NULL,
	"address" text NOT NULL,
	"notes" text,
	"items" jsonb DEFAULT '[]' NOT NULL,
	"subtotal" double precision NOT NULL,
	"shipping_cost" double precision NOT NULL,
	"total_price" double precision NOT NULL,
	"status" text DEFAULT 'new' NOT NULL,
	"synced_to_google_sheets" boolean DEFAULT false NOT NULL,
	"google_sheets_response" text,
	"created_at" timestamp DEFAULT now() NOT NULL
);
--> statement-breakpoint
CREATE TABLE "products" (
	"id" text PRIMARY KEY,
	"name" text NOT NULL,
	"slug" text NOT NULL,
	"price" double precision NOT NULL,
	"original_price" double precision,
	"category" text NOT NULL,
	"description" text NOT NULL,
	"features" jsonb DEFAULT '[]' NOT NULL,
	"in_stock" boolean DEFAULT true NOT NULL,
	"badge" text DEFAULT '',
	"rating" double precision DEFAULT 5 NOT NULL,
	"reviews_count" integer DEFAULT 0 NOT NULL,
	"sizes" jsonb DEFAULT '[]' NOT NULL,
	"colors" jsonb DEFAULT '[]' NOT NULL,
	"fabrics" jsonb DEFAULT '[]' NOT NULL,
	"image_svg_type" text DEFAULT 'caftan' NOT NULL,
	"custom_image" text,
	"gallery_images" jsonb DEFAULT '[]' NOT NULL,
	"bundle_offer" jsonb,
	"created_at" timestamp DEFAULT now() NOT NULL,
	"updated_at" timestamp DEFAULT now() NOT NULL
);
--> statement-breakpoint
CREATE TABLE "store_settings" (
	"key" text PRIMARY KEY,
	"data" jsonb NOT NULL,
	"updated_at" timestamp DEFAULT now() NOT NULL
);
--> statement-breakpoint
CREATE TABLE "users" (
	"id" serial PRIMARY KEY,
	"uid" text NOT NULL UNIQUE,
	"email" text NOT NULL,
	"display_name" text,
	"role" text DEFAULT 'admin' NOT NULL,
	"created_at" timestamp DEFAULT now() NOT NULL
);
