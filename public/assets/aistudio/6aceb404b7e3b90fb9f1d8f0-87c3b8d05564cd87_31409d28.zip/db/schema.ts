import { pgTable, serial, text, integer, boolean, timestamp, doublePrecision, jsonb } from 'drizzle-orm/pg-core';

// Users table (linked to Firebase Auth UID)
export const users = pgTable('users', {
  id: serial('id').primaryKey(),
  uid: text('uid').notNull().unique(),
  email: text('email').notNull(),
  displayName: text('display_name'),
  role: text('role').default('admin').notNull(),
  createdAt: timestamp('created_at').defaultNow().notNull(),
});

// Products table
export const productsTable = pgTable('products', {
  id: text('id').primaryKey(),
  name: text('name').notNull(),
  slug: text('slug').notNull(),
  price: doublePrecision('price').notNull(),
  originalPrice: doublePrecision('original_price'),
  category: text('category').notNull(),
  description: text('description').notNull(),
  features: jsonb('features').$type<string[]>().default([]).notNull(),
  inStock: boolean('in_stock').default(true).notNull(),
  badge: text('badge').default(''),
  rating: doublePrecision('rating').default(5.0).notNull(),
  reviewsCount: integer('reviews_count').default(0).notNull(),
  sizes: jsonb('sizes').$type<string[]>().default([]).notNull(),
  colors: jsonb('colors').$type<{ name: string; hex: string }[]>().default([]).notNull(),
  fabrics: jsonb('fabrics').$type<string[]>().default([]).notNull(),
  imageSvgType: text('image_svg_type').default('caftan').notNull(),
  customImage: text('custom_image'),
  galleryImages: jsonb('gallery_images').$type<string[]>().default([]).notNull(),
  bundleOffer: jsonb('bundle_offer').$type<any>(),
  createdAt: timestamp('created_at').defaultNow().notNull(),
  updatedAt: timestamp('updated_at').defaultNow().notNull(),
});

// Orders table
export const ordersTable = pgTable('orders', {
  id: text('id').primaryKey(),
  orderNumber: text('order_number').notNull(),
  customerName: text('customer_name').notNull(),
  phone: text('phone').notNull(),
  city: text('city').notNull(),
  address: text('address').notNull(),
  notes: text('notes'),
  items: jsonb('items').$type<any[]>().default([]).notNull(),
  subtotal: doublePrecision('subtotal').notNull(),
  shippingCost: doublePrecision('shipping_cost').notNull(),
  totalPrice: doublePrecision('total_price').notNull(),
  status: text('status').default('new').notNull(),
  syncedToGoogleSheets: boolean('synced_to_google_sheets').default(false).notNull(),
  googleSheetsResponse: text('google_sheets_response'),
  createdAt: timestamp('created_at').defaultNow().notNull(),
});

// Store Settings table
export const settingsTable = pgTable('store_settings', {
  key: text('key').primaryKey(),
  data: jsonb('data').notNull(),
  updatedAt: timestamp('updated_at').defaultNow().notNull(),
});
