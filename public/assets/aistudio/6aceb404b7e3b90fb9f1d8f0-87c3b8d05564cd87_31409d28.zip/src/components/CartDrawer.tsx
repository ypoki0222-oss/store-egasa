import React, { useState } from 'react';
import { Product, StoreSettings, Order, OrderItem } from '../types';
import { FashionIllustration } from './FashionIllustration';
import { pixelService } from '../services/pixelService';
import { sendOrderToGoogleSheet } from '../services/googleSheetsService';
import { X, Trash2, ShoppingBag, ArrowLeft, CheckCircle2, User, Phone, MapPin } from 'lucide-react';

interface CartDrawerProps {
  isOpen: boolean;
  items: {
    product: Product;
    selectedSize: string;
    selectedColor: string;
    selectedFabric?: string;
    quantity: number;
  }[];
  settings: StoreSettings;
  onClose: () => void;
  onUpdateQuantity: (index: number, newQty: number) => void;
  onRemoveItem: (index: number) => void;
  onOrderSuccess: (order: Order) => void;
}

export const CartDrawer: React.FC<CartDrawerProps> = ({
  isOpen,
  items,
  settings,
  onClose,
  onUpdateQuantity,
  onRemoveItem,
  onOrderSuccess,
}) => {
  const [showCheckoutForm, setShowCheckoutForm] = useState(false);
  const [customerName, setCustomerName] = useState('');
  const [phone, setPhone] = useState('');
  const [city, setCity] = useState('');
  const [address, setAddress] = useState('');
  const [notes, setNotes] = useState('');
  const [isSubmitting, setIsSubmitting] = useState(false);
  const [formError, setFormError] = useState('');

  if (!isOpen) return null;

  const subtotal = items.reduce((sum, item) => sum + item.product.price * item.quantity, 0);
  const shippingCost = 0;
  const grandTotal = subtotal;

  const handleCheckoutSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    setFormError('');

    if (!customerName.trim() || !phone.trim() || !city.trim() || !address.trim()) {
      setFormError('يرجى ملء جميع الحقول المطلوبة لتأكيد التوصيل.');
      return;
    }

    setIsSubmitting(true);
    const orderNumber = `#ORD-${Math.floor(1000 + Math.random() * 9000)}`;

    const orderItems: OrderItem[] = items.map((i) => ({
      productId: i.product.id,
      productName: i.product.name,
      price: i.product.price,
      quantity: i.quantity,
      selectedSize: i.selectedSize,
      selectedColor: i.selectedColor,
      selectedFabric: i.selectedFabric,
      imageSvgType: i.product.imageSvgType,
    }));

    const newOrder: Order = {
      id: `ord-${Date.now()}`,
      orderNumber,
      createdAt: new Date().toISOString(),
      customerName: customerName.trim(),
      phone: phone.trim(),
      city: city.trim(),
      address: address.trim(),
      notes: notes.trim(),
      items: orderItems,
      subtotal,
      shippingCost,
      totalPrice: grandTotal,
      status: 'new',
      syncedToGoogleSheets: false,
    };

    // Track Pixel Purchase
    pixelService.track(
      'Purchase',
      {
        value: grandTotal,
        currency: settings.currency,
        num_items: items.length,
        order_id: orderNumber,
        customer_name: customerName.trim(),
        customer_phone: phone.trim(),
      },
      settings.pixel
    );

    // Sync to Google Sheets if configured
    if (settings.googleSheetsWebhookUrl && settings.googleSheetsAutoSync) {
      const syncResult = await sendOrderToGoogleSheet(
        newOrder,
        settings.googleSheetsWebhookUrl,
        settings.currency
      );
      newOrder.syncedToGoogleSheets = syncResult.success;
      newOrder.googleSheetsResponse = syncResult.message;
    }

    setIsSubmitting(false);
    onOrderSuccess(newOrder);
    onClose();
  };

  return (
    <div className="fixed inset-0 z-50 flex justify-end bg-black/50 backdrop-blur-xs">
      <div className="relative w-full max-w-md bg-white h-full shadow-2xl flex flex-col text-right">
        {/* Header */}
        <div className="flex items-center justify-between p-4 border-b border-stone-200 bg-stone-50">
          <div className="flex items-center gap-2">
            <ShoppingBag className="w-5 h-5 text-stone-800" />
            <h3 className="text-base font-bold text-stone-900">سلة المشتريات</h3>
            <span className="text-xs font-mono text-stone-500">({items.length} منتجات)</span>
          </div>
          <button
            onClick={onClose}
            className="p-1 text-stone-500 hover:text-black rounded-lg hover:bg-stone-200 transition-colors cursor-pointer"
            aria-label="إغلاق السلة"
          >
            <X className="w-5 h-5" />
          </button>
        </div>

        {/* Free delivery banner */}
        {items.length > 0 && (
          <div className="p-2.5 bg-emerald-50 border-b border-emerald-100 text-xs">
            <p className="text-emerald-700 font-bold flex items-center gap-1.5 justify-center">
              <CheckCircle2 className="w-4 h-4 text-emerald-600 shrink-0" />
              <span>التوصيل مجاني 100% لجميع الطلبات والدفع عند الاستلام</span>
            </p>
          </div>
        )}

        {/* Content */}
        <div className="flex-1 overflow-y-auto p-4 space-y-4">
          {items.length === 0 ? (
            <div className="h-full flex flex-col items-center justify-center text-center p-6 space-y-3 text-stone-500">
              <ShoppingBag className="w-12 h-12 text-stone-300" />
              <p className="text-base font-bold text-stone-800">السلة فارغة حالياً</p>
              <p className="text-xs">تصفح تشكيلة الملابس واختر قطعك المفضلة وسنصلها لك.</p>
              <button
                onClick={onClose}
                className="mt-2 px-5 py-2.5 bg-stone-900 text-white text-xs font-bold rounded-xl hover:bg-stone-800 transition-colors cursor-pointer"
              >
                تصفح المنتجات
              </button>
            </div>
          ) : !showCheckoutForm ? (
            <div className="space-y-3">
              {items.map((item, index) => (
                <div
                  key={`${item.product.id}-${item.selectedSize}-${item.selectedColor}-${index}`}
                  className="flex items-center gap-3 p-3 bg-stone-50 rounded-xl border border-stone-200"
                >
                  {/* Thumbnail */}
                  <div className="w-16 h-20 rounded-lg overflow-hidden shrink-0 border border-stone-200 bg-white">
                    <FashionIllustration
                      type={item.product.imageSvgType}
                      accentColor="#2D3748"
                      className="w-full h-full object-cover"
                    />
                  </div>

                  {/* Details */}
                  <div className="flex-1 min-w-0">
                    <h4 className="text-xs font-bold text-stone-900 truncate">{item.product.name}</h4>
                    <div className="text-[11px] text-stone-500 flex items-center gap-2 mt-0.5">
                      <span>المقاس: {item.selectedSize}</span>
                      <span>·</span>
                      <span>اللون: {item.selectedColor}</span>
                    </div>
                    <div className="text-xs font-bold font-mono text-stone-900 mt-1">
                      {item.product.price} {settings.currency}
                    </div>

                    {/* Quantity & Remove */}
                    <div className="flex items-center justify-between mt-2">
                      <div className="inline-flex items-center border border-stone-300 rounded bg-white text-xs">
                        <button
                          onClick={() => onUpdateQuantity(index, item.quantity - 1)}
                          className="px-2 py-0.5 hover:bg-stone-100 cursor-pointer"
                        >
                          -
                        </button>
                        <span className="px-2 py-0.5 font-mono font-bold">{item.quantity}</span>
                        <button
                          onClick={() => onUpdateQuantity(index, item.quantity + 1)}
                          className="px-2 py-0.5 hover:bg-stone-100 cursor-pointer"
                        >
                          +
                        </button>
                      </div>

                      <button
                        onClick={() => onRemoveItem(index)}
                        className="text-stone-400 hover:text-rose-600 p-1 transition-colors cursor-pointer"
                        aria-label="حذف"
                      >
                        <Trash2 className="w-3.5 h-3.5" />
                      </button>
                    </div>
                  </div>
                </div>
              ))}
            </div>
          ) : (
            /* Fast Formulaire in Cart */
            <form onSubmit={handleCheckoutSubmit} className="space-y-3.5">
              <div className="flex items-center justify-between pb-2 border-b border-stone-200">
                <h4 className="text-xs font-bold text-stone-900">بيانات التوصيل (الدفع عند الاستلام)</h4>
                <button
                  type="button"
                  onClick={() => setShowCheckoutForm(false)}
                  className="text-xs text-stone-500 hover:underline cursor-pointer"
                >
                  تعديل المنتجات
                </button>
              </div>

              {formError && (
                <div className="p-2.5 bg-rose-50 border border-rose-200 text-rose-700 text-xs rounded-lg">
                  {formError}
                </div>
              )}

              <div>
                <label className="block text-xs font-bold text-stone-700 mb-1">الاسم الكامل *</label>
                <input
                  type="text"
                  required
                  placeholder="محمد أحمد"
                  value={customerName}
                  onChange={(e) => setCustomerName(e.target.value)}
                  className="w-full px-3 py-2 border border-stone-300 rounded-lg text-xs focus:ring-1 focus:ring-stone-900"
                />
              </div>

              <div>
                <label className="block text-xs font-bold text-stone-700 mb-1">رقم الهاتف / الواتساب *</label>
                <input
                  type="tel"
                  required
                  placeholder="05XXXXXXXX"
                  dir="ltr"
                  value={phone}
                  onChange={(e) => setPhone(e.target.value)}
                  className="w-full px-3 py-2 border border-stone-300 rounded-lg text-xs focus:ring-1 focus:ring-stone-900"
                />
              </div>

              <div>
                <label className="block text-xs font-bold text-stone-700 mb-1">المدينة *</label>
                <input
                  type="text"
                  required
                  placeholder="الرياض، جدة، دبي..."
                  value={city}
                  onChange={(e) => setCity(e.target.value)}
                  className="w-full px-3 py-2 border border-stone-300 rounded-lg text-xs focus:ring-1 focus:ring-stone-900"
                />
              </div>

              <div>
                <label className="block text-xs font-bold text-stone-700 mb-1">العنوان بالتفصيل *</label>
                <input
                  type="text"
                  required
                  placeholder="الحي، اسم الشارع، رقم المنزل"
                  value={address}
                  onChange={(e) => setAddress(e.target.value)}
                  className="w-full px-3 py-2 border border-stone-300 rounded-lg text-xs focus:ring-1 focus:ring-stone-900"
                />
              </div>

              <div>
                <label className="block text-xs font-bold text-stone-700 mb-1">ملاحظات (اختياري)</label>
                <input
                  type="text"
                  placeholder="أي توجيهات للمندوب"
                  value={notes}
                  onChange={(e) => setNotes(e.target.value)}
                  className="w-full px-3 py-2 border border-stone-300 rounded-lg text-xs focus:ring-1 focus:ring-stone-900"
                />
              </div>

              <button
                type="submit"
                disabled={isSubmitting}
                className="w-full py-3.5 bg-[#1E232A] hover:bg-black text-white font-bold text-xs rounded-xl shadow-md transition-all cursor-pointer flex items-center justify-center gap-2 mt-4"
              >
                {isSubmitting ? (
                  <span>جاري تأكيد طلبك...</span>
                ) : (
                  <>
                    <CheckCircle2 className="w-4 h-4 text-emerald-400" />
                    <span>تأكيد الطلب الآن ({grandTotal} {settings.currency})</span>
                  </>
                )}
              </button>
            </form>
          )}
        </div>

        {/* Footer */}
        {items.length > 0 && !showCheckoutForm && (
          <div className="p-4 border-t border-stone-200 bg-stone-50 space-y-3">
            <div className="space-y-1.5 text-xs text-stone-600">
              <div className="flex items-center justify-between">
                <span>سعر المنتجات:</span>
                <span className="font-mono tabular-nums font-bold">{subtotal} {settings.currency}</span>
              </div>
              <div className="pt-2 border-t border-stone-200 flex items-center justify-between text-sm font-extrabold text-stone-900">
                <span>المجموع الكلي:</span>
                <span className="text-base text-red-600 font-mono tabular-nums font-black">{grandTotal} {settings.currency}</span>
              </div>
            </div>

            <button
              onClick={() => setShowCheckoutForm(true)}
              className="w-full py-3.5 bg-[#1E232A] hover:bg-black text-white font-bold text-xs rounded-xl shadow-md transition-all cursor-pointer flex items-center justify-center gap-2"
            >
              <span>متابعة لتأكيد الطلب (الدفع عند الاستلام)</span>
              <ArrowLeft className="w-4 h-4" />
            </button>
          </div>
        )}
      </div>
    </div>
  );
};
