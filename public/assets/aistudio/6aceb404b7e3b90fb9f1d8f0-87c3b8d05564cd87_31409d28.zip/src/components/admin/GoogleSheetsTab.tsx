import React, { useState } from 'react';
import {
  GOOGLE_APPS_SCRIPT_TEMPLATE,
  testWebhook,
} from '../../services/googleSheetsService';
import {
  FileSpreadsheet,
  Save,
  Check,
  Copy,
  ExternalLink,
  Zap,
  HelpCircle,
  Table,
  CheckCircle2,
  AlertCircle,
} from 'lucide-react';

interface GoogleSheetsTabProps {
  webhookUrl: string;
  autoSync: boolean;
  onSave: (url: string, autoSync: boolean) => void;
}

export const GoogleSheetsTab: React.FC<GoogleSheetsTabProps> = ({
  webhookUrl,
  autoSync,
  onSave,
}) => {
  const [url, setUrl] = useState(webhookUrl);
  const [sync, setSync] = useState(autoSync);
  const [isSaved, setIsSaved] = useState(false);
  const [copiedCode, setCopiedCode] = useState(false);
  const [testResult, setTestResult] = useState<{ loading: boolean; success?: boolean; message?: string } | null>(null);

  const handleCopyCode = () => {
    navigator.clipboard.writeText(GOOGLE_APPS_SCRIPT_TEMPLATE);
    setCopiedCode(true);
    setTimeout(() => setCopiedCode(false), 2000);
  };

  const handleTestWebhook = async () => {
    if (!url.trim()) {
      setTestResult({ loading: false, success: false, message: 'يرجى إدخال الرابط أولاً للاختبار.' });
      return;
    }

    setTestResult({ loading: true });
    const result = await testWebhook(url);
    setTestResult({ loading: false, success: result.success, message: result.message });
  };

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    onSave(url.trim(), sync);
    setIsSaved(true);
    setTimeout(() => setIsSaved(false), 2500);
  };

  return (
    <form onSubmit={handleSubmit} className="space-y-8 text-right max-w-4xl">
      {/* Top Banner & Save */}
      <div className="flex items-center justify-between bg-white p-4 rounded-xl border border-stone-200">
        <div>
          <h3 className="text-sm font-bold text-stone-900 flex items-center gap-2">
            <FileSpreadsheet className="w-4 h-4 text-emerald-600" />
            <span>ربط طلبات الفورمولير تلقائياً مع Google Sheets</span>
          </h3>
          <p className="text-xs text-stone-500 mt-0.5">
            بمجرد أن يملأ العميل نموذج الطلب في المتجر، يُسجل الطلب فوراً في جدول بيانات غوغل الخاص بك.
          </p>
        </div>
        <button
          type="submit"
          className="flex items-center gap-2 px-5 py-2 bg-stone-900 hover:bg-black text-white text-xs font-bold rounded-lg transition-colors cursor-pointer shadow-xs"
        >
          {isSaved ? <Check className="w-4 h-4 text-emerald-400" /> : <Save className="w-4 h-4" />}
          <span>{isSaved ? 'تم الحفظ!' : 'حفظ الإعدادات'}</span>
        </button>
      </div>

      {/* Webhook URL Input & Test */}
      <div className="bg-white p-6 rounded-2xl border border-stone-200 space-y-4">
        <h4 className="text-sm font-bold text-stone-900 flex items-center gap-2 border-b border-stone-100 pb-3">
          <Zap className="w-4 h-4 text-amber-500" />
          <span>رابط الويب هوك (Google Web App URL / Webhook)</span>
        </h4>

        <div>
          <label className="block text-xs font-bold text-stone-800 mb-1">
            رابط تطبيق الويب (Google Apps Script Web App URL) *
          </label>
          <div className="flex items-center gap-2">
            <input
              type="url"
              placeholder="https://script.google.com/macros/s/AKfycbx.../exec"
              dir="ltr"
              value={url}
              onChange={(e) => setUrl(e.target.value)}
              className="flex-1 px-3 py-2 border border-stone-300 rounded-lg text-xs font-mono focus:ring-1 focus:ring-stone-900 text-left bg-stone-50"
            />
            <button
              type="button"
              onClick={handleTestWebhook}
              disabled={testResult?.loading}
              className="px-4 py-2 bg-stone-100 hover:bg-stone-200 text-stone-800 text-xs font-semibold rounded-lg transition-colors cursor-pointer shrink-0 border border-stone-300"
            >
              {testResult?.loading ? 'جاري الفحص...' : 'فحص الاتصال (Test)'}
            </button>
          </div>
          <span className="text-[11px] text-stone-400 mt-1 block">
            يمكنك أيضاً استخدام روابط Zapier, Make, أو Pabbly إن كنت تفضل ذلك.
          </span>
        </div>

        {/* Test Result Message */}
        {testResult && !testResult.loading && (
          <div
            className={`p-3 rounded-xl border text-xs flex items-center gap-2 ${
              testResult.success
                ? 'bg-emerald-50 border-emerald-200 text-emerald-800'
                : 'bg-rose-50 border-rose-200 text-rose-800'
            }`}
          >
            {testResult.success ? (
              <CheckCircle2 className="w-4 h-4 text-emerald-600 shrink-0" />
            ) : (
              <AlertCircle className="w-4 h-4 text-rose-600 shrink-0" />
            )}
            <span>{testResult.message}</span>
          </div>
        )}

        {/* Auto Sync Toggle */}
        <div className="pt-2 flex items-center justify-between border-t border-stone-100">
          <div>
            <div className="text-xs font-bold text-stone-900">المزامنة التلقائية الفورية</div>
            <p className="text-[11px] text-stone-500">إرسال كل طلب فور ضغط العميل على "تأكيد الطلب"</p>
          </div>
          <label className="relative inline-flex items-center cursor-pointer">
            <input
              type="checkbox"
              checked={sync}
              onChange={(e) => setSync(e.target.checked)}
              className="sr-only peer"
            />
            <div className="w-11 h-6 bg-stone-200 peer-focus:outline-none rounded-full peer peer-checked:after:translate-x-full peer-checked:after:border-white after:content-[''] after:absolute after:top-[2px] after:left-[2px] after:bg-white after:border-stone-300 after:border after:rounded-full after:h-5 after:w-5 after:transition-all peer-checked:bg-emerald-600"></div>
          </label>
        </div>
      </div>

      {/* 60-Second Setup Guide */}
      <div className="bg-white p-6 rounded-2xl border border-stone-200 space-y-5">
        <div className="flex items-center justify-between border-b border-stone-100 pb-3">
          <div className="flex items-center gap-2">
            <HelpCircle className="w-4 h-4 text-blue-600" />
            <h4 className="text-sm font-bold text-stone-900">
              طريقة التفعيل في 60 ثانية (بدون خبرة برمجية)
            </h4>
          </div>
          <button
            type="button"
            onClick={handleCopyCode}
            className="flex items-center gap-1.5 px-3 py-1.5 bg-stone-100 hover:bg-stone-200 text-stone-800 text-xs font-semibold rounded-lg transition-colors cursor-pointer"
          >
            {copiedCode ? <Check className="w-3.5 h-3.5 text-emerald-600" /> : <Copy className="w-3.5 h-3.5" />}
            <span>{copiedCode ? 'تم نسخ الكود!' : 'نسخ الكود بالكامل'}</span>
          </button>
        </div>

        {/* Steps */}
        <ol className="space-y-3 text-xs text-stone-600 list-decimal list-inside pr-2 leading-relaxed">
          <li>
            افتح{' '}
            <a
              href="https://sheets.google.com"
              target="_blank"
              rel="noreferrer"
              className="text-stone-900 underline font-semibold inline-flex items-center gap-1"
            >
              جدول بيانات غوغل جديد (Google Sheet) <ExternalLink className="w-3 h-3 inline" />
            </a>
          </li>
          <li>
            اضغط من القائمة العلوية على <strong>الإضافات (Extensions)</strong> ثم <strong>Apps Script</strong>.
          </li>
          <li>
            امسح أي كود موجود في الصفحة، ثم اضغط على زر <strong>"نسخ الكود بالكامل"</strong> أعلاه والصقه هناك.
          </li>
          <li>
            اضغط على زر <strong>نشر (Deploy)</strong> في الزاوية العلوية ثم <strong>نشر جديد (New deployment)</strong>.
          </li>
          <li>
            اختر نوع النشر: <strong>تطبيق ويب (Web app)</strong>، وفي خيار <em>من يملك حق الوصول (Who has access)</em> اختر <strong>أي مستخدم (Anyone)</strong>.
          </li>
          <li>
            انسخ رابط <strong>Web App URL</strong> الذي يظهر لك والصقه في خانة الرابط أعلاه ثم اضغط حفظ!
          </li>
        </ol>

        {/* Script Code Preview Box */}
        <div className="relative rounded-xl overflow-hidden border border-stone-200 bg-stone-900">
          <div className="px-4 py-2 bg-stone-950 flex items-center justify-between text-[11px] text-stone-400">
            <span>Google Apps Script Code</span>
            <span className="font-mono">Code.gs</span>
          </div>
          <pre
            dir="ltr"
            className="p-4 text-[11px] font-mono text-stone-300 max-h-56 overflow-y-auto overflow-x-auto text-left leading-relaxed"
          >
            {GOOGLE_APPS_SCRIPT_TEMPLATE}
          </pre>
        </div>

        {/* Data Schema Columns preview */}
        <div className="pt-2">
          <h5 className="text-xs font-bold text-stone-800 mb-2 flex items-center gap-1.5">
            <Table className="w-3.5 h-3.5 text-stone-500" />
            <span>الأعمدة التي سيتم إنشاؤها تلقائياً في جدولك:</span>
          </h5>
          <div className="flex flex-wrap gap-1.5 text-[11px] text-stone-700">
            {[
              'تاريخ الطلب',
              'رقم الطلب',
              'اسم العميل',
              'رقم الهاتف',
              'المدينة',
              'العنوان التفصيلي',
              'المنتجات',
              'المقاس',
              'اللون',
              'الكمية',
              'المبلغ الإجمالي',
              'حالة الطلب',
              'ملاحظات',
            ].map((col, idx) => (
              <span key={idx} className="bg-stone-100 border border-stone-200 px-2 py-0.5 rounded">
                {col}
              </span>
            ))}
          </div>
        </div>
      </div>
    </form>
  );
};
