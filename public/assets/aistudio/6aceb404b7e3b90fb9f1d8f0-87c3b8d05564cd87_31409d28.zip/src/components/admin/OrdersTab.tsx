import React, { useState } from 'react';
import { Order, OrderStatus } from '../../types';
import { exportOrdersToCSV, sendOrderToGoogleSheet } from '../../services/googleSheetsService';
import {
  Search,
  Filter,
  Download,
  MessageCircle,
  RefreshCw,
  Phone,
  MapPin,
  Calendar,
  CheckCircle2,
  Clock,
  Truck,
  PackageCheck,
  XCircle,
  ExternalLink,
  Trash2,
} from 'lucide-react';

interface OrdersTabProps {
  orders: Order[];
  currency: string;
  googleSheetsWebhookUrl: string;
  onUpdateOrderStatus: (orderId: string, newStatus: OrderStatus) => void;
  onRefreshSync: (orderId: string) => void;
  onClearOrders?: () => void;
}

export const OrdersTab: React.FC<OrdersTabProps> = ({
  orders,
  currency,
  googleSheetsWebhookUrl,
  onUpdateOrderStatus,
  onRefreshSync,
  onClearOrders,
}) => {
  const [searchTerm, setSearchTerm] = useState('');
  const [statusFilter, setStatusFilter] = useState<string>('all');
  const [syncingOrderId, setSyncingOrderId] = useState<string | null>(null);

  const filteredOrders = orders.filter((order) => {
    const matchesSearch =
      order.orderNumber.toLowerCase().includes(searchTerm.toLowerCase()) ||
      order.customerName.toLowerCase().includes(searchTerm.toLowerCase()) ||
      order.phone.includes(searchTerm) ||
      order.city.toLowerCase().includes(searchTerm.toLowerCase());

    const matchesStatus = statusFilter === 'all' || order.status === statusFilter;
    return matchesSearch && matchesStatus;
  });

  const handleManualSync = async (order: Order) => {
    if (!googleSheetsWebhookUrl) {
      alert('يرجى أولاً إدخال رابط Google Sheets Webhook في تبويب "ربط غوغل شيت".');
      return;
    }
    setSyncingOrderId(order.id);
    const res = await sendOrderToGoogleSheet(order, googleSheetsWebhookUrl, currency);
    setSyncingOrderId(null);
    if (res.success) {
      onRefreshSync(order.id);
      alert('تم إرسال الطلب بنجاح إلى جدول Google Sheets!');
    } else {
      alert(res.message);
    }
  };

  const handleOpenCustomerWhatsApp = (order: Order) => {
    const cleanPhone = order.phone.replace(/[^0-9]/g, '');
    const itemsText = order.items
      .map((i) => `${i.productName} (مقاس: ${i.selectedSize} - لون: ${i.selectedColor})`)
      .join('، ');
    const msg = `مرحباً ${order.customerName}،\nنتواصل معك من متجر الأزياء لتأكيد طلبك رقم (${order.orderNumber}):\nالمنتج: ${itemsText}\nالمبلغ المطلوب عند الاستلام: ${order.totalPrice} ${currency}\nالعنوان: ${order.city} - ${order.address}\nهل تؤكد التوصيل؟`;
    window.open(`https://wa.me/${cleanPhone}?text=${encodeURIComponent(msg)}`, '_blank');
  };

  const getStatusBadge = (status: OrderStatus) => {
    switch (status) {
      case 'new':
        return (
          <span className="inline-flex items-center gap-1 px-2.5 py-0.5 rounded-full text-xs font-semibold bg-blue-50 text-blue-700 border border-blue-200">
            <Clock className="w-3 h-3" />
            <span>طلب جديد</span>
          </span>
        );
      case 'confirmed':
        return (
          <span className="inline-flex items-center gap-1 px-2.5 py-0.5 rounded-full text-xs font-semibold bg-emerald-50 text-emerald-700 border border-emerald-200">
            <CheckCircle2 className="w-3 h-3" />
            <span>تم التأكيد</span>
          </span>
        );
      case 'shipping':
        return (
          <span className="inline-flex items-center gap-1 px-2.5 py-0.5 rounded-full text-xs font-semibold bg-amber-50 text-amber-700 border border-amber-200">
            <Truck className="w-3 h-3" />
            <span>قيد الشحن</span>
          </span>
        );
      case 'delivered':
        return (
          <span className="inline-flex items-center gap-1 px-2.5 py-0.5 rounded-full text-xs font-semibold bg-purple-50 text-purple-700 border border-purple-200">
            <PackageCheck className="w-3 h-3" />
            <span>تم التسليم</span>
          </span>
        );
      case 'cancelled':
        return (
          <span className="inline-flex items-center gap-1 px-2.5 py-0.5 rounded-full text-xs font-semibold bg-rose-50 text-rose-700 border border-rose-200">
            <XCircle className="w-3 h-3" />
            <span>ملغى</span>
          </span>
        );
    }
  };

  return (
    <div className="space-y-6 text-right">
      {/* Search, Filter & Export Bar */}
      <div className="flex flex-col sm:flex-row items-stretch sm:items-center justify-between gap-4 bg-white p-4 rounded-xl border border-stone-200">
        <div className="flex items-center gap-3 flex-1 flex-wrap">
          {/* Search Input */}
          <div className="relative flex-1 min-w-[220px]">
            <Search className="w-4 h-4 text-stone-400 absolute right-3 top-3" />
            <input
              type="text"
              placeholder="البحث برقم الطلب، اسم العميل، الهاتف، أو المدينة..."
              value={searchTerm}
              onChange={(e) => setSearchTerm(e.target.value)}
              className="w-full pr-9 pl-3 py-2 bg-stone-50 border border-stone-300 rounded-lg text-xs focus:ring-1 focus:ring-stone-900 text-right"
            />
          </div>

          {/* Status Filter */}
          <div className="flex items-center gap-1.5">
            <Filter className="w-4 h-4 text-stone-400" />
            <select
              value={statusFilter}
              onChange={(e) => setStatusFilter(e.target.value)}
              className="px-3 py-2 bg-stone-50 border border-stone-300 rounded-lg text-xs text-stone-700 font-medium cursor-pointer"
            >
              <option value="all">كافة الحالات ({orders.length})</option>
              <option value="new">طلبات جديدة</option>
              <option value="confirmed">تم التأكيد</option>
              <option value="shipping">قيد الشحن</option>
              <option value="delivered">تم التسليم</option>
              <option value="cancelled">ملغاة</option>
            </select>
          </div>
        </div>

        {/* Actions Bar */}
        <div className="flex items-center gap-2 flex-wrap sm:flex-nowrap">
          {onClearOrders && orders.length > 0 && (
            <button
              onClick={() => {
                if (window.confirm('هل أنت متأكد من رغبتك في حذف كافة الطلبات التجريبية للبدء من الصفر؟')) {
                  onClearOrders();
                }
              }}
              className="flex items-center justify-center gap-1.5 px-3 py-2 bg-rose-50 hover:bg-rose-100 text-rose-700 border border-rose-200 rounded-lg text-xs font-bold transition-colors cursor-pointer shrink-0"
              title="تفريغ كافة الطلبات التجريبية للبدء من 0"
            >
              <Trash2 className="w-3.5 h-3.5 text-rose-600" />
              <span>تفريغ الطلبات التجريبية</span>
            </button>
          )}

          {/* CSV Export Button */}
          <button
            onClick={() => exportOrdersToCSV(orders, currency)}
            className="flex items-center justify-center gap-2 px-4 py-2 bg-stone-900 text-white rounded-lg text-xs font-bold hover:bg-stone-800 transition-colors cursor-pointer shrink-0"
          >
            <Download className="w-3.5 h-3.5" />
            <span>تصدير الطلبات (Excel / CSV)</span>
          </button>
        </div>
      </div>

      {/* Orders Table */}
      <div className="bg-white rounded-xl border border-stone-200 overflow-hidden shadow-xs">
        {filteredOrders.length === 0 ? (
          <div className="p-12 text-center text-stone-500 space-y-2">
            <p className="font-bold text-stone-800">لا توجد طلبات تطابق بحثك حالياً</p>
            <p className="text-xs">جرب تغيير كلمات البحث أو تغيير حالة الفلتر.</p>
          </div>
        ) : (
          <div className="overflow-x-auto">
            <table className="w-full text-right text-xs">
              <thead className="bg-stone-50 border-b border-stone-200 text-stone-500 font-semibold uppercase">
                <tr>
                  <th className="py-3 px-4">رقم الطلب والتاريخ</th>
                  <th className="py-3 px-4">بيانات العميل</th>
                  <th className="py-3 px-4">المنتجات والخيارات (المقاس / اللون)</th>
                  <th className="py-3 px-4">المبلغ الكلي (COD)</th>
                  <th className="py-3 px-4">حالة الطلب</th>
                  <th className="py-3 px-4">Google Sheets</th>
                  <th className="py-3 px-4 text-center">الإجراءات</th>
                </tr>
              </thead>
              <tbody className="divide-y divide-stone-200">
                {filteredOrders.map((order) => (
                  <tr key={order.id} className="hover:bg-stone-50/80 transition-colors">
                    {/* Order ID & Date */}
                    <td className="py-3.5 px-4 align-top">
                      <div className="font-mono font-bold text-stone-900 text-sm">
                        {order.orderNumber}
                      </div>
                      <div className="flex items-center gap-1 text-[11px] text-stone-400 mt-0.5">
                        <Calendar className="w-3 h-3" />
                        <span>
                          {(() => {
                            try {
                              const d = new Date(order.createdAt);
                              if (!isNaN(d.getTime())) {
                                return d.toLocaleDateString('ar-MA', {
                                  month: 'short',
                                  day: 'numeric',
                                  hour: '2-digit',
                                  minute: '2-digit',
                                });
                              }
                            } catch {
                              // fallback
                            }
                            return order.createdAt;
                          })()}
                        </span>
                      </div>
                    </td>

                    {/* Customer Info */}
                    <td className="py-3.5 px-4 align-top">
                      <div className="font-bold text-stone-900">{order.customerName}</div>
                      <div className="flex items-center gap-1 text-stone-600 mt-0.5" dir="ltr">
                        <Phone className="w-3 h-3 text-stone-400" />
                        <span className="font-mono text-[11px]">{order.phone}</span>
                      </div>
                      <div className="flex items-start gap-1 text-stone-500 text-[11px] mt-1 max-w-[200px]">
                        <MapPin className="w-3 h-3 text-stone-400 shrink-0 mt-0.5" />
                        <span className="truncate" title={`${order.city} - ${order.address}`}>
                          {order.city} - {order.address}
                        </span>
                      </div>
                      {order.notes && (
                        <div className="text-[10px] text-amber-700 bg-amber-50 p-1 rounded mt-1">
                          ملاحظة: {order.notes}
                        </div>
                      )}
                    </td>

                    {/* Items & Options */}
                    <td className="py-3.5 px-4 align-top max-w-[260px]">
                      <div className="space-y-1.5">
                        {order.items.map((item, idx) => (
                          <div key={idx} className="bg-stone-50 p-1.5 rounded border border-stone-200/60">
                            <div className="font-semibold text-stone-900 line-clamp-1">{item.productName}</div>
                            <div className="flex items-center gap-2 text-[11px] text-stone-600 mt-0.5">
                              <span className="bg-stone-200/80 px-1 rounded font-mono font-bold">
                                مقاس: {item.selectedSize}
                              </span>
                              <span>·</span>
                              <span>لون: {item.selectedColor}</span>
                              <span>·</span>
                              <span className="font-bold font-mono">الكمية: {item.quantity}</span>
                            </div>
                          </div>
                        ))}
                      </div>
                    </td>

                    {/* Total Amount */}
                    <td className="py-3.5 px-4 align-top">
                      <div className="font-mono font-extrabold text-stone-900 text-sm tabular-nums">
                        {order.totalPrice} {currency}
                      </div>
                      <div className="text-[10px] text-stone-400">
                        {order.shippingCost === 0 ? 'شحن مجاني' : `شحن: ${order.shippingCost} ${currency}`}
                      </div>
                    </td>

                    {/* Order Status Selector */}
                    <td className="py-3.5 px-4 align-top">
                      <div className="space-y-1.5">
                        <div>{getStatusBadge(order.status)}</div>
                        <select
                          value={order.status}
                          onChange={(e) => onUpdateOrderStatus(order.id, e.target.value as OrderStatus)}
                          className="w-full text-[11px] px-2 py-1 bg-white border border-stone-300 rounded font-medium text-stone-700 cursor-pointer"
                        >
                          <option value="new">جديد</option>
                          <option value="confirmed">تم التأكيد</option>
                          <option value="shipping">قيد الشحن</option>
                          <option value="delivered">تم التسليم</option>
                          <option value="cancelled">ملغى</option>
                        </select>
                      </div>
                    </td>

                    {/* Google Sheets Sync status */}
                    <td className="py-3.5 px-4 align-top">
                      <div className="flex flex-col gap-1">
                        <span
                          className={`inline-flex items-center gap-1 text-[11px] font-semibold ${
                            order.syncedToGoogleSheets ? 'text-emerald-700' : 'text-stone-400'
                          }`}
                        >
                          <span
                            className={`w-2 h-2 rounded-full ${
                              order.syncedToGoogleSheets ? 'bg-emerald-500' : 'bg-stone-300'
                            }`}
                          />
                          {order.syncedToGoogleSheets ? 'متزامن' : 'غير متزامن'}
                        </span>

                        <button
                          onClick={() => handleManualSync(order)}
                          disabled={syncingOrderId === order.id}
                          className="text-[10px] text-stone-600 hover:text-stone-900 underline flex items-center gap-1 cursor-pointer"
                        >
                          <RefreshCw
                            className={`w-2.5 h-2.5 ${syncingOrderId === order.id ? 'animate-spin' : ''}`}
                          />
                          <span>مزامنة لـ Sheet</span>
                        </button>
                      </div>
                    </td>

                    {/* Actions */}
                    <td className="py-3.5 px-4 align-top text-center">
                      <button
                        onClick={() => handleOpenCustomerWhatsApp(order)}
                        className="inline-flex items-center gap-1 px-3 py-1.5 bg-[#25D366] hover:bg-[#1da851] text-white rounded-lg font-bold text-[11px] transition-colors cursor-pointer shadow-2xs whitespace-nowrap"
                        title="مراسلة وتأكيد الطلب مع العميل على واتساب"
                      >
                        <MessageCircle className="w-3.5 h-3.5 fill-white" />
                        <span>واتساب العميل</span>
                      </button>
                    </td>
                  </tr>
                ))}
              </tbody>
            </table>
          </div>
        )}
      </div>
    </div>
  );
};
