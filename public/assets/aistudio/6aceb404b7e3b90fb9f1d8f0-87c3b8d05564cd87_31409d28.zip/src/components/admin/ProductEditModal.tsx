import React, { useState, useEffect } from 'react';
import { Product, ProductOptionColor } from '../../types';
import { apiService } from '../../services/apiService';
import { X, Plus, Trash2, Upload, Image as ImageIcon, Sparkles, Loader2 } from 'lucide-react';

interface ProductEditModalProps {
  product: Product | null;
  isOpen: boolean;
  onClose: () => void;
  onSave: (product: Product) => void;
}

export const ProductEditModal: React.FC<ProductEditModalProps> = ({
  product,
  isOpen,
  onClose,
  onSave,
}) => {
  if (!isOpen) return null;

  const isEditing = !!product;

  const [name, setName] = useState(product?.name || '');
  const [price, setPrice] = useState(product?.price || 250);
  const [originalPrice, setOriginalPrice] = useState(product?.originalPrice || 350);
  const [category, setCategory] = useState(product?.category || 'ملابس');
  const [badge, setBadge] = useState(product?.badge || '');
  const [description, setDescription] = useState(product?.description || '');
  const [inStock, setInStock] = useState(product ? product.inStock : true);
  const [imageSvgType, setImageSvgType] = useState<Product['imageSvgType']>(
    product?.imageSvgType || 'survette'
  );

  const [isUploadingMain, setIsUploadingMain] = useState(false);
  const [isUploadingGallery, setIsUploadingGallery] = useState(false);

  // Main Image (from device or URL)
  const [customImage, setCustomImage] = useState(product?.customImage || '');

  // Gallery Images (from device or URL)
  const [galleryImages, setGalleryImages] = useState<string[]>(product?.galleryImages || []);

  // Sizes array
  const [sizes, setSizes] = useState<string[]>(product?.sizes || ['S', 'M', 'L', 'XL', '2XL', '3XL']);
  const [newSize, setNewSize] = useState('');

  // Colors array
  const [colors, setColors] = useState<ProductOptionColor[]>(
    product?.colors || [
      { name: 'Noir (أسود)', hex: '#1E1E24' },
      { name: 'Grona (عنابي)', hex: '#6A1B29' },
      { name: 'Ziti (أخضر زيتي)', hex: '#4D5638' },
      { name: 'Bleu marine (كحلي)', hex: '#1E293B' },
      { name: 'Beige (بيج)', hex: '#D9CBB7' },
    ]
  );
  const [newColorName, setNewColorName] = useState('');
  const [newColorHex, setNewColorHex] = useState('#2563EB');

  // Fabrics array
  const [fabrics, setFabrics] = useState<string[]>(
    product?.fabrics || ['Montonie Lycra']
  );
  const [newFabric, setNewFabric] = useState('');

  // Bundle Offer (Optional, not forced)
  const [bundleEnabled, setBundleEnabled] = useState(product?.bundleOffer?.enabled ?? true);
  const [bundleStickerText, setBundleStickerText] = useState(
    product?.bundleOffer?.stickerText || 'عرض قطعتين'
  );
  const [bundleLabel, setBundleLabel] = useState(
    product?.bundleOffer?.label || 'عرض قطعتين (توفير خاص + توصيل مجاني)'
  );
  const [bundlePrice, setBundlePrice] = useState(
    product?.bundleOffer?.price || Math.round((product?.price || price) * 1.75)
  );
  const [bundleOriginalPrice, setBundleOriginalPrice] = useState(
    product?.bundleOffer?.originalPrice ||
      Math.round(((product?.originalPrice || originalPrice) || price * 1.4) * 2)
  );

  // Sync state whenever editing product changes or modal is opened
  useEffect(() => {
    if (product) {
      setName(product.name || '');
      setPrice(product.price);
      setOriginalPrice(product.originalPrice || Math.round(product.price * 1.3));
      setCategory(product.category || 'أطقم وسورفيتات');
      setBadge(product.badge || '');
      setDescription(product.description || '');
      setInStock(product.inStock !== false);
      setImageSvgType(product.imageSvgType || 'survette');
      setCustomImage(product.customImage || '');
      setGalleryImages(product.galleryImages || []);
      setSizes(product.sizes?.length ? product.sizes : ['S', 'M', 'L', 'XL', '2XL', '3XL']);
      setColors(product.colors?.length ? product.colors : []);
      setFabrics(product.fabrics?.length ? product.fabrics : ['Montonie Lycra']);
      if (product.bundleOffer) {
        setBundleEnabled(product.bundleOffer.enabled);
        setBundleStickerText(product.bundleOffer.stickerText || '');
        setBundleLabel(product.bundleOffer.label || 'عرض قطعتين (توفير خاص + توصيل مجاني)');
        setBundlePrice(product.bundleOffer.price);
        setBundleOriginalPrice(product.bundleOffer.originalPrice || 0);
      }
    }
  }, [product, isOpen]);

  // Helper to optimize and compress uploaded images to prevent browser storage overload
  const compressImageFile = (file: File, maxDim = 1200, quality = 0.85): Promise<string> => {
    return new Promise((resolve) => {
      const reader = new FileReader();
      reader.onload = (e) => {
        const img = new Image();
        img.onload = () => {
          let { width, height } = img;
          if (width > maxDim || height > maxDim) {
            if (width > height) {
              height = Math.round((height * maxDim) / width);
              width = maxDim;
            } else {
              width = Math.round((width * maxDim) / height);
              height = maxDim;
            }
          }
          const canvas = document.createElement('canvas');
          canvas.width = width;
          canvas.height = height;
          const ctx = canvas.getContext('2d');
          if (ctx) {
            ctx.drawImage(img, 0, 0, width, height);
            resolve(canvas.toDataURL('image/jpeg', quality));
          } else {
            resolve(e.target?.result as string);
          }
        };
        img.onerror = () => resolve(e.target?.result as string);
        img.src = e.target?.result as string;
      };
      reader.onerror = () => resolve('');
      reader.readAsDataURL(file);
    });
  };

  // Handlers for image upload from device
  const handleMainImageFileUpload = async (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (file) {
      setIsUploadingMain(true);
      try {
        const compressed = await compressImageFile(file);
        if (compressed) {
          const serverUrl = await apiService.uploadImage(compressed);
          setCustomImage(serverUrl);
        }
      } catch (err) {
        console.error('Failed to upload main image:', err);
      } finally {
        setIsUploadingMain(false);
      }
    }
  };

  const handleGalleryImagesUpload = async (e: React.ChangeEvent<HTMLInputElement>) => {
    const files = e.target.files;
    if (files && files.length > 0) {
      setIsUploadingGallery(true);
      try {
        const promises = Array.from(files).map((f) => compressImageFile(f));
        const compressedList = await Promise.all(promises);
        const uploadPromises = compressedList.filter(Boolean).map((data) => apiService.uploadImage(data));
        const uploadedUrls = await Promise.all(uploadPromises);
        const valid = uploadedUrls.filter(Boolean);
        setGalleryImages((prev) => [...prev, ...valid]);
      } catch (err) {
        console.error('Failed to upload gallery images:', err);
      } finally {
        setIsUploadingGallery(false);
      }
    }
  };

  const handleRemoveGalleryImage = (index: number) => {
    setGalleryImages((prev) => prev.filter((_, i) => i !== index));
  };

  const handleAddSize = () => {
    if (newSize.trim() && !sizes.includes(newSize.trim())) {
      setSizes([...sizes, newSize.trim()]);
      setNewSize('');
    }
  };

  const handleRemoveSize = (sizeToRemove: string) => {
    setSizes(sizes.filter((s) => s !== sizeToRemove));
  };

  const handleAddColor = () => {
    if (newColorName.trim()) {
      setColors([...colors, { name: newColorName.trim(), hex: newColorHex }]);
      setNewColorName('');
    }
  };

  const handleRemoveColor = (index: number) => {
    setColors(colors.filter((_, i) => i !== index));
  };

  const handleAddFabric = () => {
    if (newFabric.trim() && !fabrics.includes(newFabric.trim())) {
      setFabrics([...fabrics, newFabric.trim()]);
      setNewFabric('');
    }
  };

  const handleRemoveFabric = (fabricToRemove: string) => {
    setFabrics(fabrics.filter((f) => f !== fabricToRemove));
  };

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();

    const updatedProduct: Product = {
      id: product?.id || `prod-${Date.now()}`,
      name: name.trim(),
      slug: product?.slug || name.toLowerCase().replace(/\s+/g, '-'),
      price: Number(price),
      originalPrice: originalPrice ? Number(originalPrice) : undefined,
      category: category.trim(),
      description: description.trim(),
      features: product?.features || [
        'قماش Montonie Lycra تركي ممتاز مريح وناعم ومطاطي',
        'سحاب أمامي أنيق مع حلقة معدنية دائرية عصرية',
        'غطاء رأس مريح (Capuche) مع أربطة متناسقة',
        'أكمام بأزرار عملية لإمكانية التشمير بسهولة',
        'سروال فضفاض بخصر مطاطي مريح للغاية لجميع المقاسات',
        'مناسبة للاستعمال اليومي، الخروج، السفر والراحة التامة',
      ],
      inStock,
      badge: badge.trim() || undefined,
      rating: product?.rating || 4.97,
      reviewsCount: product?.reviewsCount || 184,
      sizes: sizes.length > 0 ? sizes : (product?.sizes || ['S', 'M', 'L', 'XL', '2XL', '3XL']),
      colors: colors.length > 0 ? colors : (product?.colors || []),
      fabrics: fabrics.length > 0 ? fabrics : (product?.fabrics || ['Montonie Lycra']),
      imageSvgType: imageSvgType || product?.imageSvgType || 'survette',
      customImage: customImage.trim() || product?.customImage || undefined,
      galleryImages: galleryImages.length > 0 ? galleryImages : (product?.galleryImages || undefined),
      bundleOffer: {
        enabled: bundleEnabled,
        stickerText: bundleStickerText.trim(),
        label: bundleLabel.trim() || 'عرض قطعتين (توفير خاص + توصيل مجاني)',
        price: Number(bundlePrice),
        originalPrice: bundleOriginalPrice ? Number(bundleOriginalPrice) : undefined,
      },
    };

    onSave(updatedProduct);
    onClose();
  };

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-3 sm:p-4 bg-black/60 backdrop-blur-xs overflow-y-auto font-['Cairo',sans-serif]">
      <div className="relative w-full max-w-2xl bg-white rounded-2xl shadow-2xl border border-stone-200 overflow-hidden my-6 text-right">
        {/* Header */}
        <div className="flex items-center justify-between px-6 py-4 border-b border-stone-200 bg-stone-50">
          <button
            onClick={onClose}
            className="p-1 rounded-lg text-stone-500 hover:text-black hover:bg-stone-200 transition-colors cursor-pointer"
          >
            <X className="w-5 h-5" />
          </button>
          <h3 className="text-base font-bold text-stone-900">
            {isEditing ? 'تعديل بيانات المنتج وصوره' : 'إضافة منتج جديد إلى المتجر'}
          </h3>
        </div>

        {/* Form Body */}
        <form onSubmit={handleSubmit} className="p-6 space-y-5 max-h-[80vh] overflow-y-auto">
          {/* Product Name */}
          <div>
            <label className="block text-xs font-bold text-stone-800 mb-1">اسم المنتج *</label>
            <input
              type="text"
              required
              placeholder="مثال: فستان سهرة مخملي"
              value={name}
              onChange={(e) => setName(e.target.value)}
              className="w-full px-3 py-2 border border-stone-300 rounded-lg text-xs focus:ring-1 focus:ring-stone-900 text-right"
            />
          </div>

          {/* Pricing */}
          <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
            <div>
              <label className="block text-xs font-bold text-stone-800 mb-1">سعر البيع الحالي *</label>
              <input
                type="number"
                required
                min="1"
                value={price}
                onChange={(e) => setPrice(Number(e.target.value))}
                className="w-full px-3 py-2 border border-stone-300 rounded-lg text-xs focus:ring-1 focus:ring-stone-900 font-mono text-right"
              />
            </div>

            <div>
              <label className="block text-xs font-bold text-stone-800 mb-1">السعر الأصلي قبل الخصم (اختياري)</label>
              <input
                type="number"
                min="0"
                value={originalPrice}
                onChange={(e) => setOriginalPrice(Number(e.target.value))}
                className="w-full px-3 py-2 border border-stone-300 rounded-lg text-xs focus:ring-1 focus:ring-stone-900 font-mono text-right"
              />
            </div>
          </div>

          {/* Section: Upload Main Image from Device */}
          <div className="border border-stone-200 bg-stone-50/70 rounded-xl p-4 space-y-3">
            <div className="flex items-center justify-between">
              <label className="block text-xs font-bold text-stone-900 flex items-center gap-1.5">
                <ImageIcon className="w-4 h-4 text-stone-700" />
                <span>الصورة الرئيسية للمنتج (رفع من جهازك)</span>
              </label>
              {customImage && (
                <button
                  type="button"
                  onClick={() => setCustomImage('')}
                  className="text-xs text-rose-600 hover:underline font-bold"
                >
                  حذف الصورة
                </button>
              )}
            </div>

            <div className="flex flex-col sm:flex-row items-center gap-3">
              {/* File Upload Button */}
              <label className="w-full sm:w-auto flex items-center justify-center gap-2 px-4 py-2.5 bg-stone-900 hover:bg-black text-white rounded-xl text-xs font-bold cursor-pointer transition-colors shadow-2xs">
                {isUploadingMain ? (
                  <>
                    <Loader2 className="w-4 h-4 animate-spin text-teal-400" />
                    <span>جاري رفع ومعالجة الصورة...</span>
                  </>
                ) : (
                  <>
                    <Upload className="w-4 h-4" />
                    <span>اختر صورة من جهازك (كمبيوتر / هاتف)</span>
                  </>
                )}
                <input
                  type="file"
                  accept="image/*"
                  disabled={isUploadingMain}
                  onChange={handleMainImageFileUpload}
                  className="hidden"
                />
              </label>

              <span className="text-xs text-stone-400">أو رابط صورة:</span>

              <input
                type="url"
                placeholder="https://example.com/image.jpg"
                value={customImage}
                onChange={(e) => setCustomImage(e.target.value)}
                className="flex-1 w-full px-3 py-2 border border-stone-300 rounded-lg text-xs focus:ring-1 focus:ring-stone-900 text-left font-mono"
                dir="ltr"
              />
            </div>

            {/* Main Image Preview */}
            {customImage && (
              <div className="relative w-28 h-28 rounded-xl overflow-hidden border-2 border-stone-300 bg-white shadow-xs mx-auto sm:mx-0">
                <img
                  src={customImage}
                  alt="معاينة صورة المنتج"
                  className="w-full h-full object-cover"
                />
              </div>
            )}
          </div>

          {/* Section: Additional Gallery Images (Upload from Device) */}
          <div className="border border-stone-200 bg-stone-50/70 rounded-xl p-4 space-y-3">
            <div className="flex items-center justify-between">
              <div>
                <h4 className="text-xs font-bold text-stone-900">
                  صور إضافية لمعرض المنتج (تظهر كمصغرات في صفحة المنتج)
                </h4>
                <p className="text-[11px] text-stone-500">
                  يمكنك رفع عدة صور لزوايا مختلفة للمنتج من جهازك
                </p>
              </div>
              <label className="flex items-center gap-1.5 px-3 py-1.5 bg-stone-800 hover:bg-black text-white rounded-lg text-xs font-bold cursor-pointer transition-colors">
                {isUploadingGallery ? (
                  <>
                    <Loader2 className="w-3.5 h-3.5 animate-spin text-teal-400" />
                    <span>جاري الرفع...</span>
                  </>
                ) : (
                  <>
                    <Plus className="w-3.5 h-3.5" />
                    <span>إضافة صور</span>
                  </>
                )}
                <input
                  type="file"
                  accept="image/*"
                  multiple
                  disabled={isUploadingGallery}
                  onChange={handleGalleryImagesUpload}
                  className="hidden"
                />
              </label>
            </div>

            {/* Gallery Thumbnails List */}
            {galleryImages.length > 0 && (
              <div className="flex flex-wrap items-center gap-2 pt-1">
                {galleryImages.map((img, idx) => (
                  <div key={idx} className="relative w-16 h-16 rounded-lg overflow-hidden border border-stone-300 bg-white group">
                    <img src={img} alt={`مصغرة ${idx + 1}`} className="w-full h-full object-cover" />
                    <button
                      type="button"
                      onClick={() => handleRemoveGalleryImage(idx)}
                      className="absolute inset-0 bg-black/60 text-white opacity-0 group-hover:opacity-100 flex items-center justify-center transition-opacity cursor-pointer"
                      title="حذف هذه الصورة"
                    >
                      <Trash2 className="w-4 h-4 text-rose-300" />
                    </button>
                  </div>
                ))}
              </div>
            )}
          </div>

          {/* Optional Badge */}
          <div>
            <label className="block text-xs font-bold text-stone-800 mb-1">
              شارة نصية مخصصة فوق المنتج (اختياري، اتركه فارغاً إذا كنت لا ترغب بشارة)
            </label>
            <input
              type="text"
              placeholder="مثال: الأكثر طلباً، جديد، تخفيض 30%..."
              value={badge}
              onChange={(e) => setBadge(e.target.value)}
              className="w-full px-3 py-2 border border-stone-300 rounded-lg text-xs focus:ring-1 focus:ring-stone-900 text-right"
            />
          </div>

          {/* Description */}
          <div>
            <label className="block text-xs font-bold text-stone-800 mb-1">وصف المنتج</label>
            <textarea
              rows={2}
              placeholder="وصف تفصيلي لمزايا القطعة والخامات..."
              value={description}
              onChange={(e) => setDescription(e.target.value)}
              className="w-full px-3 py-2 border border-stone-300 rounded-lg text-xs focus:ring-1 focus:ring-stone-900 text-right"
            />
          </div>

          {/* Fallback Vector type if no image is uploaded */}
          <div>
            <label className="block text-xs font-bold text-stone-800 mb-1">
              شكل الرسمة التوضيحية (يستخدم فقط كبديل إذا لم ترفع صورة)
            </label>
            <select
              value={imageSvgType}
              onChange={(e) => setImageSvgType(e.target.value as any)}
              className="w-full px-3 py-2 border border-stone-300 rounded-lg text-xs bg-white text-stone-800"
            >
              <option value="survette">سورفيت أميليا / طقم رياضي محتشم (Survette)</option>
              <option value="caftan">قفطان</option>
              <option value="djellaba">جلابة</option>
              <option value="blazer">بليزر / سترة رسمية</option>
              <option value="dress">فستان سهرة / أنيق</option>
              <option value="coat">معطف شتوي / صوف</option>
              <option value="abaya">عباية مطرزة</option>
              <option value="shirt">قميص ناصع</option>
              <option value="suit">بدلة رسمية كاملة</option>
            </select>
          </div>

          {/* Sizes Options */}
          <div className="border border-stone-200 rounded-xl p-3.5 bg-stone-50/50 space-y-2">
            <label className="block text-xs font-bold text-stone-900">خيارات المقاسات:</label>
            <div className="flex flex-wrap items-center gap-1.5">
              {sizes.map((s) => (
                <span
                  key={s}
                  className="inline-flex items-center gap-1 bg-white border border-stone-300 px-2.5 py-1 rounded text-xs font-bold font-mono"
                >
                  <span>{s}</span>
                  <button
                    type="button"
                    onClick={() => handleRemoveSize(s)}
                    className="text-stone-400 hover:text-rose-600 cursor-pointer"
                  >
                    ×
                  </button>
                </span>
              ))}
            </div>
            <div className="flex items-center gap-2 pt-1">
              <input
                type="text"
                placeholder="أضف مقاس جديد (مثلاً: XXL)"
                value={newSize}
                onChange={(e) => setNewSize(e.target.value)}
                className="flex-1 px-3 py-1.5 border border-stone-300 rounded-lg text-xs bg-white text-right"
              />
              <button
                type="button"
                onClick={handleAddSize}
                className="px-3 py-1.5 bg-stone-900 text-white rounded-lg text-xs font-bold cursor-pointer"
              >
                إضافة مقاس
              </button>
            </div>
          </div>

          {/* Colors Options */}
          <div className="border border-stone-200 rounded-xl p-3.5 bg-stone-50/50 space-y-2">
            <label className="block text-xs font-bold text-stone-900">خيارات الألوان:</label>
            <div className="flex flex-wrap items-center gap-2">
              {colors.map((c, i) => (
                <span
                  key={i}
                  className="inline-flex items-center gap-1.5 bg-white border border-stone-300 px-2.5 py-1 rounded text-xs font-medium"
                >
                  <span
                    className="w-3.5 h-3.5 rounded-full border border-stone-300"
                    style={{ backgroundColor: c.hex }}
                  />
                  <span>{c.name}</span>
                  <button
                    type="button"
                    onClick={() => handleRemoveColor(i)}
                    className="text-stone-400 hover:text-rose-600 cursor-pointer mr-1"
                  >
                    ×
                  </button>
                </span>
              ))}
            </div>
            <div className="flex items-center gap-2 pt-1">
              <input
                type="text"
                placeholder="اسم اللون (مثلاً: كحلي داكن)"
                value={newColorName}
                onChange={(e) => setNewColorName(e.target.value)}
                className="flex-1 px-3 py-1.5 border border-stone-300 rounded-lg text-xs bg-white text-right"
              />
              <input
                type="color"
                value={newColorHex}
                onChange={(e) => setNewColorHex(e.target.value)}
                className="w-8 h-8 rounded border border-stone-300 p-0 cursor-pointer"
                title="اختر درجة اللون"
              />
              <button
                type="button"
                onClick={handleAddColor}
                className="px-3 py-1.5 bg-stone-900 text-white rounded-lg text-xs font-bold cursor-pointer"
              >
                إضافة لون
              </button>
            </div>
          </div>

          {/* Optional Bundle Offer Customizer */}
          <div className="border border-stone-200 bg-stone-50/60 rounded-xl p-4 space-y-3">
            <div className="flex items-center justify-between border-b border-stone-200 pb-2">
              <div>
                <h4 className="text-xs font-bold text-stone-900 flex items-center gap-1.5">
                  <Sparkles className="w-3.5 h-3.5 text-amber-600" />
                  <span>تفعيل باقة عرض قطعتين (اختياري)</span>
                </h4>
                <p className="text-[11px] text-stone-500">
                  يتيح للزبون خيار طلب قطعتين بسعر مخفض وشحن مجاني
                </p>
              </div>
              <label className="flex items-center gap-2 cursor-pointer">
                <span className="text-xs font-bold text-stone-800">تفعيل:</span>
                <input
                  type="checkbox"
                  checked={bundleEnabled}
                  onChange={(e) => setBundleEnabled(e.target.checked)}
                  className="w-4 h-4 rounded text-stone-900 focus:ring-stone-900 cursor-pointer"
                />
              </label>
            </div>

            {bundleEnabled && (
              <div className="grid grid-cols-1 sm:grid-cols-2 gap-3 pt-1">
                <div>
                  <label className="block text-[11px] font-bold text-stone-800 mb-1">
                    تسمية الباقة
                  </label>
                  <input
                    type="text"
                    value={bundleLabel}
                    onChange={(e) => setBundleLabel(e.target.value)}
                    placeholder="مثال: عرض قطعتين (توفير خاص)"
                    className="w-full px-3 py-2 border border-stone-300 rounded-lg text-xs bg-white text-right"
                  />
                </div>

                <div>
                  <label className="block text-[11px] font-bold text-stone-800 mb-1">
                    سعر الباقة المخفض *
                  </label>
                  <input
                    type="number"
                    min="1"
                    value={bundlePrice}
                    onChange={(e) => setBundlePrice(Number(e.target.value))}
                    className="w-full px-3 py-2 border border-stone-300 rounded-lg text-xs bg-white font-mono text-right"
                  />
                </div>

                <div>
                  <label className="block text-[11px] font-bold text-stone-800 mb-1">
                    السعر الأصلي للباقة قبل الخصم
                  </label>
                  <input
                    type="number"
                    min="0"
                    value={bundleOriginalPrice}
                    onChange={(e) => setBundleOriginalPrice(Number(e.target.value))}
                    className="w-full px-3 py-2 border border-stone-300 rounded-lg text-xs bg-white font-mono text-right"
                  />
                </div>

                <div>
                  <label className="block text-[11px] font-bold text-stone-800 mb-1">
                    شارة فوق الباقة (اختياري)
                  </label>
                  <input
                    type="text"
                    value={bundleStickerText}
                    onChange={(e) => setBundleStickerText(e.target.value)}
                    placeholder="اختياري (اتركه فارغاً إن لم ترغب بشارة)"
                    className="w-full px-3 py-2 border border-stone-300 rounded-lg text-xs bg-white text-right"
                  />
                </div>
              </div>
            )}
          </div>

          {/* In stock toggle */}
          <div className="flex items-center justify-between pt-2">
            <span className="text-xs font-bold text-stone-800">حالة توفر المنتج في المخزون</span>
            <label className="relative inline-flex items-center cursor-pointer">
              <input
                type="checkbox"
                checked={inStock}
                onChange={(e) => setInStock(e.target.checked)}
                className="sr-only peer"
              />
              <div className="w-11 h-6 bg-stone-200 peer-focus:outline-none rounded-full peer peer-checked:after:translate-x-full peer-checked:after:border-white after:content-[''] after:absolute after:top-[2px] after:left-[2px] after:bg-white after:border-stone-300 after:border after:rounded-full after:h-5 after:w-5 after:transition-all peer-checked:bg-emerald-600"></div>
            </label>
          </div>

          {/* Footer Save Button */}
          <div className="pt-4 border-t border-stone-200 flex items-center justify-end gap-3">
            <button
              type="button"
              onClick={onClose}
              className="px-4 py-2 border border-stone-300 rounded-lg text-xs font-semibold text-stone-700 hover:bg-stone-50 cursor-pointer"
            >
              إلغاء
            </button>
            <button
              type="submit"
              className="px-6 py-2 bg-stone-900 hover:bg-black text-white rounded-lg text-xs font-bold cursor-pointer transition-colors shadow-xs"
            >
              حفظ المنتج
            </button>
          </div>
        </form>
      </div>
    </div>
  );
};
