import React, { useState } from 'react';
import { StoreSettings } from '../../types';
import { Save, Store, Megaphone, MessageCircle, Truck, Sparkles, Check, Eye, EyeOff } from 'lucide-react';

interface StoreSettingsTabProps {
  settings: StoreSettings;
  onSave: (settings: StoreSettings) => void;
}

export const StoreSettingsTab: React.FC<StoreSettingsTabProps> = ({ settings, onSave }) => {
  const [localSettings, setLocalSettings] = useState<StoreSettings>({ ...settings });
  const [isSaved, setIsSaved] = useState(false);
  const [showPassword, setShowPassword] = useState(false);

  const handleChange = <K extends keyof StoreSettings>(key: K, value: StoreSettings[K]) => {
    setLocalSettings((prev) => ({ ...prev, [key]: value }));
  };

  const handleAnnouncementChange = (field: string, value: any) => {
    setLocalSettings((prev) => ({
      ...prev,
      announcement: {
        ...prev.announcement,
        [field]: value,
      },
    }));
  };

  const handleWhatsAppChange = (field: string, value: any) => {
    setLocalSettings((prev) => ({
      ...prev,
      whatsapp: {
        ...prev.whatsapp,
        [field]: value,
      },
    }));
  };

  const handleHomeBannerChange = (field: string, value: any) => {
    setLocalSettings((prev) => ({
      ...prev,
      homeBanner: {
        ...prev.homeBanner,
        [field]: value,
      },
    }));
  };

  const handleBannerImageUpload = (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (file) {
      const reader = new FileReader();
      reader.onload = () => {
        if (typeof reader.result === 'string') {
          handleHomeBannerChange('imageUrl', reader.result);
        }
      };
      reader.readAsDataURL(file);
    }
  };

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    onSave(localSettings);
    setIsSaved(true);
    setTimeout(() => setIsSaved(false), 2500);
  };

  return (
    <form onSubmit={handleSubmit} className="space-y-8 text-right max-w-4xl">
      {/* Top action confirmation */}
      <div className="flex items-center justify-between bg-white p-4 rounded-xl border border-stone-200">
        <div>
          <h3 className="text-sm font-bold text-stone-900">تخصيص الهوية والشريط العلوي والواتساب</h3>
          <p className="text-xs text-stone-500">عدل إعدادات المتجر والعروض الترويجية وستظهر فوراً في الواجهة</p>
        </div>
        <button
          type="submit"
          className="flex items-center gap-2 px-5 py-2.5 bg-stone-900 hover:bg-black text-white text-xs font-bold rounded-lg transition-colors cursor-pointer shadow-xs"
        >
          {isSaved ? <Check className="w-4 h-4 text-emerald-400" /> : <Save className="w-4 h-4" />}
          <span>{isSaved ? 'تم حفظ التعديلات!' : 'حفظ الإعدادات'}</span>
        </button>
      </div>

      {/* 1. General Brand & Currency */}
      <div className="bg-white p-6 rounded-2xl border border-stone-200 space-y-4">
        <h4 className="text-sm font-bold text-stone-900 flex items-center gap-2 border-b border-stone-100 pb-3">
          <Store className="w-4 h-4 text-stone-700" />
          <span>اسم المتجر والعملة والشحن</span>
        </h4>

        <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
          <div>
            <label className="block text-xs font-bold text-stone-800 mb-1">اسم المتجر *</label>
            <input
              type="text"
              required
              value={localSettings.storeName}
              onChange={(e) => handleChange('storeName', e.target.value)}
              className="w-full px-3 py-2 border border-stone-300 rounded-lg text-xs font-bold focus:ring-1 focus:ring-stone-900 text-right"
            />
          </div>

          <div>
            <label className="block text-xs font-bold text-stone-800 mb-1">شعار / وصف المتجر</label>
            <input
              type="text"
              value={localSettings.tagline}
              onChange={(e) => handleChange('tagline', e.target.value)}
              className="w-full px-3 py-2 border border-stone-300 rounded-lg text-xs focus:ring-1 focus:ring-stone-900 text-right"
            />
          </div>

          <div>
            <label className="block text-xs font-bold text-stone-800 mb-1">عملة المتجر</label>
            <select
              value={localSettings.currency}
              onChange={(e) => handleChange('currency', e.target.value)}
              className="w-full px-3 py-2 border border-stone-300 rounded-lg text-xs font-bold bg-white text-stone-800"
            >
              <option value="ر.س">ريال سعودي (ر.س)</option>
              <option value="د.إ">درهم إماراتي (د.إ)</option>
              <option value="د.م">درهم مغربي (د.م)</option>
              <option value="د.ج">دينار جزائري (د.ج)</option>
              <option value="ج.م">جنيه مصري (ج.م)</option>
              <option value="د.ك">دينار كويتي (د.ك)</option>
              <option value="د.ب">دينار بحريني (د.ب)</option>
              <option value="ر.ع">ريال عماني (ر.ع)</option>
              <option value="ر.ق">ريال قطري (ر.ق)</option>
              <option value="$">دولار أمريكي ($)</option>
              <option value="€">يورو (€)</option>
            </select>
          </div>

          <div>
            <label className="block text-xs font-bold text-stone-800 mb-1">حد الشحن المجاني</label>
            <div className="flex items-center gap-2">
              <input
                type="number"
                min="0"
                value={localSettings.freeShippingThreshold}
                onChange={(e) => handleChange('freeShippingThreshold', Number(e.target.value))}
                className="w-full px-3 py-2 border border-stone-300 rounded-lg text-xs font-mono font-bold focus:ring-1 focus:ring-stone-900 text-right"
              />
              <span className="text-xs text-stone-500 font-mono shrink-0">{localSettings.currency}</span>
            </div>
          </div>

          <div>
            <label className="block text-xs font-bold text-stone-800 mb-1">سعر الشحن الافتراضي</label>
            <div className="flex items-center gap-2">
              <input
                type="number"
                min="0"
                value={localSettings.standardShippingCost}
                onChange={(e) => handleChange('standardShippingCost', Number(e.target.value))}
                className="w-full px-3 py-2 border border-stone-300 rounded-lg text-xs font-mono font-bold focus:ring-1 focus:ring-stone-900 text-right"
              />
              <span className="text-xs text-stone-500 font-mono shrink-0">{localSettings.currency}</span>
            </div>
          </div>
        </div>
      </div>

      {/* 2. Top Announcement Bar */}
      <div className="bg-white p-6 rounded-2xl border border-stone-200 space-y-4">
        <div className="flex items-center justify-between border-b border-stone-100 pb-3">
          <h4 className="text-sm font-bold text-stone-900 flex items-center gap-2">
            <Megaphone className="w-4 h-4 text-stone-700" />
            <span>شريط العروض والإعلانات في الأعلى (Top Announcement Bar)</span>
          </h4>

          <label className="flex items-center gap-2 cursor-pointer">
            <span className="text-xs text-stone-600 font-semibold">تفعيل الشريط:</span>
            <input
              type="checkbox"
              checked={localSettings.announcement.enabled}
              onChange={(e) => handleAnnouncementChange('enabled', e.target.checked)}
              className="w-4 h-4 rounded text-stone-900 focus:ring-stone-900 cursor-pointer"
            />
          </label>
        </div>

        <div className="space-y-4">
          <div>
            <label className="block text-xs font-bold text-stone-800 mb-1">نص الإعلان أو العرض *</label>
            <input
              type="text"
              value={localSettings.announcement.text}
              onChange={(e) => handleAnnouncementChange('text', e.target.value)}
              className="w-full px-3 py-2 border border-stone-300 rounded-lg text-xs focus:ring-1 focus:ring-stone-900 text-right"
              placeholder="مثال: خصم 20% لكافة الطلبات + شحن مجاني لفترة محدودة!"
            />
          </div>

          <div className="grid grid-cols-1 sm:grid-cols-3 gap-4">
            <div>
              <label className="block text-xs font-bold text-stone-800 mb-1">شارة العرض (Badge Text)</label>
              <input
                type="text"
                value={localSettings.announcement.badgeText}
                onChange={(e) => handleAnnouncementChange('badgeText', e.target.value)}
                className="w-full px-3 py-2 border border-stone-300 rounded-lg text-xs text-right"
                placeholder="مثال: عرض الموسم"
              />
            </div>

            <div>
              <label className="block text-xs font-bold text-stone-800 mb-1">نص الرابط (Call to Action)</label>
              <input
                type="text"
                value={localSettings.announcement.linkText || ''}
                onChange={(e) => handleAnnouncementChange('linkText', e.target.value)}
                className="w-full px-3 py-2 border border-stone-300 rounded-lg text-xs text-right"
                placeholder="تسوق الآن"
              />
            </div>

            <div>
              <label className="block text-xs font-bold text-stone-800 mb-1">عداد تنازلي (ساعة)</label>
              <div className="flex items-center gap-2">
                <input
                  type="checkbox"
                  checked={localSettings.announcement.showCountdown}
                  onChange={(e) => handleAnnouncementChange('showCountdown', e.target.checked)}
                  className="w-4 h-4 cursor-pointer"
                  id="countdown-check"
                />
                <label htmlFor="countdown-check" className="text-xs text-stone-700 cursor-pointer">
                  تفعيل العداد
                </label>
              </div>
            </div>
          </div>

          {/* Color pickers */}
          <div className="grid grid-cols-1 sm:grid-cols-2 gap-4 pt-2">
            <div>
              <label className="block text-xs font-bold text-stone-800 mb-1">لون خلفية الشريط</label>
              <div className="flex items-center gap-2">
                <input
                  type="color"
                  value={localSettings.announcement.bgColor}
                  onChange={(e) => handleAnnouncementChange('bgColor', e.target.value)}
                  className="w-9 h-8 rounded border border-stone-300 p-0 cursor-pointer"
                />
                <span className="font-mono text-xs text-stone-600">{localSettings.announcement.bgColor}</span>
              </div>
            </div>

            <div>
              <label className="block text-xs font-bold text-stone-800 mb-1">لون الخط</label>
              <div className="flex items-center gap-2">
                <input
                  type="color"
                  value={localSettings.announcement.textColor}
                  onChange={(e) => handleAnnouncementChange('textColor', e.target.value)}
                  className="w-9 h-8 rounded border border-stone-300 p-0 cursor-pointer"
                />
                <span className="font-mono text-xs text-stone-600">{localSettings.announcement.textColor}</span>
              </div>
            </div>
          </div>
        </div>
      </div>

      {/* 3. Home Hero Banner Settings */}
      <div className="bg-white p-6 rounded-2xl border border-stone-200 space-y-4">
        <div className="flex items-center justify-between border-b border-stone-100 pb-3">
          <h4 className="text-sm font-bold text-stone-900 flex items-center gap-2">
            <Sparkles className="w-4 h-4 text-amber-500" />
            <span>البانر الترويجي في الصفحة الرئيسية (Home Hero Banner)</span>
          </h4>

          <label className="flex items-center gap-2 cursor-pointer">
            <span className="text-xs text-stone-600 font-semibold">تفعيل البانر:</span>
            <input
              type="checkbox"
              checked={localSettings.homeBanner?.enabled ?? true}
              onChange={(e) => handleHomeBannerChange('enabled', e.target.checked)}
              className="w-4 h-4 rounded text-stone-900 focus:ring-stone-900 cursor-pointer"
            />
          </label>
        </div>

        <div className="space-y-4">
          <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
            <div>
              <label className="block text-xs font-bold text-stone-800 mb-1">
                عنوان البانر الرئيسي *
              </label>
              <input
                type="text"
                value={localSettings.homeBanner?.title || ''}
                onChange={(e) => handleHomeBannerChange('title', e.target.value)}
                className="w-full px-3 py-2 border border-stone-300 rounded-lg text-xs focus:ring-1 focus:ring-stone-900 text-right"
                placeholder="مثال: تخفيضات الموسم الكبرى"
              />
            </div>

            <div>
              <label className="block text-xs font-bold text-stone-800 mb-1">
                نص الخصم البارز (Discount Text) *
              </label>
              <input
                type="text"
                value={localSettings.homeBanner?.discountText || ''}
                onChange={(e) => handleHomeBannerChange('discountText', e.target.value)}
                className="w-full px-3 py-2 border border-stone-300 rounded-lg text-xs focus:ring-1 focus:ring-stone-900 text-right"
                placeholder="مثال: خصم يصل إلى 50%"
              />
            </div>

            <div>
              <label className="block text-xs font-bold text-stone-800 mb-1">
                نص زر الإجراء (CTA Button Text)
              </label>
              <input
                type="text"
                value={localSettings.homeBanner?.ctaText || ''}
                onChange={(e) => handleHomeBannerChange('ctaText', e.target.value)}
                className="w-full px-3 py-2 border border-stone-300 rounded-lg text-xs focus:ring-1 focus:ring-stone-900 text-right"
                placeholder="مثال: تسوقي الآن"
              />
            </div>

            <div>
              <label className="block text-xs font-bold text-stone-800 mb-1">
                شكل ولون التدرج اللوني للبانر (عند عدم استخدام صورة)
              </label>
              <select
                value={localSettings.homeBanner?.bgGradient || 'from-[#FF5E62] via-[#FF6A5B] to-[#FFA07A]'}
                onChange={(e) => handleHomeBannerChange('bgGradient', e.target.value)}
                className="w-full px-3 py-2 border border-stone-300 rounded-lg text-xs bg-white text-stone-800"
              >
                <option value="from-[#FF5E62] via-[#FF6A5B] to-[#FFA07A]">
                  وردي مرجاني مشرق
                </option>
                <option value="from-[#0f766e] via-[#115e59] to-[#134e4a]">
                  تيل زمردي أنيق
                </option>
                <option value="from-[#881337] via-[#9f1239] to-[#be123c]">
                  عنابي ملكي فخم
                </option>
                <option value="from-[#18181b] via-[#27272a] to-[#3f3f46]">
                  أسود مودرن راقٍ
                </option>
                <option value="from-[#1e3a8a] via-[#1d4ed8] to-[#3b82f6]">
                  أزرق ملكي عصري
                </option>
              </select>
            </div>

            {/* Custom Banner Image Upload */}
            <div className="sm:col-span-2 pt-3 border-t border-stone-100 space-y-2">
              <label className="block text-xs font-bold text-stone-800">
                صورة مخصصة للبانر (رفع مباشر من جهازك أو رابط)
              </label>

              <div className="flex flex-col sm:flex-row items-start sm:items-center gap-3">
                {/* Upload Button */}
                <label className="flex items-center gap-2 px-4 py-2.5 bg-stone-900 hover:bg-black text-white rounded-xl text-xs font-bold cursor-pointer transition-colors shadow-2xs">
                  <span>📁 رفع صورة البانر من الجهاز</span>
                  <input
                    type="file"
                    accept="image/*"
                    onChange={handleBannerImageUpload}
                    className="hidden"
                  />
                </label>

                <span className="text-xs text-stone-400">أو أدخل رابط:</span>

                <input
                  type="url"
                  placeholder="https://example.com/banner.jpg"
                  value={localSettings.homeBanner?.imageUrl || ''}
                  onChange={(e) => handleHomeBannerChange('imageUrl', e.target.value)}
                  className="flex-1 px-3 py-2 border border-stone-300 rounded-xl text-xs focus:ring-1 focus:ring-stone-900 text-left font-mono"
                  dir="ltr"
                />

                {localSettings.homeBanner?.imageUrl && (
                  <button
                    type="button"
                    onClick={() => handleHomeBannerChange('imageUrl', '')}
                    className="px-3 py-2 text-xs font-bold text-rose-600 hover:bg-rose-50 rounded-lg cursor-pointer"
                  >
                    إزالة الصورة
                  </button>
                )}
              </div>

              {/* Banner Image Preview */}
              {localSettings.homeBanner?.imageUrl && (
                <div className="relative mt-2 rounded-xl overflow-hidden border border-stone-200 aspect-[21/9] max-h-48 bg-stone-100">
                  <img
                    src={localSettings.homeBanner.imageUrl}
                    alt="معاينة بانر الموقع"
                    className="w-full h-full object-cover"
                  />
                  <span className="absolute bottom-2 right-2 bg-black/70 text-white text-[10px] px-2 py-0.5 rounded">
                    معاينة صورة البانر المرفوعة
                  </span>
                </div>
              )}
            </div>
          </div>
        </div>
      </div>

      {/* 4. Bundle Offers Global Guide */}
      <div className="bg-stone-50 p-6 rounded-2xl border border-stone-200 space-y-2">
        <h4 className="text-sm font-bold text-stone-900 flex items-center gap-2">
          <Truck className="w-4 h-4 text-stone-700" />
          <span>عروض الكميات والباقات الإضافية</span>
        </h4>
        <p className="text-xs text-stone-600 leading-relaxed">
          يمكنك تخصيص وتفعيل عروض الشراء (مثل باقة قطعتين) لأي منتج بشكل اختياري عبر تبويب <strong>المنتجات</strong> ثم الضغط على <strong>تعديل</strong>. لا يتم فرض أي شارات فوق المنتجات إلا إذا قمت بتفعيلها بنفسك.
        </p>
      </div>

      {/* 5. WhatsApp Floating Button Settings */}
      <div className="bg-white p-6 rounded-2xl border border-stone-200 space-y-4">
        <div className="flex items-center justify-between border-b border-stone-100 pb-3">
          <h4 className="text-sm font-bold text-stone-900 flex items-center gap-2">
            <MessageCircle className="w-4 h-4 text-emerald-600" />
            <span>زر الواتساب العائم في المتجر (WhatsApp Floating Button)</span>
          </h4>

          <label className="flex items-center gap-2 cursor-pointer">
            <span className="text-xs text-stone-600 font-semibold">تفعيل زر الواتساب:</span>
            <input
              type="checkbox"
              checked={localSettings.whatsapp.enabled}
              onChange={(e) => handleWhatsAppChange('enabled', e.target.checked)}
              className="w-4 h-4 rounded text-emerald-600 focus:ring-emerald-600 cursor-pointer"
            />
          </label>
        </div>

        <div className="space-y-4">
          <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
            <div>
              <label className="block text-xs font-bold text-stone-800 mb-1">رقم هاتف الواتساب (مع رمز الدولة) *</label>
              <input
                type="text"
                dir="ltr"
                placeholder="مثال: 966501234567"
                value={localSettings.whatsapp.phoneNumber}
                onChange={(e) => handleWhatsAppChange('phoneNumber', e.target.value)}
                className="w-full px-3 py-2 border border-stone-300 rounded-lg text-xs font-mono focus:ring-1 focus:ring-stone-900 text-left"
              />
              <span className="text-[10px] text-stone-400 mt-0.5 block">
                أدخل الرقم بدون علامة + أو أصفار دولية في البداية
              </span>
            </div>

            <div>
              <label className="block text-xs font-bold text-stone-800 mb-1">موضع الزر في الشاشة</label>
              <select
                value={localSettings.whatsapp.position}
                onChange={(e) => handleWhatsAppChange('position', e.target.value as 'left' | 'right')}
                className="w-full px-3 py-2 border border-stone-300 rounded-lg text-xs bg-white text-stone-800 font-medium"
              >
                <option value="left">أسفل اليسار (موصى به في الواجهة العربية)</option>
                <option value="right">أسفل اليمين</option>
              </select>
            </div>
          </div>

          <div>
            <label className="block text-xs font-bold text-stone-800 mb-1">رسالة الترحيب الافتراضية</label>
            <textarea
              rows={2}
              value={localSettings.whatsapp.greetingMessage}
              onChange={(e) => handleWhatsAppChange('greetingMessage', e.target.value)}
              className="w-full px-3 py-2 border border-stone-300 rounded-lg text-xs focus:ring-1 focus:ring-stone-900 text-right"
              placeholder="مرحباً بك! يسعدنا مساعدتك في اختيار مقاسك المناسب أو الإجابة على أي استفسار."
            />
          </div>
        </div>
      </div>

      {/* 6. Admin Security & Password Settings */}
      <div className="bg-white p-6 rounded-2xl border border-stone-200 space-y-4">
        <div className="flex items-center justify-between border-b border-stone-100 pb-3">
          <h4 className="text-sm font-bold text-stone-900 flex items-center gap-2">
            <span className="w-5 h-5 rounded-md bg-stone-900 text-white flex items-center justify-center text-xs">🔐</span>
            <span>حماية لوحة التحكم وكلمة المرور (Admin Password)</span>
          </h4>
          <span className="text-[11px] text-teal-800 bg-teal-50 border border-teal-200 px-2.5 py-0.5 rounded-full font-bold">
            لوحة الإدارة مخفية عن الزوار
          </span>
        </div>

        <p className="text-xs text-stone-600 leading-relaxed">
          تم إخفاء لوحة التحكم بالكامل عن زوار المتجر العاديين. للوصول إليها، يمكنك النقر على رابط الإدارة الخفي في أسفل الموقع أو استخدام المعلمة <code className="bg-stone-100 px-1 py-0.5 rounded font-mono text-[11px]">?admin</code> مع إدخال كلمة المرور.
        </p>

        <div className="max-w-md">
          <label className="block text-xs font-bold text-stone-800 mb-1">
            تعيين كلمة مرور جديدة للوحة التحكم *
          </label>
          <div className="relative">
            <input
              type={showPassword ? 'text' : 'password'}
              required
              value={localSettings.adminPassword || 'egasa2025'}
              onChange={(e) => handleChange('adminPassword', e.target.value)}
              className="w-full pr-3 pl-10 py-2 border border-stone-300 rounded-lg text-xs font-mono font-bold focus:ring-1 focus:ring-stone-900 text-right"
              placeholder="أدخل كلمة مرور قوية..."
            />
            <button
              type="button"
              onClick={() => setShowPassword(!showPassword)}
              className="absolute left-2.5 top-2 text-stone-400 hover:text-stone-700 cursor-pointer p-0.5"
              title={showPassword ? 'إخفاء كلمة المرور' : 'إظهار كلمة المرور'}
            >
              {showPassword ? <EyeOff className="w-4 h-4" /> : <Eye className="w-4 h-4" />}
            </button>
          </div>
          <span className="text-[10px] text-stone-500 mt-1 block">
            احرص على حفظ كلمة المرور في مكان آمن وعدم مشاركتها مع أي شخص.
          </span>
        </div>
      </div>

      {/* 7. EdgeOne Orders & Static Deployment Settings */}
      <div className="bg-white p-6 rounded-2xl border border-stone-200 space-y-4">
        <div className="flex items-center justify-between border-b border-stone-100 pb-3">
          <h4 className="text-sm font-bold text-stone-900 flex items-center gap-2">
            <span className="w-5 h-5 rounded-md bg-blue-600 text-white flex items-center justify-center text-xs font-mono font-bold">EO</span>
            <span>استلام الطلبات ونشر الموقع على EdgeOne</span>
          </h4>
          <span className="text-[10px] bg-blue-50 text-blue-700 px-2 py-0.5 rounded font-bold border border-blue-200">
            Static / Edge Ready
          </span>
        </div>

        <div className="bg-blue-50/60 border border-blue-100 rounded-xl p-3.5 text-xs text-blue-900 space-y-2 leading-relaxed">
          <p className="font-bold">كيف يضمن المتجر استلام كافة الطلبات بعد رفعه على EdgeOne؟</p>
          <ul className="list-disc list-inside space-y-1 text-stone-700 text-[11px] pr-1">
            <li><strong>تخزين الطلبات محلياً:</strong> كل طلب يقدمه العميل يحفظ فوراً في ذاكرة المتصفح.</li>
            <li><strong>المزامنة التلقائية مع Google Sheets:</strong> عند تفعيل ربط Google Sheets، يتم إرسال بيانات كل طلب فورا إلى جدولك السحابي بدون الحاجة لخادم Node.js.</li>
            <li><strong>تأكيد الواتساب المباشر:</strong> يظهر للعميل زر فوري لإرسال تفاصيل طلبه إلى رقم الواتساب الخاص بك بنقرة واحدة.</li>
          </ul>
        </div>

        <div className="pt-1">
          <label className="flex items-center gap-2 cursor-pointer">
            <input
              type="checkbox"
              checked={Boolean(localSettings.autoOpenWhatsAppOnOrder)}
              onChange={(e) => handleChange('autoOpenWhatsAppOnOrder', e.target.checked)}
              className="w-4 h-4 rounded text-teal-700 focus:ring-teal-700 cursor-pointer"
            />
            <span className="text-xs font-bold text-stone-800">
              توجيه العميل تلقائياً إلى الواتساب بعد الضغط على "أطلب الان" (موصى به في التجارة الإلكترونية بالمغرب)
            </span>
          </label>
        </div>
      </div>
    </form>
  );
};
