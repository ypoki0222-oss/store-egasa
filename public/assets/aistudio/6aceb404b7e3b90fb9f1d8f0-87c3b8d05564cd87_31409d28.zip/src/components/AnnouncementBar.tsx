import React, { useState, useEffect } from 'react';
import { AnnouncementSettings } from '../types';
import { X, Clock } from 'lucide-react';

interface AnnouncementBarProps {
  settings: AnnouncementSettings;
}

export const AnnouncementBar: React.FC<AnnouncementBarProps> = ({ settings }) => {
  const [dismissed, setDismissed] = useState(false);
  const [timeLeft, setTimeLeft] = useState<{ hours: number; minutes: number; seconds: number }>({
    hours: settings.countdownHours || 14,
    minutes: 42,
    seconds: 18,
  });

  useEffect(() => {
    if (!settings.showCountdown) return;

    const timer = setInterval(() => {
      setTimeLeft((prev) => {
        if (prev.seconds > 0) {
          return { ...prev, seconds: prev.seconds - 1 };
        } else if (prev.minutes > 0) {
          return { ...prev, minutes: 59, seconds: 59 };
        } else if (prev.hours > 0) {
          return { hours: prev.hours - 1, minutes: 59, seconds: 59 };
        }
        return prev;
      });
    }, 1000);

    return () => clearInterval(timer);
  }, [settings.showCountdown]);

  if (!settings.enabled || dismissed) return null;

  return (
    <div
      style={{ backgroundColor: settings.bgColor, color: settings.textColor }}
      className="relative z-40 transition-all duration-200 border-b border-black/10 text-xs py-2 px-4"
    >
      <div className="max-w-7xl mx-auto flex items-center justify-between gap-4">
        {/* Left: Optional space or badge */}
        <div className="hidden sm:flex items-center gap-2">
          {settings.badgeText && (
            <span className="bg-white/15 px-2 py-0.5 rounded text-[11px] font-medium tracking-wide">
              {settings.badgeText}
            </span>
          )}
        </div>

        {/* Center: Main announcement text + countdown */}
        <div className="flex-1 text-center flex items-center justify-center gap-3 flex-wrap">
          <p className="font-medium tracking-wide">{settings.text}</p>

          {settings.showCountdown && (
            <div className="inline-flex items-center gap-1.5 bg-black/25 px-2 py-0.5 rounded font-mono tabular-nums text-[11px]">
              <Clock className="w-3 h-3 opacity-80" />
              <span>
                {String(timeLeft.hours).padStart(2, '0')}:
                {String(timeLeft.minutes).padStart(2, '0')}:
                {String(timeLeft.seconds).padStart(2, '0')}
              </span>
            </div>
          )}

          {settings.linkText && (
            <a
              href="#products-section"
              className="underline underline-offset-4 font-semibold hover:opacity-80 transition-opacity whitespace-nowrap"
            >
              {settings.linkText}
            </a>
          )}
        </div>

        {/* Right: Dismiss button */}
        <button
          onClick={() => setDismissed(true)}
          className="opacity-70 hover:opacity-100 p-1 transition-opacity shrink-0 cursor-pointer"
          aria-label="إغلاق الإعلان"
        >
          <X className="w-3.5 h-3.5" />
        </button>
      </div>
    </div>
  );
};
