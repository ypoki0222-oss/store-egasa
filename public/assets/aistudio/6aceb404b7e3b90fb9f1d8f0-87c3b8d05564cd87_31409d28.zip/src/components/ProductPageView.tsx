import React, { useState, useEffect, useRef } from 'react';
import { Product, StoreSettings, Order } from '../types';
import { FashionIllustration } from './FashionIllustration';
import survetteLocalImg from '../assets/survette_amelia.png';
import { pixelService } from '../services/pixelService';
import { sendOrderToGoogleSheet } from '../services/googleSheetsService';
import {
  ShoppingCart,
  Search,
  Phone,
  Plus,
  Minus,
  ArrowRight,
  CheckCircle2,
  AlertCircle,
  Maximize2,
  ZoomIn,
  ZoomOut,
  RotateCcw,
  X,
  ChevronRight,
  ChevronLeft,
} from 'lucide-react';

interface ProductPageViewProps {
  product: Product;
  settings: StoreSettings;
  cartCount: number;
  onBack: () => void;
  onOpenCart: () => void;
  onOrderSuccess: (order: Order) => void;
}

const POPULAR_CITIES = [
  'الدار البيضاء (Casablanca)',
  'الرباط (Rabat)',
  'مراكش (Marrakech)',
  'طنجة (Tanger)',
  'فاس (Fès)',
  'أكادير (Agadir)',
  'مكناس (Meknès)',
  'وجدة (Oujda)',
  'القنيطرة (Kénitra)',
  'تطوان (Tétouan)',
  'تمارة (Témara)',
  'آسفي (Safi)',
  'المحمدية (Mohammédia)',
  'الجديدة (El Jadida)',
  'بني ملال (Béni Mellal)',
  'الناظور (Nador)',
  'خريبكة (Khouribga)',
  'سطات (Settat)',
  'تازة (Taza)',
  'العيون (Laâyoune)',
];

export const ProductPageView: React.FC<ProductPageViewProps> = ({
  product,
  settings,
  cartCount,
  onBack,
  onOpenCart,
  onOrderSuccess,
}) => {
  const formRef = useRef<HTMLDivElement>(null);
  const nameInputRef = useRef<HTMLInputElement>(null);
  const phoneInputRef = useRef<HTMLInputElement>(null);
  const cityInputRef = useRef<HTMLInputElement>(null);
  const addressInputRef = useRef<HTMLInputElement>(null);

  // Gallery images combined with guaranteed fallback to real product asset
  const fallbackImage =
    product.customImage ||
    (product.imageSvgType === 'survette' || product.id === 'prod-survette-amelia'
      ? survetteLocalImg
      : null);

  const allImages = [
    ...(fallbackImage ? [fallbackImage] : []),
    ...(product.galleryImages || []),
  ];

  // Gallery active thumbnail
  const [activeImageIndex, setActiveImageIndex] = useState(0);

  // Lightbox / Image Enlarge modal state
  const [isLightboxOpen, setIsLightboxOpen] = useState(false);
  const [lightboxIndex, setLightboxIndex] = useState(0);
  const [zoomScale, setZoomScale] = useState(1);

  // Variant choices
  const [selectedSize, setSelectedSize] = useState<string>(product.sizes[0] || 'M');
  const [selectedColor, setSelectedColor] = useState<{ name: string; hex: string }>(
    product.colors[0] || { name: 'افتراضي', hex: '#2D3748' }
  );

  // Bundle offer settings (only if merchant explicitly enabled it)
  const bundleOffer = product.bundleOffer;
  const isBundleEnabled = Boolean(bundleOffer?.enabled);
  const bundleLabel = bundleOffer?.label || 'عرض قطعتين (توفير خاص)';
  const bundlePrice = bundleOffer?.price || Math.round(product.price * 1.75);
  const bundleOriginalPrice =
    bundleOffer?.originalPrice || Math.round((product.originalPrice || product.price * 1.4) * 2);

  // Selected package tier: 'single' | 'double'
  const [selectedPackage, setSelectedPackage] = useState<'single' | 'double'>('single');
  const [quantity, setQuantity] = useState<number>(1);

  // Formulaire fields
  const [customerName, setCustomerName] = useState('');
  const [phone, setPhone] = useState('');
  const [city, setCity] = useState('');
  const [address, setAddress] = useState('');
  const [isSubmitting, setIsSubmitting] = useState(false);
  const [formError, setFormError] = useState('');

  // Ref to track InitiateCheckout event once
  const hasTrackedCheckoutRef = useRef(false);

  // Track ViewContent on mount
  useEffect(() => {
    pixelService.track(
      'ViewContent',
      {
        content_name: product.name,
        content_ids: [product.id],
        content_type: 'product',
        value: product.price,
        currency: 'MAD',
      },
      settings.pixel
    );
    window.scrollTo({ top: 0, behavior: 'smooth' });
  }, [product, settings]);

  // Lightbox keyboard controls (ESC, ArrowLeft, ArrowRight)
  useEffect(() => {
    if (!isLightboxOpen) return;
    const handleKeyDown = (e: KeyboardEvent) => {
      if (e.key === 'Escape') {
        setIsLightboxOpen(false);
        setZoomScale(1);
      } else if (e.key === 'ArrowRight') {
        // In RTL Arabic, ArrowRight is Previous
        if (allImages.length > 1) {
          setLightboxIndex((prev) => (prev - 1 + allImages.length) % allImages.length);
          setZoomScale(1);
        }
      } else if (e.key === 'ArrowLeft') {
        // In RTL Arabic, ArrowLeft is Next
        if (allImages.length > 1) {
          setLightboxIndex((prev) => (prev + 1) % allImages.length);
          setZoomScale(1);
        }
      }
    };
    window.addEventListener('keydown', handleKeyDown);
    return () => window.removeEventListener('keydown', handleKeyDown);
  }, [isLightboxOpen, allImages.length]);

  const triggerInitiateCheckout = () => {
    if (!hasTrackedCheckoutRef.current) {
      hasTrackedCheckoutRef.current = true;
      pixelService.track(
        'InitiateCheckout',
        {
          content_name: product.name,
          content_ids: [product.id],
          content_type: 'product',
          value: product.price,
          currency: 'MAD',
          num_items: quantity,
        },
        settings.pixel
      );
    }
  };

  // Price calculations - Delivery is always free, so no shipping added!
  let unitPrice = product.price;
  let unitOriginalPrice = product.originalPrice || Math.round(product.price * 1.4);
  let packageDescription = 'قطعة واحدة';

  if (selectedPackage === 'double' && isBundleEnabled) {
    unitPrice = bundlePrice;
    unitOriginalPrice = bundleOriginalPrice;
    packageDescription = bundleLabel;
  }

  const subtotal = unitPrice * quantity;
  // Delivery is always free: shippingCost = 0
  const shippingCost = 0;
  const grandTotal = subtotal;

  const handleOpenLightbox = (index?: number) => {
    setLightboxIndex(index !== undefined ? index : activeImageIndex);
    setZoomScale(1);
    setIsLightboxOpen(true);
  };

  const handleCloseLightbox = () => {
    setIsLightboxOpen(false);
    setZoomScale(1);
  };

  const handleNextLightboxImage = (e?: React.MouseEvent) => {
    e?.stopPropagation();
    if (allImages.length > 1) {
      setLightboxIndex((prev) => (prev + 1) % allImages.length);
      setZoomScale(1);
    }
  };

  const handlePrevLightboxImage = (e?: React.MouseEvent) => {
    e?.stopPropagation();
    if (allImages.length > 1) {
      setLightboxIndex((prev) => (prev - 1 + allImages.length) % allImages.length);
      setZoomScale(1);
    }
  };

  const handleToggleZoom = (e?: React.MouseEvent) => {
    e?.stopPropagation();
    setZoomScale((prev) => (prev === 1 ? 1.6 : prev === 1.6 ? 2.2 : 1));
  };

  const handleSubmitOrder = async (e?: React.FormEvent) => {
    if (e) e.preventDefault();
    setFormError('');
    triggerInitiateCheckout();

    if (!customerName.trim()) {
      setFormError('يرجى إدخال الإسم الكامل لتأكيد الطلب.');
      formRef.current?.scrollIntoView({ behavior: 'smooth' });
      nameInputRef.current?.focus();
      return;
    }

    const cleanPhoneDigits = phone.replace(/[^0-9]/g, '');
    if (!cleanPhoneDigits || cleanPhoneDigits.length < 8) {
      setFormError('يرجى إدخال رقم هاتف صحيح للتواصل وتأكيد الشحنة (مثال: 0612345678).');
      formRef.current?.scrollIntoView({ behavior: 'smooth' });
      phoneInputRef.current?.focus();
      return;
    }

    if (!city.trim()) {
      setFormError('يرجى كتابة أو اختيار المدينة.');
      formRef.current?.scrollIntoView({ behavior: 'smooth' });
      cityInputRef.current?.focus();
      return;
    }

    if (!address.trim()) {
      setFormError('يرجى كتابة العنوان بالتفصيل (الحي، الشارع، رقم المنزل).');
      formRef.current?.scrollIntoView({ behavior: 'smooth' });
      addressInputRef.current?.focus();
      return;
    }

    setIsSubmitting(true);

    const orderNumber = `#ORD-${Math.floor(1000 + Math.random() * 9000)}`;

    const newOrder: Order = {
      id: `ord-${Date.now()}`,
      orderNumber,
      createdAt: new Date().toISOString(),
      customerName: customerName.trim(),
      phone: phone.trim(),
      city: city.trim(),
      address: address.trim(),
      notes: `الباقة: ${packageDescription} - المقاس: ${selectedSize} - اللون: ${selectedColor.name}`,
      items: [
        {
          productId: product.id,
          productName: `${product.name} (${packageDescription})`,
          price: unitPrice,
          quantity,
          selectedSize,
          selectedColor: selectedColor.name,
          imageSvgType: product.imageSvgType,
        },
      ],
      subtotal,
      shippingCost,
      totalPrice: grandTotal,
      status: 'new',
      syncedToGoogleSheets: false,
    };

    // 1. Fire Pixel Purchase event (Normalized with MAD for ad networks)
    pixelService.track(
      'Purchase',
      {
        content_name: product.name,
        content_ids: [product.id],
        value: grandTotal,
        currency: 'MAD',
        num_items: quantity,
        order_id: orderNumber,
        customer_name: customerName.trim(),
        customer_phone: phone.trim(),
      },
      settings.pixel
    );

    // 2. Sync to Google Sheets / Webhook if configured
    if (settings.googleSheetsWebhookUrl && settings.googleSheetsAutoSync) {
      try {
        const syncResult = await sendOrderToGoogleSheet(
          newOrder,
          settings.googleSheetsWebhookUrl,
          settings.currency
        );
        newOrder.syncedToGoogleSheets = syncResult.success;
        newOrder.googleSheetsResponse = syncResult.message;
      } catch (err) {
        console.warn('Webhook sync error:', err);
      }
    }

    // 3. Auto-open WhatsApp if merchant enabled this in Store Settings
    if (settings.autoOpenWhatsAppOnOrder && settings.whatsapp.phoneNumber) {
      const cleanStorePhone = settings.whatsapp.phoneNumber.replace(/[^0-9]/g, '');
      const waMsg = `🛍️ *طلب جديد من متجر ${settings.storeName}*\nرقم الطلب: ${orderNumber}\nالمنتج: ${product.name} (${packageDescription})\nالكمية: ${quantity}\nالمقاس: ${selectedSize} | اللون: ${selectedColor.name}\nالمجموع الإجمالي: ${grandTotal} ${settings.currency}\n---\n👤 العميل: ${customerName}\n📱 الهاتف: ${phone}\n📍 المدينة: ${city}\n🏠 العنوان: ${address}`;
      const waUrl = `https://wa.me/${cleanStorePhone}?text=${encodeURIComponent(waMsg)}`;
      window.open(waUrl, '_blank');
    }

    setIsSubmitting(false);
    onOrderSuccess(newOrder);
  };

  const handleWhatsAppCall = () => {
    const cleanPhone = settings.whatsapp.phoneNumber.replace(/[^0-9]/g, '');
    const msg = `مرحباً EGASA، أود الاستفسار وطلب منتج: ${product.name} (${packageDescription}) بسعر ${unitPrice} ${settings.currency}.`;
    window.open(`https://wa.me/${cleanPhone}?text=${encodeURIComponent(msg)}`, '_blank');
  };

  const activeImageUrl = allImages.length > 0 ? allImages[activeImageIndex] || allImages[0] : null;

  return (
    <div className="min-h-screen bg-white text-stone-900 pb-32 font-['Cairo',sans-serif]">
      {/* 1. Header (EGASA Brand Top Bar - Customer Facing, No Admin Expose) */}
      <header className="sticky top-0 z-30 bg-white border-b border-stone-200/90 px-4 py-3 flex items-center justify-between shadow-2xs">
        {/* Left: Cart Icon with Badge & Search */}
        <div className="flex items-center gap-3">
          <button
            onClick={onOpenCart}
            className="relative p-1.5 text-stone-800 hover:text-black cursor-pointer transition-transform active:scale-95"
            aria-label="سلة التسوق"
          >
            <ShoppingCart className="w-6 h-6 stroke-[2.2]" />
            {cartCount > 0 && (
              <span className="absolute -top-1 -right-1 bg-red-600 text-white font-bold text-[10px] rounded-full h-4 min-w-[16px] px-1 flex items-center justify-center animate-pulse">
                {cartCount}
              </span>
            )}
          </button>

          <button
            onClick={onBack}
            className="p-1.5 text-stone-800 hover:text-black cursor-pointer transition-transform active:scale-95"
            aria-label="البحث في المتجر"
            title="العودة والبحث"
          >
            <Search className="w-5 h-5 stroke-[2.2]" />
          </button>
        </div>

        {/* Right: EGASA Brand Wordmark */}
        <div className="flex items-center gap-2">
          <span
            onClick={onBack}
            className="text-lg sm:text-xl font-bold tracking-[0.25em] text-[#881337] uppercase font-serif cursor-pointer hover:opacity-85 select-none"
          >
            EGASA
          </span>
        </div>
      </header>

      {/* Breadcrumb Bar - Clean, Customer Facing (Private merchant links removed) */}
      <div className="max-w-xl mx-auto px-4 pt-3 pb-1 flex items-center justify-between text-xs text-stone-500">
        <button
          onClick={onBack}
          className="flex items-center gap-1.5 font-bold text-stone-700 hover:text-stone-900 cursor-pointer transition-colors"
        >
          <ArrowRight className="w-4 h-4" />
          <span>العودة للمتجر</span>
        </button>
      </div>

      <main className="max-w-xl mx-auto px-4 py-2 space-y-5">
        {/* 2. Main Product Hero Image - Click to enlarge in full screen */}
        <div
          onClick={() => handleOpenLightbox(activeImageIndex)}
          className="group relative aspect-[16/11] sm:aspect-[4/3] w-full rounded-2xl overflow-hidden border border-stone-200 bg-stone-50 flex items-center justify-center shadow-xs cursor-zoom-in transition-all hover:shadow-md"
          title="اضغط لتكبير الصورة ورؤيتها كاملة"
        >
          {product.badge && (
            <div className="absolute top-3 right-3 z-20 bg-stone-900/90 text-white px-2.5 py-1 rounded-lg text-xs font-bold shadow-xs">
              {product.badge}
            </div>
          )}

          {/* Zoom hint badge */}
          <div className="absolute bottom-3 left-3 z-20 flex items-center gap-1.5 px-2.5 py-1.5 bg-black/70 group-hover:bg-black/85 backdrop-blur-xs text-white text-[11px] font-bold rounded-xl shadow-md transition-all group-hover:scale-105 pointer-events-none">
            <Maximize2 className="w-3.5 h-3.5" />
            <span>تكبير الصورة</span>
          </div>

          {activeImageUrl ? (
            <img
              src={activeImageUrl}
              alt={product.name}
              onError={(e) => {
                if (activeImageUrl !== survetteLocalImg) {
                  e.currentTarget.src = survetteLocalImg;
                }
              }}
              className="w-full h-full object-cover transition-transform duration-300 group-hover:scale-102"
            />
          ) : (
            <FashionIllustration
              type={product.imageSvgType}
              accentColor={selectedColor.hex}
              className="w-full h-full object-cover transition-transform duration-300 group-hover:scale-102"
            />
          )}
        </div>

        {/* Gallery Thumbnails */}
        {allImages.length > 1 ? (
          <div className="flex items-center gap-2 overflow-x-auto pb-1 pt-0.5">
            {allImages.map((imgUrl, idx) => (
              <button
                key={idx}
                type="button"
                onClick={() => setActiveImageIndex(idx)}
                className={`relative w-16 h-16 rounded-xl overflow-hidden border-2 shrink-0 transition-all cursor-pointer ${
                  activeImageIndex === idx
                    ? 'border-teal-700 shadow-sm scale-102'
                    : 'border-stone-200 opacity-75 hover:opacity-100'
                }`}
                title={`صورة ${idx + 1}`}
              >
                <img
                  src={imgUrl}
                  alt={`${product.name} thumbnail ${idx + 1}`}
                  className="w-full h-full object-cover"
                />
              </button>
            ))}
          </div>
        ) : product.colors.length > 1 ? (
          <div className="space-y-1.5 pt-1">
            <span className="text-[11px] text-stone-500 font-bold block text-right">
              الألوان المتوفرة ({product.colors.length} ألوان):
            </span>
            <div className="flex items-center gap-2 overflow-x-auto pb-1 pt-0.5 justify-end">
              {product.colors.map((c, idx) => (
                <button
                  key={idx}
                  type="button"
                  onClick={() => {
                    setSelectedColor(c);
                    triggerInitiateCheckout();
                  }}
                  className={`relative w-14 sm:w-16 h-16 sm:h-20 rounded-xl overflow-hidden border-2 shrink-0 transition-all cursor-pointer flex flex-col items-center justify-between p-1 ${
                    selectedColor.name === c.name
                      ? 'border-teal-700 ring-2 ring-teal-600/30 shadow-sm scale-105 bg-teal-50/50'
                      : 'border-stone-200 opacity-80 hover:opacity-100 bg-white'
                  }`}
                  title={c.name}
                >
                  <div className="w-full flex-1 relative flex items-center justify-center">
                    <FashionIllustration
                      type={product.imageSvgType}
                      accentColor={c.hex}
                      className="w-full h-full pointer-events-none"
                    />
                  </div>
                  <span className="text-[10px] font-bold text-stone-800 truncate max-w-full text-center">
                    {c.name}
                  </span>
                </button>
              ))}
            </div>
          </div>
        ) : null}

        {/* 3. Product Title & Current Pricing */}
        <div className="space-y-1 text-right">
          <h1 className="text-xl sm:text-2xl font-black text-stone-900 tracking-tight font-['Cairo']">
            {product.name}
          </h1>

          <div className="flex items-baseline justify-end gap-3 pt-1">
            <span className="text-2xl sm:text-3xl font-extrabold text-[#D90429] font-sans tabular-nums">
              {unitPrice} {settings.currency}
            </span>
            {unitOriginalPrice > unitPrice && (
              <span className="text-sm sm:text-base text-stone-400 line-through font-sans tabular-nums">
                {unitOriginalPrice} {settings.currency}
              </span>
            )}
          </div>
        </div>

        {/* 4. Customizable Bundle Packages Selection (Only if enabled) */}
        {isBundleEnabled && (
          <div className="space-y-2.5 pt-1">
            <label className="block text-xs font-bold text-stone-900 text-right">
              اختر العرض المناسب لك:
            </label>

            <div className="grid grid-cols-1 sm:grid-cols-2 gap-2.5">
              {/* Single Tier */}
              <button
                type="button"
                onClick={() => {
                  setSelectedPackage('single');
                  triggerInitiateCheckout();
                }}
                className={`p-3.5 rounded-xl border-2 text-right transition-all cursor-pointer ${
                  selectedPackage === 'single'
                    ? 'border-teal-700 bg-teal-50/70 shadow-xs'
                    : 'border-stone-200 bg-white hover:border-stone-300'
                }`}
              >
                <div className="flex items-center justify-between">
                  <span className="text-xs font-bold text-stone-900">قطعة واحدة</span>
                  <span className="font-bold text-teal-800 text-sm">
                    {product.price} {settings.currency}
                  </span>
                </div>
                <p className="text-[11px] text-stone-500 mt-0.5">الطلب القياسي</p>
              </button>

              {/* Bundle Tier */}
              <button
                type="button"
                onClick={() => {
                  setSelectedPackage('double');
                  triggerInitiateCheckout();
                }}
                className={`relative p-3.5 rounded-xl border-2 text-right transition-all cursor-pointer ${
                  selectedPackage === 'double'
                    ? 'border-red-600 bg-red-50/70 shadow-xs'
                    : 'border-red-200 bg-white hover:border-red-300'
                }`}
              >
                {bundleOffer?.stickerText && (
                  <span className="absolute -top-2.5 left-3 bg-red-600 text-white font-bold text-[10px] px-2 py-0.5 rounded-full shadow-2xs">
                    {bundleOffer.stickerText}
                  </span>
                )}
                <div className="flex items-center justify-between">
                  <span className="text-xs font-bold text-red-900">{bundleLabel}</span>
                  <span className="font-bold text-red-700 text-sm">
                    {bundlePrice} {settings.currency}
                  </span>
                </div>
                <p className="text-[11px] text-red-600/90 mt-0.5 font-medium">
                  وفر أكثر + شحن مجاني
                </p>
              </button>
            </div>
          </div>
        )}

        {/* 5. Variant Selectors (Size & Color) */}
        <div className="space-y-4 pt-1">
          {/* Sizes */}
          {product.sizes.length > 0 && (
            <div className="space-y-2 text-right">
              <div className="flex items-center justify-between">
                <span className="text-xs font-bold text-stone-900">المقاس:</span>
                <span className="text-xs font-bold text-teal-800 font-mono">{selectedSize}</span>
              </div>
              <div className="flex flex-wrap gap-2 justify-end">
                {product.sizes.map((s) => (
                  <button
                    key={s}
                    type="button"
                    onClick={() => {
                      setSelectedSize(s);
                      triggerInitiateCheckout();
                    }}
                    className={`min-w-[44px] h-10 px-3 rounded-xl font-bold text-xs font-mono transition-all cursor-pointer border ${
                      selectedSize === s
                        ? 'border-teal-700 bg-teal-700 text-white shadow-xs'
                        : 'border-stone-200 bg-white text-stone-800 hover:border-stone-400'
                    }`}
                  >
                    {s}
                  </button>
                ))}
              </div>
            </div>
          )}

          {/* Colors */}
          {product.colors.length > 0 && (
            <div className="space-y-2 text-right">
              <div className="flex items-center justify-between">
                <span className="text-xs font-bold text-stone-900">اللون:</span>
                <span className="text-xs font-bold text-teal-800">{selectedColor.name}</span>
              </div>
              <div className="flex flex-wrap gap-2.5 justify-end items-center">
                {product.colors.map((c, i) => (
                  <button
                    key={i}
                    type="button"
                    onClick={() => {
                      setSelectedColor(c);
                      triggerInitiateCheckout();
                    }}
                    style={{ backgroundColor: c.hex }}
                    className={`w-8 h-8 rounded-full border-2 transition-transform cursor-pointer ${
                      selectedColor.name === c.name
                        ? 'border-teal-700 scale-110 shadow-xs ring-2 ring-teal-700/30'
                        : 'border-stone-300 hover:scale-105'
                    }`}
                    title={c.name}
                  />
                ))}
              </div>
            </div>
          )}
        </div>

        {/* 6. Formulaire de Commande (Form with Blue Border as per Moroccan COD standard) */}
        <div
          ref={formRef}
          className="bg-white p-5 rounded-3xl border-2 border-[#00AEEF] shadow-sm space-y-4 text-right transition-all"
        >
          {/* Form Header */}
          <div className="space-y-1">
            <h2 className="text-lg sm:text-xl font-bold text-stone-900 font-['Cairo']">
              معلومات الزبون للطلب
            </h2>
            <p className="text-[11px] text-stone-500">
              قم بملء الاستمارة لإتمام طلبك، سنتصل بك لتأكيد الإرسال والشحن
            </p>
          </div>

          {formError && (
            <div className="p-3 bg-red-50 border border-red-200 text-red-700 text-xs rounded-xl flex items-center gap-2 text-right">
              <AlertCircle className="w-4 h-4 shrink-0 text-red-600" />
              <span>{formError}</span>
            </div>
          )}

          <form onSubmit={handleSubmitOrder} className="space-y-3">
            {/* 1. الإسم الكامل */}
            <div>
              <input
                ref={nameInputRef}
                type="text"
                required
                value={customerName}
                onFocus={triggerInitiateCheckout}
                onChange={(e) => setCustomerName(e.target.value)}
                placeholder="الإسم الكامل *"
                className="w-full px-4 py-3 bg-white border-2 border-[#00AEEF] rounded-2xl text-xs sm:text-sm text-right text-stone-900 placeholder:text-stone-400 focus:outline-none focus:ring-2 focus:ring-[#00AEEF]/40 transition-all font-['Cairo']"
              />
            </div>

            {/* 2. رقم الهاتف */}
            <div>
              <input
                ref={phoneInputRef}
                type="tel"
                required
                value={phone}
                onFocus={triggerInitiateCheckout}
                onChange={(e) => setPhone(e.target.value)}
                placeholder="رقم الهاتف (مثال: 0612345678) *"
                className="w-full px-4 py-3 bg-white border-2 border-[#00AEEF] rounded-2xl text-xs sm:text-sm text-right text-stone-900 placeholder:text-stone-400 focus:outline-none focus:ring-2 focus:ring-[#00AEEF]/40 transition-all font-['Cairo']"
              />
            </div>

            {/* 3. المدينة */}
            <div>
              <input
                ref={cityInputRef}
                list="popular-cities-list"
                type="text"
                required
                value={city}
                onFocus={triggerInitiateCheckout}
                onChange={(e) => setCity(e.target.value)}
                placeholder="المدينة (مثال: الدار البيضاء، الرباط، طنجة...) *"
                className="w-full px-4 py-3 bg-white border-2 border-[#00AEEF] rounded-2xl text-xs sm:text-sm text-right text-stone-900 placeholder:text-stone-400 focus:outline-none focus:ring-2 focus:ring-[#00AEEF]/40 transition-all font-['Cairo']"
              />
              <datalist id="popular-cities-list">
                {POPULAR_CITIES.map((c) => (
                  <option key={c} value={c} />
                ))}
              </datalist>
            </div>

            {/* 4. العنوان بالتفصيل */}
            <div>
              <input
                ref={addressInputRef}
                type="text"
                required
                value={address}
                onFocus={triggerInitiateCheckout}
                onChange={(e) => setAddress(e.target.value)}
                placeholder="العنوان بالتفصيل (الحي، الشارع، رقم الدار/الإقامة) *"
                className="w-full px-4 py-3 bg-white border-2 border-[#00AEEF] rounded-2xl text-xs sm:text-sm text-right text-stone-900 placeholder:text-stone-400 focus:outline-none focus:ring-2 focus:ring-[#00AEEF]/40 transition-all font-['Cairo']"
              />
            </div>

            {/* Summary Preview - Clean, delivery is always free and not added */}
            <div className="bg-stone-50 p-3.5 rounded-2xl border border-stone-200 text-xs space-y-2 font-sans">
              <div className="flex justify-between items-center text-stone-700">
                <span>سعر المنتج ({packageDescription}):</span>
                <span className="font-bold tabular-nums text-stone-900">{subtotal} {settings.currency}</span>
              </div>
              <div className="flex justify-between items-center text-stone-900 font-bold border-t border-stone-200 pt-2 text-sm">
                <span>المجموع الكلي للدفع عند الاستلام:</span>
                <span className="text-red-600 font-black tabular-nums text-base">{grandTotal} {settings.currency}</span>
              </div>
            </div>

            {/* Payment terms guarantee */}
            <div className="pt-1 text-[11px] text-stone-600 flex items-center justify-center gap-1.5 font-medium">
              <CheckCircle2 className="w-4 h-4 text-emerald-600 shrink-0" />
              <span>الدفع نقداً بعد استلام ومعاينة الطلب (COD)</span>
            </div>
          </form>
        </div>

        {/* Product features & description bullet points */}
        <div className="bg-stone-50 p-4 rounded-2xl border border-stone-200 text-right space-y-2 text-xs text-stone-700">
          <h3 className="font-bold text-stone-900">مميزات ومواصفات هذه القطعة:</h3>
          <p className="text-stone-600 leading-relaxed">{product.description}</p>
          <ul className="space-y-1.5 list-disc list-inside pr-1 text-stone-600 leading-relaxed pt-1">
            {product.features.map((feat, idx) => (
              <li key={idx}>{feat}</li>
            ))}
          </ul>
        </div>
      </main>

      {/* 7. Sticky Bottom Buy Bar (Matches exact red button layout) */}
      <div className="fixed bottom-0 inset-x-0 z-40 bg-white/95 backdrop-blur-md border-t border-stone-200 px-3 py-2.5 sm:px-4 sm:py-3 pb-[max(0.75rem,env(safe-area-inset-bottom))] shadow-2xl">
        <div className="max-w-xl mx-auto flex items-center justify-between gap-2.5">
          {/* Order Now Red Button */}
          <button
            onClick={() => handleSubmitOrder()}
            disabled={isSubmitting}
            className="flex-1 py-3 px-3 sm:px-6 bg-[#FF0000] hover:bg-red-700 active:bg-red-800 text-white font-black text-sm sm:text-base rounded-md transition-all duration-150 cursor-pointer shadow-md flex items-center justify-center gap-2 active:scale-98 disabled:opacity-60 font-['Cairo'] tracking-wide"
          >
            {isSubmitting ? (
              <span>جاري إرسال طلبك...</span>
            ) : (
              <span>أطلب الان !</span>
            )}
          </button>

          {/* Quantity Controls & WhatsApp Direct Button */}
          <div className="flex items-center gap-2 shrink-0">
            {/* Quantity Stepper */}
            <div className="flex items-center bg-stone-100 rounded-lg p-0.5 border border-stone-200 text-xs">
              <button
                type="button"
                onClick={() => {
                  setQuantity((q) => q + 1);
                  triggerInitiateCheckout();
                }}
                className="w-8 h-8 rounded-md bg-stone-200 hover:bg-stone-300 active:bg-stone-400 flex items-center justify-center font-bold text-stone-800 cursor-pointer transition-colors"
                aria-label="زيادة الكمية"
              >
                <Plus className="w-3.5 h-3.5" />
              </button>

              <span className="w-7 text-center font-bold font-mono text-stone-900 tabular-nums text-xs">
                {quantity}
              </span>

              <button
                type="button"
                onClick={() => {
                  setQuantity((q) => Math.max(1, q - 1));
                  triggerInitiateCheckout();
                }}
                className="w-8 h-8 rounded-md bg-stone-200 hover:bg-stone-300 active:bg-stone-400 flex items-center justify-center font-bold text-stone-800 cursor-pointer transition-colors"
                aria-label="إنقاص الكمية"
              >
                <Minus className="w-3.5 h-3.5" />
              </button>
            </div>

            {/* WhatsApp Direct Button */}
            <button
              onClick={handleWhatsAppCall}
              className="w-11 h-11 rounded-full bg-[#25D366] hover:bg-[#20ba59] active:bg-[#128C7E] text-white flex items-center justify-center shadow-md cursor-pointer transition-transform hover:scale-105 active:scale-95 shrink-0"
              aria-label="تواصل واطلب عبر الواتساب"
              title="تواصل مباشر عبر الواتساب"
            >
              <Phone className="w-5 h-5 fill-white" />
            </button>
          </div>
        </div>
      </div>

      {/* 8. Fullscreen Image Lightbox Modal (Click to see full image) */}
      {isLightboxOpen && (
        <div
          onClick={handleCloseLightbox}
          className="fixed inset-0 z-50 bg-black/95 backdrop-blur-md flex flex-col justify-between p-3 sm:p-6 select-none animate-fadeIn"
          role="dialog"
          aria-modal="true"
        >
          {/* Top Bar Controls */}
          <div
            onClick={(e) => e.stopPropagation()}
            className="flex items-center justify-between gap-4 z-20 pb-2 border-b border-white/10"
          >
            {/* Right: Close button */}
            <button
              onClick={handleCloseLightbox}
              className="flex items-center gap-1.5 px-3.5 py-1.5 rounded-full bg-white/15 hover:bg-white/25 active:bg-white/35 text-white text-xs font-bold transition-all cursor-pointer"
            >
              <X className="w-4 h-4" />
              <span>إغلاق</span>
            </button>

            {/* Middle: Title & Image counter */}
            <div className="text-center px-2">
              <h4 className="text-xs sm:text-sm font-bold text-white line-clamp-1">
                {product.name}
              </h4>
              {allImages.length > 1 && (
                <span className="text-[11px] text-white/60 font-mono">
                  صورة {lightboxIndex + 1} من {allImages.length}
                </span>
              )}
            </div>

            {/* Left: Zoom Controls */}
            <div className="flex items-center gap-1.5">
              <button
                onClick={(e) => {
                  e.stopPropagation();
                  setZoomScale((prev) => Math.min(3, prev + 0.3));
                }}
                className="p-1.5 rounded-lg bg-white/10 hover:bg-white/20 active:bg-white/30 text-white transition-colors cursor-pointer"
                title="تكبير"
              >
                <ZoomIn className="w-4 h-4" />
              </button>

              <button
                onClick={(e) => {
                  e.stopPropagation();
                  setZoomScale((prev) => Math.max(0.8, prev - 0.3));
                }}
                className="p-1.5 rounded-lg bg-white/10 hover:bg-white/20 active:bg-white/30 text-white transition-colors cursor-pointer"
                title="تصغير"
              >
                <ZoomOut className="w-4 h-4" />
              </button>

              {zoomScale !== 1 && (
                <button
                  onClick={(e) => {
                    e.stopPropagation();
                    setZoomScale(1);
                  }}
                  className="p-1.5 rounded-lg bg-white/10 hover:bg-white/20 text-white transition-colors cursor-pointer"
                  title="إعادة الحجم الافتراضي"
                >
                  <RotateCcw className="w-4 h-4" />
                </button>
              )}
            </div>
          </div>

          {/* Center Image Display */}
          <div className="relative flex-1 flex items-center justify-center overflow-hidden my-2">
            {/* Previous Image Button (In RTL, right arrow goes previous) */}
            {allImages.length > 1 && (
              <button
                onClick={handlePrevLightboxImage}
                className="absolute right-2 sm:right-6 top-1/2 -translate-y-1/2 z-20 w-10 h-10 sm:w-12 sm:h-12 rounded-full bg-black/60 hover:bg-black/90 text-white flex items-center justify-center border border-white/20 transition-all cursor-pointer hover:scale-105 active:scale-95"
                title="الصورة السابقة"
              >
                <ChevronRight className="w-6 h-6" />
              </button>
            )}

            {/* The Enlargeable Image */}
            <div
              onClick={handleToggleZoom}
              className="max-h-[75vh] max-w-[95vw] sm:max-h-[82vh] flex items-center justify-center transition-transform duration-200 cursor-zoom-in"
              style={{ transform: `scale(${zoomScale})` }}
            >
              {allImages[lightboxIndex] ? (
                <img
                  src={allImages[lightboxIndex]}
                  alt={`${product.name} - صورة كاملة مكبرة`}
                  onError={(e) => {
                    if (allImages[lightboxIndex] !== survetteLocalImg) {
                      e.currentTarget.src = survetteLocalImg;
                    }
                  }}
                  className="max-h-[75vh] max-w-[92vw] sm:max-h-[82vh] object-contain rounded-xl shadow-2xl pointer-events-auto"
                />
              ) : (
                <div className="w-[85vw] max-w-md aspect-square bg-stone-900 rounded-2xl flex items-center justify-center p-6 border border-white/10">
                  <FashionIllustration
                    type={product.imageSvgType}
                    accentColor={selectedColor.hex}
                    className="w-full h-full object-contain"
                  />
                </div>
              )}
            </div>

            {/* Next Image Button (In RTL, left arrow goes next) */}
            {allImages.length > 1 && (
              <button
                onClick={handleNextLightboxImage}
                className="absolute left-2 sm:left-6 top-1/2 -translate-y-1/2 z-20 w-10 h-10 sm:w-12 sm:h-12 rounded-full bg-black/60 hover:bg-black/90 text-white flex items-center justify-center border border-white/20 transition-all cursor-pointer hover:scale-105 active:scale-95"
                title="الصورة التالية"
              >
                <ChevronLeft className="w-6 h-6" />
              </button>
            )}
          </div>

          {/* Bottom Thumbnails Strip (if multiple) */}
          {allImages.length > 1 && (
            <div
              onClick={(e) => e.stopPropagation()}
              className="flex items-center justify-center gap-2 pt-2 border-t border-white/10 overflow-x-auto z-20"
            >
              {allImages.map((img, idx) => (
                <button
                  key={idx}
                  onClick={() => {
                    setLightboxIndex(idx);
                    setZoomScale(1);
                  }}
                  className={`w-12 h-12 rounded-lg overflow-hidden border-2 transition-all cursor-pointer shrink-0 ${
                    lightboxIndex === idx
                      ? 'border-white scale-105 shadow-md'
                      : 'border-white/30 opacity-60 hover:opacity-100'
                  }`}
                >
                  <img src={img} alt={`مصغرة ${idx + 1}`} className="w-full h-full object-cover" />
                </button>
              ))}
            </div>
          )}
        </div>
      )}
    </div>
  );
};
