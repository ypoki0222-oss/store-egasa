import React from 'react';
import { HomeBannerSettings } from '../types';
import { ArrowLeft } from 'lucide-react';

interface PromoSliderProps {
  bannerSettings?: HomeBannerSettings;
  onCtaClick: () => void;
}

export const PromoSlider: React.FC<PromoSliderProps> = ({ bannerSettings, onCtaClick }) => {
  if (bannerSettings && !bannerSettings.enabled) {
    return null;
  }

  const title = bannerSettings?.title || 'تخفيضات الموسم الكبرى';
  const subtitle = bannerSettings?.subtitle || '';
  const discount = bannerSettings?.discountText || 'خصم يصل إلى 50%';
  const ctaText = bannerSettings?.ctaText || 'تسوقي الآن';
  const bgGradient = bannerSettings?.bgGradient || 'from-[#FF5E62] via-[#FF6A5B] to-[#FFA07A]';
  const imageUrl = bannerSettings?.imageUrl;

  return (
    <div className="w-full max-w-4xl mx-auto px-4 sm:px-6 pt-3 pb-2 font-['Cairo',sans-serif]">
      <div
        className={`relative overflow-hidden rounded-2xl sm:rounded-3xl shadow-lg ${
          imageUrl ? 'bg-stone-900' : `bg-gradient-to-r ${bgGradient}`
        } text-white p-6 sm:p-9 transition-all duration-300 min-h-[220px] flex items-center`}
      >
        {/* Custom Uploaded Background Image if set */}
        {imageUrl ? (
          <>
            <img
              src={imageUrl}
              alt="بانر المتجر"
              className="absolute inset-0 w-full h-full object-cover object-center"
            />
            {/* Dark gradient overlay for perfect contrast */}
            <div className="absolute inset-0 bg-gradient-to-r from-black/85 via-black/60 to-black/30 pointer-events-none" />
          </>
        ) : (
          <>
            {/* Playful geometric shapes in background when gradient is used */}
            <div className="absolute top-0 right-0 w-36 h-36 bg-amber-300/30 rounded-full blur-xl pointer-events-none transform translate-x-10 -translate-y-10" />
            <div className="absolute bottom-2 left-6 w-28 h-28 bg-emerald-400/30 rounded-2xl rotate-12 blur-lg pointer-events-none" />
            <div className="absolute top-4 left-1/3 w-16 h-16 bg-white/10 rounded-full pointer-events-none" />
            <div className="absolute bottom-4 right-1/4 w-8 h-8 bg-yellow-300/40 rounded-full pointer-events-none" />
          </>
        )}

        <div className="relative z-10 flex flex-col items-center sm:items-start text-center sm:text-right space-y-2.5 max-w-xl">
          {/* Title */}
          <h2 className="text-2xl sm:text-3xl lg:text-4xl font-extrabold tracking-tight drop-shadow-md font-['Cairo']">
            {title}
          </h2>

          {/* Subtitle if set */}
          {subtitle && (
            <p className="text-xs sm:text-sm font-medium text-white/90 drop-shadow-xs leading-relaxed">
              {subtitle}
            </p>
          )}

          {/* Big Discount Tag */}
          {discount && (
            <div className="text-2xl sm:text-3xl lg:text-4xl font-black tracking-tight drop-shadow-md text-white font-['Cairo'] py-0.5">
              {discount}
            </div>
          )}

          {/* White rounded pill button */}
          <div className="pt-2">
            <button
              onClick={onCtaClick}
              className="px-7 py-2.5 sm:px-8 sm:py-3 bg-white text-stone-900 font-extrabold text-xs sm:text-sm rounded-full shadow-md hover:bg-stone-50 hover:scale-105 active:scale-95 transition-all duration-200 cursor-pointer inline-flex items-center gap-2 font-['Cairo']"
            >
              <span>{ctaText}</span>
              <ArrowLeft className="w-4 h-4 text-stone-900" />
            </button>
          </div>
        </div>
      </div>
    </div>
  );
};
