import { Order } from '../types';

export const GOOGLE_APPS_SCRIPT_TEMPLATE = `/**
 * كود Google Apps Script لربط متجر الملابس مع جدول بيانات غوغل شيت تلقائياً
 * 
 * خطوات التفعيل في 60 ثانية:
 * 1. افتح جدول Google Sheet جديد.
 * 2. اضغط من القائمة العلوية على "الإضافات" (Extensions) ثم "Apps Script".
 * 3. امسح أي كود موجود والصق هذا الكود كاملاً.
 * 4. اضغط على زر "نشر" (Deploy) في الأعلى يمين -> "نشر جديد" (New deployment).
 * 5. اختر نوع النشر: "تطبيق ويب" (Web app).
 * 6. في حقل "من يملك حق الوصول" (Who has access)، اختر: "أي مستخدم" (Anyone).
 * 7. اضغط "Deploy" وانسخ رابط Web App URL والصقه في لوحة تحكم المتجر!
 */

function doPost(e) {
  var lock = LockService.getScriptLock();
  lock.tryLock(10000);

  try {
    var sheet = SpreadsheetApp.getActiveSpreadsheet().getActiveSheet();
    
    // إذا كان الجدول فارغاً، ننشئ العناوين تلقائياً
    if (sheet.getLastRow() === 0) {
      sheet.appendRow([
        "تاريخ الطلب",
        "رقم الطلب",
        "اسم العميل",
        "رقم الهاتف",
        "المدينة",
        "العنوان التفصيلي",
        "المنتجات والخيارات",
        "المقاس",
        "اللون",
        "الكمية",
        "المبلغ الإجمالي",
        "حالة الطلب",
        "ملاحظات العميل"
      ]);
      sheet.getRange(1, 1, 1, 13).setFontWeight("bold").setBackground("#F3F4F6");
    }

    var data = JSON.parse(e.postData.contents);
    
    // معالجة تفاصيل المنتجات والمقاسات
    var itemsSummary = "";
    var sizesSummary = "";
    var colorsSummary = "";
    var totalQty = 0;

    if (data.items && data.items.length > 0) {
      itemsSummary = data.items.map(function(item) {
        return item.productName + " (" + item.quantity + "x)";
      }).join(" | ");

      sizesSummary = data.items.map(function(item) {
        return item.selectedSize;
      }).join(", ");

      colorsSummary = data.items.map(function(item) {
        return item.selectedColor;
      }).join(", ");

      totalQty = data.items.reduce(function(acc, item) {
        return acc + item.quantity;
      }, 0);
    }

    sheet.appendRow([
      data.createdAt || new Date().toLocaleString(),
      data.orderNumber,
      data.customerName,
      "'" + data.phone, // إضافة علامة الاقتباس لحفظ أصفار الهاتف
      data.city,
      data.address,
      itemsSummary,
      sizesSummary,
      colorsSummary,
      totalQty,
      data.totalPrice + " " + (data.currency || ""),
      data.status || "جديد",
      data.notes || ""
    ]);

    return ContentService
      .createTextOutput(JSON.stringify({ result: "success", orderNumber: data.orderNumber }))
      .setMimeType(ContentService.MimeType.JSON);
  } catch (err) {
    return ContentService
      .createTextOutput(JSON.stringify({ result: "error", error: err.toString() }))
      .setMimeType(ContentService.MimeType.JSON);
  } finally {
    lock.releaseLock();
  }
}
`;

export async function sendOrderToGoogleSheet(
  order: Order,
  webhookUrl: string,
  currency: string = 'د.م'
): Promise<{ success: boolean; message: string }> {
  if (!webhookUrl || !webhookUrl.trim()) {
    return { success: false, message: 'لم يتم إدخال رابط Google Sheets Webhook في الإعدادات.' };
  }

  const payload = {
    ...order,
    currency,
  };

  try {
    // We send payload to Google Apps Script or Webhook
    // Note: Google Apps Script Web App redirects (302), in browser fetch, mode 'no-cors' is typically used
    // or standard JSON POST for Make/Zapier/custom webhooks.
    await fetch(webhookUrl.trim(), {
      method: 'POST',
      headers: {
        'Content-Type': 'text/plain;charset=utf-8',
      },
      body: JSON.stringify(payload),
      mode: 'no-cors', // Essential for Google Apps Script Web App cross-origin redirects
    });

    return {
      success: true,
      message: 'تم إرسال الطلب بنجاح إلى جدول Google Sheets!',
    };
  } catch (error: any) {
    console.error('Google Sheets sync error:', error);
    return {
      success: false,
      message: `فشل الإرسال: ${error?.message || 'خطأ في الاتصال بالرابط'}`,
    };
  }
}

export async function testWebhook(webhookUrl: string): Promise<{ success: boolean; message: string }> {
  if (!webhookUrl || !webhookUrl.trim()) {
    return { success: false, message: 'يرجى إدخال الرابط أولاً للاختبار.' };
  }

  const testData = {
    orderNumber: '#TEST-9999',
    createdAt: new Date().toLocaleString('ar-MA'),
    customerName: 'تجربة فحص الربط',
    phone: '0661234567',
    city: 'الدار البيضاء',
    address: 'حي المعاريف - تجربة تحقق',
    items: [
      {
        productName: 'قفطان ملكي فاخر (تجربة)',
        quantity: 1,
        selectedSize: 'M',
        selectedColor: 'أزرق ملكي',
      },
    ],
    totalPrice: 349,
    currency: 'د.م',
    status: 'تجربة',
    notes: 'هذا اختبار للتأكد من وصول البيانات لجدولك',
  };

  try {
    await fetch(webhookUrl.trim(), {
      method: 'POST',
      headers: {
        'Content-Type': 'text/plain;charset=utf-8',
      },
      body: JSON.stringify(testData),
      mode: 'no-cors',
    });
    return { success: true, message: 'تم إرسال إشارة الفحص بنجاح! تفقد جدولك في Google Sheets.' };
  } catch (err: any) {
    return { success: false, message: `تعذر الوصول إلى الرابط: ${err?.message || 'خطأ غير معروف'}` };
  }
}

export function exportOrdersToCSV(orders: Order[], currency: string = 'ر.س') {
  if (orders.length === 0) return;

  const headers = [
    'رقم الطلب',
    'التاريخ',
    'اسم العميل',
    'الهاتف',
    'المدينة',
    'العنوان التفصيلي',
    'المنتجات',
    'المقاسات',
    'الألوان',
    'الكمية',
    'المبلغ الإجمالي',
    'الحالة',
    'ملاحظات',
  ];

  const rows = orders.map((o) => {
    const productsStr = o.items.map((i) => `${i.productName} (x${i.quantity})`).join(' | ');
    const sizesStr = o.items.map((i) => i.selectedSize).join(', ');
    const colorsStr = o.items.map((i) => i.selectedColor).join(', ');
    const totalQty = o.items.reduce((sum, i) => sum + i.quantity, 0);

    return [
      `"${o.orderNumber}"`,
      `"${o.createdAt}"`,
      `"${o.customerName}"`,
      `"'\t${o.phone}"`,
      `"${o.city}"`,
      `"${o.address.replace(/"/g, '""')}"`,
      `"${productsStr.replace(/"/g, '""')}"`,
      `"${sizesStr}"`,
      `"${colorsStr}"`,
      totalQty,
      `"${o.totalPrice} ${currency}"`,
      `"${o.status}"`,
      `"${(o.notes || '').replace(/"/g, '""')}"`,
    ];
  });

  const csvContent = '\uFEFF' + [headers.join(','), ...rows.map((r) => r.join(','))].join('\n');
  const blob = new Blob([csvContent], { type: 'text/csv;charset=utf-8;' });
  const url = URL.createObjectURL(blob);
  const link = document.createElement('a');
  link.setAttribute('href', url);
  link.setAttribute('download', `طلبات_المتجر_${new Date().toISOString().slice(0, 10)}.csv`);
  document.body.appendChild(link);
  link.click();
  document.body.removeChild(link);
}
