import { Product, Order, StoreSettings } from '../types';

export const apiService = {
  async getProducts(): Promise<Product[]> {
    try {
      const res = await fetch('/api/products');
      if (!res.ok) throw new Error('Failed to fetch products');
      return await res.json();
    } catch (err) {
      console.warn('API getProducts error, falling back:', err);
      throw err;
    }
  },

  async saveProduct(product: Product): Promise<Product> {
    const res = await fetch('/api/products', {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify(product),
    });
    if (!res.ok) throw new Error('Failed to save product');
    return await res.json();
  },

  async deleteProduct(id: string): Promise<void> {
    const res = await fetch(`/api/products/${id}`, { method: 'DELETE' });
    if (!res.ok) throw new Error('Failed to delete product');
  },

  async clearAllProducts(): Promise<void> {
    const res = await fetch('/api/products/clear', { method: 'POST' });
    if (!res.ok) throw new Error('Failed to clear products');
  },

  async getOrders(): Promise<Order[]> {
    try {
      const res = await fetch('/api/orders');
      if (!res.ok) throw new Error('Failed to fetch orders');
      return await res.json();
    } catch (err) {
      console.warn('API getOrders error, falling back:', err);
      throw err;
    }
  },

  async createOrder(order: Order): Promise<Order> {
    const res = await fetch('/api/orders', {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify(order),
    });
    if (!res.ok) throw new Error('Failed to create order');
    return await res.json();
  },

  async updateOrderStatus(id: string, status: string): Promise<void> {
    const res = await fetch(`/api/orders/${id}`, {
      method: 'PATCH',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({ status }),
    });
    if (!res.ok) throw new Error('Failed to update order status');
  },

  async deleteOrder(id: string): Promise<void> {
    const res = await fetch(`/api/orders/${id}`, { method: 'DELETE' });
    if (!res.ok) throw new Error('Failed to delete order');
  },

  async clearAllOrders(): Promise<void> {
    const res = await fetch('/api/orders/clear', { method: 'POST' });
    if (!res.ok) throw new Error('Failed to clear orders');
  },

  async getSettings(): Promise<StoreSettings> {
    try {
      const res = await fetch('/api/settings');
      if (!res.ok) throw new Error('Failed to fetch settings');
      return await res.json();
    } catch (err) {
      console.warn('API getSettings error, falling back:', err);
      throw err;
    }
  },

  async saveSettings(settings: StoreSettings): Promise<StoreSettings> {
    const res = await fetch('/api/settings', {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify(settings),
    });
    if (!res.ok) throw new Error('Failed to save settings');
    return await res.json();
  },

  async restoreDemoData(): Promise<{ products: Product[]; orders: Order[] }> {
    const res = await fetch('/api/store/restore-demo', { method: 'POST' });
    if (!res.ok) throw new Error('Failed to restore demo data');
    return await res.json();
  },

  async uploadImage(base64Data: string): Promise<string> {
    try {
      const res = await fetch('/api/upload', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ image: base64Data }),
      });
      if (res.ok) {
        const data = await res.json();
        return data.url;
      }
    } catch (e) {
      console.warn('Direct upload failed, fallback to data url:', e);
    }
    return base64Data;
  },
};
