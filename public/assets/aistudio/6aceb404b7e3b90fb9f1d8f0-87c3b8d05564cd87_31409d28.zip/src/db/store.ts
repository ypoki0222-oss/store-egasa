import { db } from '../../db/index.ts';
import { productsTable, ordersTable, settingsTable } from '../../db/schema.ts';
import { eq, desc } from 'drizzle-orm';
import { Product, Order, StoreSettings } from '../types/index.ts';
import { INITIAL_PRODUCTS, INITIAL_ORDERS, INITIAL_STORE_SETTINGS } from '../data/initialData.ts';

async function isDbInitialized(): Promise<boolean> {
  try {
    const rows = await db.select().from(settingsTable).where(eq(settingsTable.key, 'db_initialized'));
    return rows.length > 0;
  } catch {
    return false;
  }
}

export async function markDbInitialized(): Promise<void> {
  try {
    await db
      .insert(settingsTable)
      .values({
        key: 'db_initialized',
        data: { initialized: true, timestamp: new Date().toISOString() },
        updatedAt: new Date(),
      })
      .onConflictDoNothing();
  } catch (err) {
    console.warn('Failed to mark db initialized:', err);
  }
}

export async function getProducts(): Promise<Product[]> {
  try {
    const rows = await db.select().from(productsTable).orderBy(desc(productsTable.createdAt));
    const initialized = await isDbInitialized();

    // Auto-seed ONLY if this is the very first deployment and the database hasn't been initialized yet
    if (rows.length === 0 && !initialized) {
      try {
        await seedInitialProducts();
        await markDbInitialized();
        const seeded = await db.select().from(productsTable).orderBy(desc(productsTable.createdAt));
        return formatProducts(seeded);
      } catch (err) {
        console.warn('Seeding initial products skipped or failed:', err);
      }
    }
    return formatProducts(rows);
  } catch (error) {
    console.error('Failed to get products:', error);
    throw new Error('Database query failed while fetching products.', { cause: error });
  }
}

export async function upsertProduct(product: Product): Promise<Product> {
  try {
    const existing = await db.select().from(productsTable).where(eq(productsTable.id, product.id));
    const prev = existing.length > 0 ? existing[0] : null;

    const values = {
      id: product.id,
      name: product.name,
      slug: product.slug || prev?.slug || product.name.toLowerCase().replace(/\s+/g, '-'),
      price: product.price,
      originalPrice: product.originalPrice ?? prev?.originalPrice ?? null,
      category: product.category || prev?.category || 'ملابس',
      description: product.description || prev?.description || '',
      features: (product.features && product.features.length > 0) ? product.features : (prev?.features || []),
      inStock: product.inStock ?? prev?.inStock ?? true,
      badge: product.badge !== undefined ? product.badge : (prev?.badge || ''),
      rating: product.rating || prev?.rating || 4.97,
      reviewsCount: product.reviewsCount || prev?.reviewsCount || 184,
      sizes: (product.sizes && product.sizes.length > 0) ? product.sizes : (prev?.sizes || ['S', 'M', 'L', 'XL', '2XL', '3XL']),
      colors: (product.colors && product.colors.length > 0) ? product.colors : (prev?.colors || []),
      fabrics: (product.fabrics && product.fabrics.length > 0) ? product.fabrics : (prev?.fabrics || ['Montonie Lycra']),
      imageSvgType: product.imageSvgType || prev?.imageSvgType || 'survette',
      customImage: product.customImage || prev?.customImage || null,
      galleryImages: (product.galleryImages && product.galleryImages.length > 0) ? product.galleryImages : (prev?.galleryImages || []),
      bundleOffer: product.bundleOffer || prev?.bundleOffer || null,
      updatedAt: new Date(),
    };

    const result = await db
      .insert(productsTable)
      .values({
        ...values,
        createdAt: new Date(),
      })
      .onConflictDoUpdate({
        target: productsTable.id,
        set: values,
      })
      .returning();

    return formatProduct(result[0]);
  } catch (error) {
    console.error('Failed to upsert product:', error);
    throw new Error('Database query failed while saving product.', { cause: error });
  }
}

export async function deleteProduct(id: string): Promise<boolean> {
  try {
    await db.delete(productsTable).where(eq(productsTable.id, id));
    return true;
  } catch (error) {
    console.error('Failed to delete product:', error);
    throw new Error('Database query failed while deleting product.', { cause: error });
  }
}

export async function clearAllProducts(): Promise<boolean> {
  try {
    await db.delete(productsTable);
    await markDbInitialized();
    return true;
  } catch (error) {
    console.error('Failed to clear products:', error);
    throw new Error('Database query failed while clearing products.', { cause: error });
  }
}

export async function getOrders(): Promise<Order[]> {
  try {
    const rows = await db.select().from(ordersTable).orderBy(desc(ordersTable.createdAt));
    return rows.map((r) => ({
      id: r.id,
      orderNumber: r.orderNumber,
      createdAt: r.createdAt.toISOString(),
      customerName: r.customerName,
      phone: r.phone,
      city: r.city,
      address: r.address,
      notes: r.notes || undefined,
      items: (r.items as any) || [],
      subtotal: r.subtotal,
      shippingCost: r.shippingCost,
      totalPrice: r.totalPrice,
      status: r.status as any,
      syncedToGoogleSheets: r.syncedToGoogleSheets,
      googleSheetsResponse: r.googleSheetsResponse || undefined,
    }));
  } catch (error) {
    console.error('Failed to get orders:', error);
    throw new Error('Database query failed while fetching orders.', { cause: error });
  }
}

export async function createOrder(order: Order): Promise<Order> {
  try {
    let orderDate = new Date();
    if (order.createdAt) {
      const parsed = new Date(order.createdAt);
      if (!isNaN(parsed.getTime())) {
        orderDate = parsed;
      }
    }

    const result = await db
      .insert(ordersTable)
      .values({
        id: order.id,
        orderNumber: order.orderNumber,
        customerName: order.customerName,
        phone: order.phone,
        city: order.city,
        address: order.address,
        notes: order.notes || null,
        items: order.items || [],
        subtotal: order.subtotal,
        shippingCost: order.shippingCost,
        totalPrice: order.totalPrice,
        status: order.status || 'new',
        syncedToGoogleSheets: order.syncedToGoogleSheets || false,
        googleSheetsResponse: order.googleSheetsResponse || null,
        createdAt: orderDate,
      })
      .onConflictDoUpdate({
        target: ordersTable.id,
        set: {
          status: order.status || 'new',
          syncedToGoogleSheets: order.syncedToGoogleSheets || false,
          googleSheetsResponse: order.googleSheetsResponse || null,
        },
      })
      .returning();

    const r = result[0];
    return {
      id: r.id,
      orderNumber: r.orderNumber,
      createdAt: r.createdAt.toISOString(),
      customerName: r.customerName,
      phone: r.phone,
      city: r.city,
      address: r.address,
      notes: r.notes || undefined,
      items: (r.items as any) || [],
      subtotal: r.subtotal,
      shippingCost: r.shippingCost,
      totalPrice: r.totalPrice,
      status: r.status as any,
      syncedToGoogleSheets: r.syncedToGoogleSheets,
      googleSheetsResponse: r.googleSheetsResponse || undefined,
    };
  } catch (error) {
    console.error('Failed to create order in database:', error);
    throw new Error('Database query failed while creating order.', { cause: error });
  }
}

export async function updateOrderStatus(orderId: string, status: string): Promise<boolean> {
  try {
    await db.update(ordersTable).set({ status }).where(eq(ordersTable.id, orderId));
    return true;
  } catch (error) {
    console.error('Failed to update order status:', error);
    throw new Error('Database query failed while updating order.', { cause: error });
  }
}

export async function deleteOrder(orderId: string): Promise<boolean> {
  try {
    await db.delete(ordersTable).where(eq(ordersTable.id, orderId));
    return true;
  } catch (error) {
    console.error('Failed to delete order:', error);
    throw new Error('Database query failed while deleting order.', { cause: error });
  }
}

export async function clearAllOrders(): Promise<boolean> {
  try {
    await db.delete(ordersTable);
    return true;
  } catch (error) {
    console.error('Failed to clear orders:', error);
    throw new Error('Database query failed while clearing orders.', { cause: error });
  }
}

export async function getStoreSettings(): Promise<StoreSettings> {
  try {
    const rows = await db.select().from(settingsTable).where(eq(settingsTable.key, 'global_settings'));
    if (rows.length > 0 && rows[0].data) {
      return rows[0].data as StoreSettings;
    }
    // Seed default settings if not exists
    await db
      .insert(settingsTable)
      .values({
        key: 'global_settings',
        data: INITIAL_STORE_SETTINGS,
        updatedAt: new Date(),
      })
      .onConflictDoNothing();

    return INITIAL_STORE_SETTINGS;
  } catch (error) {
    console.error('Failed to get store settings:', error);
    return INITIAL_STORE_SETTINGS;
  }
}

export async function updateStoreSettings(settings: StoreSettings): Promise<StoreSettings> {
  try {
    await db
      .insert(settingsTable)
      .values({
        key: 'global_settings',
        data: settings,
        updatedAt: new Date(),
      })
      .onConflictDoUpdate({
        target: settingsTable.key,
        set: {
          data: settings,
          updatedAt: new Date(),
        },
      });

    return settings;
  } catch (error) {
    console.error('Failed to update store settings:', error);
    throw new Error('Database query failed while updating settings.', { cause: error });
  }
}

async function seedInitialProducts() {
  for (const p of INITIAL_PRODUCTS) {
    await upsertProduct(p);
  }
}

function formatProduct(r: any): Product {
  return {
    id: r.id,
    name: r.name,
    slug: r.slug,
    price: r.price,
    originalPrice: r.originalPrice ?? undefined,
    category: r.category,
    description: r.description,
    features: r.features || [],
    inStock: r.inStock,
    badge: r.badge || undefined,
    rating: r.rating,
    reviewsCount: r.reviewsCount,
    sizes: r.sizes || [],
    colors: r.colors || [],
    fabrics: r.fabrics || [],
    imageSvgType: r.imageSvgType,
    customImage: r.customImage || undefined,
    galleryImages: r.galleryImages || [],
    bundleOffer: r.bundleOffer || undefined,
  };
}

function formatProducts(rows: any[]): Product[] {
  return rows.map(formatProduct);
}

export async function restoreDemoData(): Promise<{ products: Product[]; orders: Order[] }> {
  try {
    // Clear existing and re-seed products
    await db.delete(productsTable);
    await seedInitialProducts();
    await markDbInitialized();

    // Clear existing and re-seed orders
    await db.delete(ordersTable);
    for (const o of INITIAL_ORDERS) {
      await createOrder(o);
    }

    const currentProducts = await getProducts();
    const currentOrders = await getOrders();
    return { products: currentProducts, orders: currentOrders };
  } catch (error) {
    console.error('Failed to restore demo data:', error);
    throw new Error('Database query failed while restoring demo data.', { cause: error });
  }
}
