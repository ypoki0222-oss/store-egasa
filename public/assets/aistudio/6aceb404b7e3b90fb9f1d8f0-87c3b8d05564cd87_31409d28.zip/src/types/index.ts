export type OrderStatus = 'new' | 'confirmed' | 'shipping' | 'delivered' | 'cancelled';

export interface ProductOptionColor {
  name: string;
  hex: string;
}

export interface ProductBundleOffer {
  enabled: boolean;
  label: string; // e.g. "عرض قطعتين (توفير خاص + شحن مجاني)"
  price: number; // e.g. 299
  originalPrice?: number; // e.g. 450
  stickerText: string; // e.g. "عرض حبتين"
  tier3Enabled?: boolean;
  tier3Label?: string;
  tier3Price?: number;
  tier3OriginalPrice?: number;
  tier3StickerText?: string;
}

export interface Product {
  id: string;
  name: string;
  slug: string;
  price: number;
  originalPrice?: number;
  category: string;
  description: string;
  features: string[];
  inStock: boolean;
  badge?: string;
  rating: number;
  reviewsCount: number;
  sizes: string[];
  colors: ProductOptionColor[];
  fabrics: string[];
  imageSvgType: 'blazer' | 'dress' | 'coat' | 'shirt' | 'abaya' | 'suit' | 'caftan' | 'djellaba' | 'survette';
  customImage?: string;
  galleryImages?: string[];
  bundleOffer?: ProductBundleOffer;
}

export interface OrderItem {
  productId: string;
  productName: string;
  price: number;
  quantity: number;
  selectedSize: string;
  selectedColor: string;
  selectedFabric?: string;
  imageSvgType: string;
}

export interface Order {
  id: string;
  orderNumber: string;
  createdAt: string;
  customerName: string;
  phone: string;
  city: string;
  address: string;
  notes?: string;
  items: OrderItem[];
  subtotal: number;
  shippingCost: number;
  totalPrice: number;
  status: OrderStatus;
  syncedToGoogleSheets: boolean;
  googleSheetsResponse?: string;
}

export interface PixelEventLog {
  id: string;
  timestamp: string;
  pixelType: 'facebook' | 'tiktok' | 'snapchat' | 'google' | 'custom';
  eventName: string;
  payload: Record<string, any>;
}

export interface PixelSettings {
  facebookPixelId: string;
  facebookEnabled: boolean;
  tiktokPixelId: string;
  tiktokEnabled: boolean;
  snapchatPixelId: string;
  snapchatEnabled: boolean;
  googleAnalyticsId: string;
  googleEnabled: boolean;
  customHeadScript: string;
  customBodyScript: string;
}

export interface AnnouncementSettings {
  enabled: boolean;
  text: string;
  badgeText: string;
  linkText?: string;
  showCountdown: boolean;
  countdownHours: number;
  bgColor: string;
  textColor: string;
}

export interface WhatsAppSettings {
  enabled: boolean;
  phoneNumber: string; // e.g. "966501234567"
  position: 'left' | 'right';
  greetingMessage: string;
  orderPrefillTemplate: string;
}

export interface HomeBannerSettings {
  enabled: boolean;
  title: string;
  subtitle?: string;
  discountText: string;
  ctaText: string;
  bgGradient: string;
  imageUrl?: string;
}

export interface StoreSettings {
  storeName: string;
  tagline: string;
  currency: string;
  adminPassword?: string;
  autoOpenWhatsAppOnOrder?: boolean;
  freeShippingThreshold: number;
  standardShippingCost: number;
  whatsapp: WhatsAppSettings;
  announcement: AnnouncementSettings;
  homeBanner: HomeBannerSettings;
  googleSheetsWebhookUrl: string;
  googleSheetsAutoSync: boolean;
  pixel: PixelSettings;
}
