import React, { useState, useEffect, useRef } from 'react';
import {
  Product,
  Order,
  StoreSettings,
  OrderStatus,
  PixelSettings,
} from './types';
import {
  INITIAL_PRODUCTS,
  INITIAL_ORDERS,
  INITIAL_STORE_SETTINGS,
} from './data/initialData';
import { AnnouncementBar } from './components/AnnouncementBar';
import { Navbar } from './components/Navbar';
import { PromoSlider } from './components/PromoSlider';
import { ProductCard } from './components/ProductCard';
import { ProductDetailModal } from './components/ProductDetailModal';
import { CartDrawer } from './components/CartDrawer';
import { OrderSuccessModal } from './components/OrderSuccessModal';
import { FloatingWhatsApp } from './components/FloatingWhatsApp';
import { BottomNav } from './components/BottomNav';
import { ProductPageView } from './components/ProductPageView';
import { AdminDashboard } from './components/admin/AdminDashboard';
import { AdminPasswordModal } from './components/admin/AdminPasswordModal';
import { pixelService } from './services/pixelService';
import { apiService } from './services/apiService';
import {
  Search,
  Sparkles,
  ShieldCheck,
  Truck,
  RotateCcw,
  ShoppingBag,
  Lock,
} from 'lucide-react';

const DEMO_PRODUCT_IDS = new Set([
  'prod-caftan-1',
  'prod-djellaba-1',
  'prod-blazer-1',
  'prod-dress-1',
  'prod-coat-1',
  'prod-suit-1',
  'prod-shirt-1',
  'prod-abaya-1',
]);

// Helper to resolve product from URL synchronously on initial render
function getInitialProductFromUrl(pool: Product[]): Product | null {
  if (typeof window === 'undefined') return null;
  try {
    const url = new URL(window.location.href);
    const productParam =
      url.searchParams.get('p') ||
      url.searchParams.get('product') ||
      url.searchParams.get('id');

    let hashParam: string | null = null;
    if (window.location.hash) {
      const cleanHash = window.location.hash.replace(/^#\/?/, '');
      if (cleanHash.startsWith('product/')) {
        hashParam = cleanHash.replace('product/', '');
      } else if (cleanHash.startsWith('p/')) {
        hashParam = cleanHash.replace('p/', '');
      }
    }

    const target = productParam || hashParam;
    if (!target) return null;

    const cleanTarget = decodeURIComponent(target).trim().toLowerCase();
    return (
      pool.find(
        (p) =>
          p.slug.toLowerCase() === cleanTarget ||
          p.id.toLowerCase() === cleanTarget ||
          decodeURIComponent(p.slug).trim().toLowerCase() === cleanTarget ||
          (p.slug.toLowerCase().includes('survette') && cleanTarget.includes('survette')) ||
          p.name.toLowerCase() === cleanTarget
      ) || null
    );
  } catch {
    return null;
  }
}

export default function App() {
  // Load stored state or fallback to defaults
  const [storeSettings, setStoreSettings] = useState<StoreSettings>(() => {
    try {
      const stored = localStorage.getItem('egasa_store_settings_v3');
      if (stored) {
        return JSON.parse(stored);
      }
      return INITIAL_STORE_SETTINGS;
    } catch {
      return INITIAL_STORE_SETTINGS;
    }
  });

  const [products, setProducts] = useState<Product[]>(() => {
    try {
      if (localStorage.getItem('egasa_store_cleared') === 'true') {
        return [];
      }
      const stored = localStorage.getItem('egasa_store_products_v3');
      if (stored !== null) {
        const parsed = JSON.parse(stored);
        if (Array.isArray(parsed)) {
          const filtered = parsed.filter((p: Product) => !DEMO_PRODUCT_IDS.has(p.id));
          if (filtered.length > 0) {
            return filtered;
          }
        }
      }
      return INITIAL_PRODUCTS;
    } catch {
      return INITIAL_PRODUCTS;
    }
  });

  const [orders, setOrders] = useState<Order[]>(() => {
    try {
      if (localStorage.getItem('egasa_orders_cleared') === 'true') {
        return [];
      }
      const stored =
        localStorage.getItem('egasa_store_orders_v3') ||
        localStorage.getItem('egasa_store_orders');
      if (stored !== null) {
        return JSON.parse(stored);
      }
      return INITIAL_ORDERS;
    } catch {
      return INITIAL_ORDERS;
    }
  });

  // UI state - Synchronously resolve product from URL if visiting a direct product link
  const [selectedProduct, setSelectedProduct] = useState<Product | null>(() => {
    return getInitialProductFromUrl(products);
  });

  // If a product param exists in the URL but was not matched immediately in initial cache, hold view until backend responds
  const [isRoutePending, setIsRoutePending] = useState<boolean>(() => {
    if (typeof window === 'undefined') return false;
    try {
      const url = new URL(window.location.href);
      const target =
        url.searchParams.get('p') ||
        url.searchParams.get('product') ||
        url.searchParams.get('id') ||
        (window.location.hash && (window.location.hash.startsWith('#product/') || window.location.hash.startsWith('#p/')));
      return Boolean(target && !getInitialProductFromUrl(products));
    } catch {
      return false;
    }
  });

  const [isAdminOpen, setIsAdminOpen] = useState(false);
  const [isAdminPasswordModalOpen, setIsAdminPasswordModalOpen] = useState(false);
  const [isDetailModalOpen, setIsDetailModalOpen] = useState(false);
  const [isCartOpen, setIsCartOpen] = useState(false);
  const [completedOrder, setCompletedOrder] = useState<Order | null>(null);
  const [activeMobileTab, setActiveMobileTab] = useState<'home' | 'categories' | 'favorites'>('home');

  // Cart items
  const [cartItems, setCartItems] = useState<
    {
      product: Product;
      selectedSize: string;
      selectedColor: string;
      selectedFabric?: string;
      quantity: number;
    }[]
  >([]);

  // Search
  const [searchQuery, setSearchQuery] = useState<string>('');
  const searchInputRef = useRef<HTMLInputElement>(null);

  // Persist state changes
  useEffect(() => {
    try {
      localStorage.setItem('egasa_store_settings_v3', JSON.stringify(storeSettings));
    } catch {
      // ignore
    }
  }, [storeSettings]);

  useEffect(() => {
    try {
      localStorage.setItem('egasa_store_products_v3', JSON.stringify(products));
    } catch {
      // ignore
    }
  }, [products]);

  useEffect(() => {
    try {
      localStorage.setItem('egasa_store_orders_v3', JSON.stringify(orders));
    } catch {
      // ignore
    }
  }, [orders]);

  // Load products, orders, and settings from Cloud SQL backend
  useEffect(() => {
    let active = true;
    const fetchBackendData = async () => {
      try {
        const [cloudProducts, cloudOrders, cloudSettings] = await Promise.allSettled([
          apiService.getProducts(),
          apiService.getOrders(),
          apiService.getSettings(),
        ]);

        if (!active) return;

        if (
          cloudProducts.status === 'fulfilled' &&
          Array.isArray(cloudProducts.value)
        ) {
          setProducts(cloudProducts.value);
          setIsRoutePending(false);
          // If a product is already selected, update it with fresh cloud data; or resolve from URL if needed
          setSelectedProduct((current) => {
            if (!current) {
              return getInitialProductFromUrl(cloudProducts.value);
            }
            const fresh = cloudProducts.value.find(
              (p) => p.id === current.id || p.slug.toLowerCase() === current.slug.toLowerCase()
            );
            return fresh || current;
          });
          if (cloudProducts.value.length === 0) {
            localStorage.setItem('egasa_store_cleared', 'true');
          } else {
            localStorage.removeItem('egasa_store_cleared');
          }
        } else {
          setIsRoutePending(false);
        }

        if (
          cloudOrders.status === 'fulfilled' &&
          Array.isArray(cloudOrders.value)
        ) {
          setOrders(cloudOrders.value);
          if (cloudOrders.value.length === 0) {
            localStorage.setItem('egasa_orders_cleared', 'true');
          } else {
            localStorage.removeItem('egasa_orders_cleared');
          }
        }

        if (
          cloudSettings.status === 'fulfilled' &&
          cloudSettings.value
        ) {
          setStoreSettings((prev) => ({ ...prev, ...cloudSettings.value }));
        }
      } catch (err) {
        console.warn('Backend data initial load skipped:', err);
      }
    };

    fetchBackendData();
    return () => {
      active = false;
    };
  }, []);

  // Keep selectedProduct in sync with the latest products data (e.g. when merchant edits price)
  useEffect(() => {
    if (selectedProduct) {
      const match = products.find(
        (p) => p.id === selectedProduct.id || p.slug.toLowerCase() === selectedProduct.slug.toLowerCase()
      );
      if (
        match &&
        (match.price !== selectedProduct.price ||
          match.name !== selectedProduct.name ||
          match.customImage !== selectedProduct.customImage ||
          match.originalPrice !== selectedProduct.originalPrice)
      ) {
        setSelectedProduct(match);
      }
    }
  }, [products]);

  // Sync pixels and track PageView on initial mount
  useEffect(() => {
    pixelService.syncPixels(storeSettings.pixel);
    pixelService.track(
      'PageView',
      {
        page_title: `متجر ${storeSettings.storeName}`,
        page_location: window.location.href,
      },
      storeSettings.pixel
    );
  }, [storeSettings.pixel, storeSettings.storeName]);

  // Request Admin access (Hidden from visitors, protected by password)
  const handleRequestAdmin = () => {
    let isAuthed = false;
    try {
      isAuthed = sessionStorage.getItem('egasa_admin_auth') === 'true';
    } catch {
      isAuthed = false;
    }

    if (isAuthed) {
      setIsAdminOpen(true);
    } else {
      setIsAdminPasswordModalOpen(true);
    }
  };

  const handleAdminLogout = () => {
    try {
      sessionStorage.removeItem('egasa_admin_auth');
    } catch {
      // ignore
    }
    setIsAdminOpen(false);
    setActiveMobileTab('home');
  };

  // Dedicated URL routing for product ads (?p=slug or ?product=slug or ?id=id) and EdgeOne compatibility
  useEffect(() => {
    const checkUrlRoute = () => {
      try {
        const url = new URL(window.location.href);
        const productParam =
          url.searchParams.get('p') ||
          url.searchParams.get('product') ||
          url.searchParams.get('id');

        let hashParam: string | null = null;
        if (window.location.hash) {
          const cleanHash = window.location.hash.replace(/^#\/?/, '');
          if (cleanHash.startsWith('product/')) {
            hashParam = cleanHash.replace('product/', '');
          } else if (cleanHash.startsWith('p/')) {
            hashParam = cleanHash.replace('p/', '');
          } else if (cleanHash === 'admin') {
            handleRequestAdmin();
          }
        }

        const targetSlugOrId = productParam || hashParam;

        if (targetSlugOrId) {
          const cleanTarget = decodeURIComponent(targetSlugOrId).trim().toLowerCase();
          const matched = products.find(
            (p) =>
              p.slug.toLowerCase() === cleanTarget ||
              p.id.toLowerCase() === cleanTarget ||
              decodeURIComponent(p.slug).trim().toLowerCase() === cleanTarget ||
              (p.slug.toLowerCase().includes('survette') && cleanTarget.includes('survette')) ||
              p.name.toLowerCase() === cleanTarget
          );
          if (matched) {
            setSelectedProduct(matched);
            setIsRoutePending(false);
            document.title = `${matched.name} | ${storeSettings.storeName}`;
            return;
          }
        } else {
          setIsRoutePending(false);
        }

        if (url.searchParams.has('admin')) {
          handleRequestAdmin();
        }
      } catch {
        // ignore url parse error
      }
    };

    checkUrlRoute();

    const handlePopState = () => {
      checkUrlRoute();
    };

    window.addEventListener('popstate', handlePopState);

    // Keyboard shortcut: Ctrl + Shift + A opens admin login modal
    const handleKeyDown = (e: KeyboardEvent) => {
      if ((e.ctrlKey || e.metaKey) && e.shiftKey && (e.key === 'a' || e.key === 'A')) {
        e.preventDefault();
        handleRequestAdmin();
      }
    };
    window.addEventListener('keydown', handleKeyDown);

    return () => {
      window.removeEventListener('popstate', handlePopState);
      window.removeEventListener('keydown', handleKeyDown);
    };
  }, [products, storeSettings.storeName]);

  const filteredProducts = products.filter((p) => {
    const matchesSearch =
      p.name.toLowerCase().includes(searchQuery.toLowerCase()) ||
      p.description.toLowerCase().includes(searchQuery.toLowerCase()) ||
      (p.category && p.category.toLowerCase().includes(searchQuery.toLowerCase()));
    return matchesSearch;
  });

  const totalCartCount = cartItems.reduce((acc, item) => acc + item.quantity, 0);

  // Handlers for product navigation with direct URL updating
  const handleOpenProductDetail = (prod: Product) => {
    setSelectedProduct(prod);
    setIsRoutePending(false);
    setIsDetailModalOpen(false);
    try {
      const url = new URL(window.location.href);
      url.searchParams.set('p', prod.slug || prod.id);
      window.history.pushState({ productId: prod.id }, '', url.toString());
      document.title = `${prod.name} | ${storeSettings.storeName}`;
    } catch {
      // ignore
    }
  };

  const handleCloseProductView = () => {
    setSelectedProduct(null);
    setIsRoutePending(false);
    try {
      const url = new URL(window.location.href);
      url.searchParams.delete('p');
      url.searchParams.delete('product');
      url.searchParams.delete('id');
      window.history.pushState({}, '', url.pathname + (url.search ? url.search : ''));
      document.title = `${storeSettings.storeName} - ${storeSettings.tagline}`;
    } catch {
      // ignore
    }
  };

  const handleAddToCart = (newItem: {
    product: Product;
    selectedSize: string;
    selectedColor: string;
    selectedFabric?: string;
    quantity: number;
  }) => {
    setCartItems((prev) => {
      const existingIndex = prev.findIndex(
        (i) =>
          i.product.id === newItem.product.id &&
          i.selectedSize === newItem.selectedSize &&
          i.selectedColor === newItem.selectedColor
      );
      if (existingIndex > -1) {
        const updated = [...prev];
        updated[existingIndex].quantity += newItem.quantity;
        return updated;
      }
      return [...prev, newItem];
    });
  };

  const handleUpdateCartQuantity = (index: number, newQty: number) => {
    if (newQty <= 0) {
      setCartItems((prev) => prev.filter((_, i) => i !== index));
    } else {
      setCartItems((prev) => {
        const updated = [...prev];
        updated[index].quantity = newQty;
        return updated;
      });
    }
  };

  const handleRemoveCartItem = (index: number) => {
    setCartItems((prev) => prev.filter((_, i) => i !== index));
  };

  const handleOrderSuccess = (newOrder: Order) => {
    setOrders((prev) => [newOrder, ...prev]);
    setCompletedOrder(newOrder);
    setCartItems([]);
    apiService.createOrder(newOrder).catch((err) => {
      console.warn('Failed to save order to database:', err);
    });
  };

  const handleUpdateOrderStatus = (orderId: string, status: OrderStatus) => {
    setOrders((prev) =>
      prev.map((o) => (o.id === orderId ? { ...o, status } : o))
    );
    apiService.updateOrderStatus(orderId, status).catch((err) => {
      console.warn('Failed to update order status in database:', err);
    });
  };

  const handleSaveProduct = (updatedProduct: Product) => {
    setProducts((prev) => {
      const idx = prev.findIndex((p) => p.id === updatedProduct.id);
      if (idx > -1) {
        const copy = [...prev];
        copy[idx] = updatedProduct;
        return copy;
      }
      return [updatedProduct, ...prev];
    });

    // Update selectedProduct immediately if user is viewing this product
    setSelectedProduct((prev) => (prev?.id === updatedProduct.id ? updatedProduct : prev));

    try {
      // Persist to localStorage immediately
      const current = localStorage.getItem('egasa_store_products_v3');
      let arr: Product[] = [];
      if (current) {
        try {
          arr = JSON.parse(current);
        } catch {
          arr = [];
        }
      }
      const idx = arr.findIndex((p) => p.id === updatedProduct.id);
      if (idx > -1) {
        arr[idx] = updatedProduct;
      } else {
        arr.unshift(updatedProduct);
      }
      localStorage.setItem('egasa_store_products_v3', JSON.stringify(arr));
      localStorage.removeItem('egasa_store_cleared');
    } catch {
      // ignore
    }

    apiService.saveProduct(updatedProduct).catch((err) => {
      console.warn('Failed to save product to database:', err);
    });
  };

  const handleDeleteProduct = (productId: string) => {
    setProducts((prev) => prev.filter((p) => p.id !== productId));
    apiService.deleteProduct(productId).catch((err) => {
      console.warn('Failed to delete product from database:', err);
    });
  };

  const handleRefreshSync = (orderId: string) => {
    setOrders((prev) =>
      prev.map((o) => (o.id === orderId ? { ...o, syncedToGoogleSheets: true } : o))
    );
  };

  const handleClearOrders = () => {
    setOrders([]);
    try {
      localStorage.setItem('egasa_orders_cleared', 'true');
      localStorage.setItem('egasa_store_orders_v3', JSON.stringify([]));
      localStorage.removeItem('egasa_store_orders');
    } catch {
      // ignore
    }
    apiService.clearAllOrders().catch((err) => {
      console.warn('Failed to clear orders from database:', err);
    });
  };

  const handleClearProducts = () => {
    setProducts([]);
    try {
      localStorage.setItem('egasa_store_cleared', 'true');
      localStorage.setItem('egasa_store_products_v3', JSON.stringify([]));
    } catch {
      // ignore
    }
    apiService.clearAllProducts().catch((err) => {
      console.warn('Failed to clear products from database:', err);
    });
  };

  const handleClearAllDemoData = () => {
    handleClearOrders();
    handleClearProducts();
  };

  const handleRestoreDemoData = () => {
    apiService
      .restoreDemoData()
      .then((res) => {
        setProducts(res.products);
        setOrders(res.orders);
        try {
          localStorage.removeItem('egasa_store_cleared');
          localStorage.removeItem('egasa_orders_cleared');
          localStorage.setItem('egasa_store_products_v3', JSON.stringify(res.products));
          localStorage.setItem('egasa_store_orders_v3', JSON.stringify(res.orders));
        } catch {
          // ignore
        }
      })
      .catch((err) => {
        console.warn('Failed to restore demo data via API:', err);
        setProducts(INITIAL_PRODUCTS);
        setOrders(INITIAL_ORDERS);
        try {
          localStorage.removeItem('egasa_store_cleared');
          localStorage.removeItem('egasa_orders_cleared');
          localStorage.setItem('egasa_store_products_v3', JSON.stringify(INITIAL_PRODUCTS));
          localStorage.setItem('egasa_store_orders_v3', JSON.stringify(INITIAL_ORDERS));
        } catch {
          // ignore
        }
        INITIAL_PRODUCTS.forEach((p) => {
          apiService.saveProduct(p).catch(() => {});
        });
      });
  };

  const handleSaveStoreSettings = (newSettings: StoreSettings) => {
    setStoreSettings(newSettings);
    apiService.saveSettings(newSettings).catch((err) => {
      console.warn('Failed to save store settings to database:', err);
    });
  };

  const handleMobileTabChange = (tab: 'home' | 'categories' | 'favorites') => {
    setActiveMobileTab(tab);
    if (tab === 'categories') {
      document.getElementById('products-section')?.scrollIntoView({ behavior: 'smooth' });
    } else if (tab === 'home') {
      window.scrollTo({ top: 0, behavior: 'smooth' });
    }
  };

  // If Admin panel is open, show full admin dashboard
  if (isAdminOpen) {
    return (
      <div className="font-['Cairo',sans-serif]">
        <AdminDashboard
          products={products}
          orders={orders}
          settings={storeSettings}
          onClose={() => {
            setIsAdminOpen(false);
            setActiveMobileTab('home');
          }}
          onLogout={handleAdminLogout}
          onViewProduct={(prod) => {
            setIsAdminOpen(false);
            handleOpenProductDetail(prod);
          }}
          onUpdateOrderStatus={handleUpdateOrderStatus}
          onSaveProduct={handleSaveProduct}
          onDeleteProduct={handleDeleteProduct}
          onSaveStoreSettings={handleSaveStoreSettings}
          onSavePixelSettings={(pixel) =>
            handleSaveStoreSettings({ ...storeSettings, pixel })
          }
          onSaveGoogleSheets={(url, autoSync) =>
            handleSaveStoreSettings({
              ...storeSettings,
              googleSheetsWebhookUrl: url,
              googleSheetsAutoSync: autoSync,
            })
          }
          onRefreshSync={handleRefreshSync}
          onClearOrders={handleClearOrders}
          onClearProducts={handleClearProducts}
          onClearAllDemoData={handleClearAllDemoData}
          onRestoreDemoData={handleRestoreDemoData}
        />
      </div>
    );
  }

  // If a direct product route is requested (?p=... or ?id=...) but is still resolving from the backend, show clean loading view
  if (isRoutePending && !selectedProduct) {
    return (
      <div className="min-h-screen bg-[#F8F9FA] flex flex-col items-center justify-center font-['Cairo',sans-serif] px-4">
        <div className="w-10 h-10 border-3 border-teal-700 border-t-transparent rounded-full animate-spin mb-4"></div>
        <p className="text-sm font-bold text-stone-800">جاري تحميل تفاصيل المنتج...</p>
        <p className="text-xs text-stone-500 mt-1">لحظات قليلة ونكون معك</p>
      </div>
    );
  }

  // If viewing a product, show the dedicated ProductPageView layout matching the user's design
  if (selectedProduct) {
    return (
      <div className="font-['Cairo',sans-serif]">
        <ProductPageView
          product={selectedProduct}
          settings={storeSettings}
          cartCount={totalCartCount}
          onBack={handleCloseProductView}
          onOpenCart={() => setIsCartOpen(true)}
          onOrderSuccess={handleOrderSuccess}
        />

        {/* Cart Drawer */}
        <CartDrawer
          isOpen={isCartOpen}
          items={cartItems}
          settings={storeSettings}
          onClose={() => setIsCartOpen(false)}
          onUpdateQuantity={handleUpdateCartQuantity}
          onRemoveItem={handleRemoveCartItem}
          onOrderSuccess={handleOrderSuccess}
        />

        {/* Order Success Modal */}
        <OrderSuccessModal
          order={completedOrder}
          currency={storeSettings.currency}
          whatsappSettings={storeSettings.whatsapp}
          onClose={() => {
            setCompletedOrder(null);
            handleCloseProductView();
          }}
        />

        {/* Admin Password Modal */}
        <AdminPasswordModal
          isOpen={isAdminPasswordModalOpen}
          correctPassword={storeSettings.adminPassword || 'egasa2025'}
          onSuccess={() => {
            setIsAdminPasswordModalOpen(false);
            setIsAdminOpen(true);
          }}
          onClose={() => setIsAdminPasswordModalOpen(false)}
        />
      </div>
    );
  }

  return (
    <div className="min-h-screen bg-[#F8F9FA] text-[#1E232A] flex flex-col font-['Cairo',sans-serif] pb-16 sm:pb-0">
      {/* 1. Top Announcement Bar */}
      <AnnouncementBar settings={storeSettings.announcement} />

      {/* 2. Top Bar Navigation (With Brand EGASA, Search, and Cart - No Admin button visible to visitors) */}
      <Navbar
        storeName={storeSettings.storeName}
        cartCount={totalCartCount}
        onOpenCart={() => setIsCartOpen(true)}
        onSearchClick={() => {
          searchInputRef.current?.focus();
          document.getElementById('products-section')?.scrollIntoView({ behavior: 'smooth' });
        }}
      />

      {/* 3. Promo Slider (Controlled via Admin) */}
      <PromoSlider
        bannerSettings={storeSettings.homeBanner}
        onCtaClick={() => {
          document.getElementById('products-section')?.scrollIntoView({ behavior: 'smooth' });
        }}
      />

      {/* 4. Products Section */}
      <section id="products-section" className="py-4 sm:py-8 max-w-7xl mx-auto px-3 sm:px-6 lg:px-8 w-full flex-1">
        {/* Clean, minimal search bar */}
        <div className="flex justify-end mb-5">
          <div className="relative w-full sm:w-64">
            <Search className="w-4 h-4 text-stone-400 absolute right-3 top-2.5" />
            <input
              ref={searchInputRef}
              type="text"
              placeholder="بحث في الملابس..."
              value={searchQuery}
              onChange={(e) => setSearchQuery(e.target.value)}
              className="w-full pr-9 pl-3 py-2 bg-white border border-stone-200 rounded-xl text-xs focus:ring-2 focus:ring-teal-700 text-right shadow-2xs font-['Cairo'] placeholder:text-stone-400"
            />
          </div>
        </div>

        {/* Products Grid (2 columns on mobile) */}
        {products.length === 0 ? (
          <div className="py-16 text-center bg-white rounded-2xl border border-stone-200 p-8 space-y-4 max-w-lg mx-auto shadow-2xs">
            <div className="w-16 h-16 bg-teal-50 border border-teal-200 rounded-2xl flex items-center justify-center mx-auto text-teal-700">
              <ShoppingBag className="w-8 h-8" />
            </div>
            <div>
              <h3 className="text-base font-bold text-stone-900">المتجر مفرغ وجاهز لإضافة منتجاتك</h3>
              <p className="text-xs text-stone-500 mt-1">تم مسح المنتجات والبيانات التجريبية بنجاح. المتجر نظيف تماماً ويمكنك البدء بإضافة منتجاتك الحقيقية من لوحة التحكم.</p>
            </div>
            <div className="pt-2 flex flex-wrap items-center justify-center gap-3">
              <button
                onClick={() => setIsAdminPasswordModalOpen(true)}
                className="px-5 py-2.5 bg-teal-700 hover:bg-teal-800 text-white rounded-xl text-xs font-bold transition-all shadow-sm cursor-pointer"
              >
                الدخول للوحة التحكم وإضافة منتجات
              </button>
              <button
                onClick={handleRestoreDemoData}
                className="px-4 py-2.5 bg-stone-100 hover:bg-stone-200 text-stone-700 rounded-xl text-xs font-medium transition-all cursor-pointer"
              >
                استعادة المنتجات التجريبية للمعاينة
              </button>
            </div>
          </div>
        ) : filteredProducts.length === 0 ? (
          <div className="py-16 text-center bg-white rounded-2xl border border-stone-200 p-8 space-y-3">
            <ShoppingBag className="w-10 h-10 text-stone-300 mx-auto" />
            <h3 className="text-base font-bold text-stone-800">لا توجد نتائج مطابقة للبحث</h3>
            <p className="text-xs text-stone-500">جرب البحث بكلمة أخرى أو عرض كافة المنتجات.</p>
            <button
              onClick={() => {
                setSearchQuery('');
              }}
              className="px-4 py-2 bg-teal-700 text-white rounded-lg text-xs font-bold cursor-pointer"
            >
              عرض كافة المنتجات
            </button>
          </div>
        ) : (
          <div className="grid grid-cols-2 md:grid-cols-3 lg:grid-cols-4 gap-3 sm:gap-5">
            {filteredProducts.map((product) => (
              <ProductCard
                key={product.id}
                product={product}
                currency={storeSettings.currency}
                onSelect={handleOpenProductDetail}
                onQuickOrder={handleOpenProductDetail}
              />
            ))}
          </div>
        )}
      </section>

      {/* 5. Guarantees & COD Confidence */}
      <section className="bg-white border-y border-stone-200/80 py-10 my-6">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="grid grid-cols-1 md:grid-cols-3 gap-6 text-right">
            <div className="flex items-center gap-3 p-4 bg-teal-50/60 rounded-xl border border-teal-100">
              <div className="w-10 h-10 rounded-full bg-teal-700 text-white flex items-center justify-center shrink-0">
                <ShieldCheck className="w-5 h-5" />
              </div>
              <div>
                <h3 className="text-xs sm:text-sm font-bold text-stone-900">الدفع عند الاستلام (COD)</h3>
                <p className="text-[11px] text-stone-600">عاين طلبك وتأكد من جودته قبل تسليم المبلغ للمندوب</p>
              </div>
            </div>

            <div className="flex items-center gap-3 p-4 bg-teal-50/60 rounded-xl border border-teal-100">
              <div className="w-10 h-10 rounded-full bg-teal-700 text-white flex items-center justify-center shrink-0">
                <Truck className="w-5 h-5" />
              </div>
              <div>
                <h3 className="text-xs sm:text-sm font-bold text-stone-900">شحن سريع لكافة المدن</h3>
                <p className="text-[11px] text-stone-600">توصيل من 24 إلى 48 ساعة إلى باب منزلك</p>
              </div>
            </div>

            <div className="flex items-center gap-3 p-4 bg-teal-50/60 rounded-xl border border-teal-100">
              <div className="w-10 h-10 rounded-full bg-teal-700 text-white flex items-center justify-center shrink-0">
                <RotateCcw className="w-5 h-5" />
              </div>
              <div>
                <h3 className="text-xs sm:text-sm font-bold text-stone-900">استبدال سهل وسريع</h3>
                <p className="text-[11px] text-stone-600">خدمة عملاء عبر الواتساب على مدار الساعة</p>
              </div>
            </div>
          </div>
        </div>
      </section>

      {/* 6. Footer (Discreet, Professional - Admin button hidden behind discreet link & password) */}
      <footer className="bg-[#1C1917] text-stone-400 text-xs py-10 mt-auto">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 space-y-6 text-center sm:text-right">
          <div className="flex flex-col sm:flex-row items-center justify-between gap-4 border-b border-stone-800 pb-6">
            <div>
              <h3 className="text-xl font-black text-white uppercase tracking-wider font-serif">
                {storeSettings.storeName}
              </h3>
              <p className="text-stone-400 text-xs mt-1">
                {storeSettings.tagline}
              </p>
            </div>

            {/* Discreet Admin Entrance for store owner only */}
            <button
              onClick={handleRequestAdmin}
              className="inline-flex items-center gap-1.5 px-3 py-1.5 rounded-lg text-stone-500 hover:text-stone-300 text-[11px] font-medium transition-colors cursor-pointer border border-stone-800 hover:border-stone-700"
              title="دخول الإدارة (محمي بكلمة مرور)"
            >
              <Lock className="w-3.5 h-3.5 text-stone-500" />
              <span>دخول الإدارة</span>
            </button>
          </div>

          <div className="flex flex-col sm:flex-row items-center justify-between gap-4 text-[11px] text-stone-500">
            <p>© {new Date().getFullYear()} {storeSettings.storeName}. جميع الحقوق محفوظة.</p>
            <div className="flex items-center gap-3">
              <span>الدفع عند الاستلام</span>
              <span>·</span>
              <span>شحن سريع ومجاني</span>
              <span>·</span>
              <span>ضمان المعاينة والجودة</span>
            </div>
          </div>
        </div>
      </footer>

      {/* Floating WhatsApp Button */}
      <FloatingWhatsApp
        settings={storeSettings.whatsapp}
        storeName={storeSettings.storeName}
      />

      {/* Mobile Bottom Navigation Bar (No admin tab, clean shopper tabs) */}
      <BottomNav
        activeTab={activeMobileTab}
        cartCount={totalCartCount}
        onTabChange={handleMobileTabChange}
        onOpenCart={() => setIsCartOpen(true)}
      />

      {/* Modals */}
      <ProductDetailModal
        product={selectedProduct}
        settings={storeSettings}
        isOpen={isDetailModalOpen}
        onClose={() => setIsDetailModalOpen(false)}
        onAddToCart={handleAddToCart}
        onOrderSuccess={handleOrderSuccess}
      />

      <CartDrawer
        isOpen={isCartOpen}
        items={cartItems}
        settings={storeSettings}
        onClose={() => setIsCartOpen(false)}
        onUpdateQuantity={handleUpdateCartQuantity}
        onRemoveItem={handleRemoveCartItem}
        onOrderSuccess={handleOrderSuccess}
      />

      <OrderSuccessModal
        order={completedOrder}
        currency={storeSettings.currency}
        whatsappSettings={storeSettings.whatsapp}
        onClose={() => setCompletedOrder(null)}
      />

      {/* Admin Password Modal */}
      <AdminPasswordModal
        isOpen={isAdminPasswordModalOpen}
        correctPassword={storeSettings.adminPassword || 'egasa2025'}
        onSuccess={() => {
          setIsAdminPasswordModalOpen(false);
          setIsAdminOpen(true);
        }}
        onClose={() => setIsAdminPasswordModalOpen(false)}
      />
    </div>
  );
}
